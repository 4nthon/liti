package com.gao.recite.ui.screen

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gao.recite.data.WEAK_DEMO
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.components.ProgressBar
import com.gao.recite.ui.components.StatCell
import com.gao.recite.ui.components.StatDivider
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.Scope
import com.gao.recite.vm.ScopeKind
import kotlin.math.roundToInt

/**
 * 折线图 / 日历的几何参数照抄原型 SVG（viewBox 0 0 326 130）：
 * 网格线 y=15/55/95、面积填充到 y=110、圆点 r=3.5、左刻度 100@18 / 75@58 / 50@98。
 * 曲线数据不再写死 —— 由 AppVm.trendSamples() / calendarWeeks() 从按日历史现算。
 */
private const val X0 = 45f
private const val X1 = 303f
private const val FLOOR = 110f

/** 正确率 v(0..100) → 画布 y。线性映射与原型左刻度一致（100→18、75→58、50→98），0 压到 110 */
private fun accY(v: Int): Float = (18f + (100 - v.coerceIn(0, 100)) * 1.6f).coerceAtMost(FLOOR)

/**
 * 打卡格子透明度分档——**固定题数档位**（2026-09-23 老高拍板：0 / 1-150 / 151-250 / 251-350 / 351+）。
 * 各格子互不影响：某天颜色只取决于它自己当天的题数，不随其他天（哪怕做更多）变浅。
 */
private fun cellAlpha(n: Int): Float = when {
    n <= 0 -> 0f
    n < 151 -> 0.2f
    n < 251 -> 0.45f
    n < 351 -> 0.7f
    else -> 1f
}

/** "M/d" 形式的短日期（yyyyMMdd 戳） */
private fun String.shortDate(): String = "${substring(4, 6).toInt()}/${substring(6, 8).toInt()}"

/** 秒 → 「5.2」这种一位小数的小时数；不足 0.1h 显示 0 */
private fun hours(sec: Int): String {
    if (sec <= 0) return "0"
    val s = "%.1f".format(sec / 3600.0)
    return if (s.endsWith(".0")) s.dropLast(2) else s
}

@Composable
fun StatsScreen(vm: AppVm) {
    val p = LocalPalette.current
    val accGlobal = if (vm.totalAnswered > 0) (vm.totalCorrect * 100.0 / vm.totalAnswered).roundToInt() else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp),
    ) {
        Text("分析", style = AppType.pageTitle, color = p.text1)
        Spacer(Modifier.height(4.dp))
        Text("了解你的做题趋势与薄弱环节", style = AppType.pageSub, color = p.text2)
        Spacer(Modifier.height(16.dp))

        // ---------------- 历史正确率
        val trend = vm.trendSamples()
        AppCard(modifier = Modifier.padding(bottom = 12.dp)) {
            ChartHead(
                title = "历史正确率",
                sub = vm.firstStudyStamp()?.let { "按学习日期累计 · ${it.shortDate()} 开刷至今" }
                    ?: "暂无刷题记录",
                rightLabel = "整体正确率 ",
                rightValue = "$accGlobal%",
            )
            TrendChart(trend)
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 薄弱论述题 TOP 5
        // 原型 renderWeak()：动态错题（按正确率升序）+ WEAK_DEMO 四条固定演示，取前 5。
        // 本 App 没有逐题 srcStats 统计，动态部分恒为空，所以就是这 4 条。
        AppCard(modifier = Modifier.padding(bottom = 12.dp)) {
            Text("薄弱论述题 TOP 5", style = AppType.cardTitle, color = p.text1)
            Spacer(Modifier.height(12.dp))
            WEAK_DEMO.forEach { w ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            w.name,
                            style = AppType.wbarTitle, color = p.text1, maxLines = 1, modifier = Modifier.weight(1f),
                        )
                        Text("${w.v}%", style = AppType.mini, color = p.text2)
                    }
                    Spacer(Modifier.height(5.dp))
                    ProgressBar(w.v, p.wbarFill(w.v), p.wbarEnd(w.v), height = 6.dp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 五个概览数字（带竖线分隔）
        AppCard(
            modifier = Modifier.padding(bottom = 12.dp),
            padding = PaddingValues(vertical = 12.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                StatCell(null, p.text1, "${vm.weekCount}", null, "本周刷题", Modifier.weight(1f))
                StatDivider()
                StatCell(null, p.text1, hours(vm.weekSecs), "h", "本周用时", Modifier.weight(1f))
                StatDivider()
                StatCell(null, p.primary, hours(vm.totalSecs), "h", "累计用时", Modifier.weight(1f))
                StatDivider()
                StatCell(null, p.text1, "${vm.weekWrong}", null, "本周错题", Modifier.weight(1f))
                StatDivider()
                val d = vm.accDelta
                StatCell(null, p.text1, if (d > 0) "+$d" else "$d", "%", "正确率环比", Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------------- 背诵打卡日历
        AppCard {
            ChartHead(
                title = "背诵打卡日历",
                sub = if (vm.totalAnswered > 0) "当月打卡 · 颜色越深当天刷题越多" else "暂无打卡记录 · 颜色越深当天刷题越多",
                rightLabel = null,
                rightValue = null,
            )
            CheckInCalendar(vm.calendarWeeks())
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** 进度条颜色：<60 红 / <75 橙 / 其他主色（同原型 renderWeak 的取色） */
private fun com.gao.recite.ui.theme.AppPalette.wbarFill(v: Int): Color =
    if (v < 60) danger else if (v < 75) warning else primary

/** 弱项条：<60 红 / <75 橙 / 其他走默认主色渐变（同原型 .progress-fill 的分档写法） */
private fun com.gao.recite.ui.theme.AppPalette.wbarEnd(v: Int): Color? =
    if (v < 75) null else primary2

/** .chart-head：左标题 + 内联小字说明，右侧概览数字（.ov 11px/--text-2 + .ov b 15px/700 primary） */
@Composable
private fun ChartHead(title: String, sub: String, rightLabel: String?, rightValue: String?) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        // 原型是 align-items:baseline：13px 标题与 15px 概览数字按**基线**对齐
        Text(
            buildAnnotatedString {
                append(title)
                pushStyle(SpanStyle(fontSize = 10.sp, fontWeight = FontWeight.Normal, color = p.text3))
                append("  ")
                append(sub)
                pop()
            },
            style = AppType.cardTitle,
            color = p.text1,
            maxLines = 1,
            modifier = Modifier.weight(1f).alignByBaseline(),
        )
        if (rightValue != null) {
            Text(
                buildAnnotatedString {
                    append(rightLabel.orEmpty())
                    pushStyle(SpanStyle(fontSize = 15.sp, fontWeight = FontWeight.Bold, color = p.primary))
                    append(rightValue)
                    pop()
                },
                style = AppType.mini,
                color = p.text2,
                maxLines = 1,
                modifier = Modifier.alignByBaseline(),
            )
        }
    }
}

/**
 * 历史正确率折线图。[samples] 来自 AppVm.trendSamples()（≤7 个采样点，空表 = 还没刷过题）。
 * 几何照抄原型：网格 y=15/55/95、面积填到 y=110、圆点 r=3.5、均值虚线、X 轴标签。
 */
@Composable
private fun TrendChart(samples: List<Pair<String, Int>>) {
    val p = LocalPalette.current
    val n = samples.size

    // 采样点坐标：n 个点均匀铺在原型 45..303 的 X 轴上，y 按正确率线性映射
    val xs = remember(n) {
        FloatArray(n) { i -> if (n == 1) X0 else X0 + (X1 - X0) * i / (n - 1) }
    }
    val ys = remember(n, samples) { FloatArray(n) { i -> accY(samples[i].second) } }

    // 折线：原型同款平滑贝塞尔 —— 每段两个控制点都取 X 中点（lineTo 会在拐点出现棱角）
    val linePath = remember(n, samples) {
        if (n == 0) null
        else android.graphics.Path().apply {
            moveTo(xs[0], ys[0])
            for (i in 1 until n) {
                val mid = (xs[i - 1] + xs[i]) / 2f
                cubicTo(mid, ys[i - 1], mid, ys[i], xs[i], ys[i])
            }
        }
    }
    val areaPath = remember(linePath) {
        linePath?.let {
            android.graphics.Path(it).apply { lineTo(xs[n - 1], FLOOR); lineTo(xs[0], FLOOR); close() }
        }
    }
    // 均值虚线的 y（原型 y=37.4 就是 7 个采样点的均值位置）
    val meanY = remember(n, samples) { if (n == 0) 0f else accY(samples.sumOf { it.second } / n) }

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val u = maxWidth.value / 326f              // viewBox 单位 → dp
        Box(Modifier.fillMaxWidth().height((130f * u).dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val s = size.width / 326f
                // 网格
                listOf(15f, 55f, 95f).forEach { y ->
                    drawLine(p.track, Offset(28f * s, y * s), Offset(326f * s, y * s), 1f)
                }
                if (n == 0) return@Canvas
                // 均值虚线
                drawLine(
                    p.primary.copy(alpha = .45f),
                    Offset(28f * s, meanY * s), Offset(326f * s, meanY * s),
                    1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f * s, 4f * s)),
                )
                // 面积 + 折线
                drawIntoCanvas { c ->
                    c.save()
                    c.scale(s, s)
                    areaPath?.let {
                        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                            style = android.graphics.Paint.Style.FILL
                            color = p.primary.toArgb()
                            alpha = (255 * .08f).toInt()
                        }
                        c.nativeCanvas.drawPath(it, paint)
                    }
                    c.restore()
                }
                // 描边（lineTo 会在采样点处出现明显棱角，保持贝塞尔）
                linePath?.let {
                    drawIntoCanvas { c ->
                        c.save()
                        c.scale(s, s)
                        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                            style = android.graphics.Paint.Style.STROKE
                            strokeWidth = 2.5f
                            strokeCap = android.graphics.Paint.Cap.ROUND
                            strokeJoin = android.graphics.Paint.Join.ROUND
                            color = p.primary.toArgb()
                        }
                        c.nativeCanvas.drawPath(it, paint)
                        c.restore()
                    }
                }
                // 采样点
                xs.forEachIndexed { i, x ->
                    drawCircle(p.primary, 3.5f * s, Offset(x * s, ys[i] * s))
                }
                // 左侧数值刻度
                listOf(100 to 18f, 75 to 58f, 50 to 98f).forEach { (v, y) ->
                    drawIntoCanvas { c ->
                        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                            color = p.text3.toArgb()
                            textSize = 9f * s
                        }
                        c.nativeCanvas.drawText(v.toString(), if (v == 100) 4f * s else 8f * s, y * s, paint)
                    }
                }
                // 最新正确率标注（画在最后一个点的左上方）
                drawIntoCanvas { c ->
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = p.primary.toArgb()
                        textSize = 10f * s
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        textAlign = android.graphics.Paint.Align.RIGHT
                    }
                    c.nativeCanvas.drawText(
                        "${samples.last().second}%",
                        (xs.last() - 6f) * s,
                        (ys.last() - 10f) * s,
                        paint,
                    )
                }
                // X 轴标签
                xs.forEachIndexed { i, x ->
                    drawIntoCanvas { c ->
                        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                            color = p.text3.toArgb()
                            textSize = 9f * s
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        c.nativeCanvas.drawText(samples[i].first, x * s, 122f * s, paint)
                    }
                }
            }
        }
    }
}

/**
 * 打卡日历：**当月日历**（周一起始，5～6 行 × 7 列方块 36×14 / 圆角 3）+ 左侧日期刻度 + 底部「少→多」图例。
 * [weeks] 来自 AppVm.calendarWeeks()：每行 (行首周一日期 M/d, 7 天各自的答题数)，跨月/未来格为 0。
 * 画布几何沿用原型 viewBox 0 0 326 130；行数比 5 多时按每行 +20 延伸高度与图例位置。
 */
@Composable
private fun CheckInCalendar(weeks: List<Pair<String, List<Int>>>) {
    val p = LocalPalette.current
    val extra = ((weeks.size - 5).coerceAtLeast(0)) * 20f
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val u = maxWidth.value / 326f
        Box(Modifier.fillMaxWidth().height(((130f + extra) * u).dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val s = size.width / 326f
                fun cell(alpha: Float) =
                    if (alpha <= 0f) p.track else p.primary.copy(alpha = 0.2f + alpha * 0.8f)
                weeks.forEachIndexed { r, (_, counts) ->
                    counts.forEachIndexed { c, n ->
                        drawRoundRect(
                            color = cell(cellAlpha(n)),
                            topLeft = Offset((42f + 40f * c) * s, (8f + 20f * r) * s),
                            size = androidx.compose.ui.geometry.Size(36f * s, 14f * s),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f * s, 3f * s),
                        )
                    }
                }
                // 左侧日期
                weeks.forEachIndexed { i, (label, _) ->
                    drawIntoCanvas { cv ->
                        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                            color = p.text3.toArgb()
                            textSize = 9f * s
                            textAlign = android.graphics.Paint.Align.RIGHT
                        }
                        cv.nativeCanvas.drawText(label, 36f * s, (19f + 20f * i) * s, paint)
                    }
                }
                // 图例：少 + 5 档色块 + 多（随行数下移，避免与第 6 行重叠）
                val legendY = 114f + extra
                val legend = listOf(0f, .2f, .45f, .7f, 1f)
                legend.forEachIndexed { i, a ->
                    drawRoundRect(
                        color = cell(a),
                        topLeft = Offset((228f + 14f * i) * s, legendY * s),
                        size = androidx.compose.ui.geometry.Size(10f * s, 10f * s),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f * s, 2f * s),
                    )
                }
                drawIntoCanvas { cv ->
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = p.text3.toArgb()
                        textSize = 9f * s
                    }
                    cv.nativeCanvas.drawText("少", 216f * s, (legendY + 8f) * s, paint)
                    cv.nativeCanvas.drawText("多", 300f * s, (legendY + 8f) * s, paint)
                }
            }
        }
    }
}
