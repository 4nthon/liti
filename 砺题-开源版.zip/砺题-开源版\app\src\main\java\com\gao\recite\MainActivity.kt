package com.gao.recite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.toArgb
import com.gao.recite.ui.ReciteAppRoot
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.theme.paletteFor
import com.gao.recite.vm.AppVm

class MainActivity : ComponentActivity() {

    /** 提到 Activity 层，是为了在 onStop 里能摸到它做兜底落盘 */
    private val vm: AppVm by viewModels()

    /** 题库导入：SAF 多选 txt（launcher 必须在 Activity 上注册，所以挂在这里） */
    private val pickQbank = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importQbank(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.onPickFiles = { pickQbank.launch(arrayOf("*/*")) }
        setContent {
            // 外观三态：light / dark / auto（跟随系统）
            val sysDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                "dark" -> true
                "auto" -> sysDark
                else -> false
            }
            val p = paletteFor(dark)
            DisposableEffect(p) {
                window.statusBarColor = p.bg.toArgb()
                window.navigationBarColor = p.surface.toArgb()
                onDispose { }
            }
            CompositionLocalProvider(LocalPalette provides p) {
                ReciteAppRoot(vm)
            }
        }
    }

    /**
     * 切出 / 被杀之前的兜底落盘。
     *
     * 答题计时每秒都在跳，不可能每一跳都写盘，所以平时只在「选答案 / 确认 / 翻页 / 收藏」这些
     * 节点上异步落盘，秒数这类高频字段靠这里在切出时同步补一次。
     * 按 Home 键、切到别的 App、从最近任务里划掉都会走到 onStop。
     */
    override fun onStop() {
        super.onStop()
        vm.persistNow()
    }
}
