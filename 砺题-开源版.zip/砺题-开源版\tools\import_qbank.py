# -*- coding: utf-8 -*-
"""
题库导入器：把 `tools/qbank_src/` 下的 `*DayN*.txt` 解析为 App 用的 qbank.tsv。

题库 txt 的书写格式（宽容解析，兼容多种写法）：

  小标题      【马克思主义】
  题干        1、马克思主义是由…… ____ 所不断发展的科学理论体系。
  选项        A. 后继者        （也可能是  A、后继者）
  多空选项    A. 唯物论 \\ 辩证法  /  A. 唯物论 / 辩证法   （两种分隔符都吃）
  答案        答案：A           正确答案：A
  解析        解析：原文「……」   解析：填充后的整句

用法：
  python import_qbank.py --analyze              # 体检，报告写入 tools/import_analyze.txt
  python import_qbank.py --probe-exp            # 分析「解析」是否含额外讲解
  python import_qbank.py --emit <out.tsv>       # 生成 App 用的数据文件
可选 --src <目录> 指定题目 txt 所在目录（默认 tools/qbank_src/）。
"""
import io
import json
import os
import re
import sys

# 题目 txt 的默认来源目录（把你的 DayN.txt 放进 tools/qbank_src/ 即可，
# 或用 --src 指定其他目录）
SRC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qbank_src")

RE_HEAD = re.compile(r"^\s*【\s*(.+?)\s*】\s*$")
RE_QNUM = re.compile(r"^\s*(\d+)\s*[、.．]\s*(.*)$")
RE_OPT = re.compile(r"^\s*([A-Da-d])\s*[、.．:：]\s*(.*)$")
RE_ANS = re.compile(r"^\s*(?:正确)?答案\s*[：:]\s*([A-Da-d])\s*$")
RE_EXP = re.compile(r"^\s*(?:解析|分析|解答)\s*[：:]\s*(.*)$")
# 空位标记：下划线（2 个以上）或全角/半角方括号空位
RE_BLANK = re.compile(r"_{2,}|【\s*】|\[\s*\]")
# 选项内部的分空分隔符：` \ `、` / `、`／`、`；`（只取单独成段的那类）
RE_SEP = re.compile(r"\s*\\\s*|\s+/\s+|\s*／\s*")


def read_text(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def normalize_stem(s):
    """只挤多余空白，空位标记（____ / 【 】）保持原样不转换（2026-09-22 用户要求）"""
    s = re.sub(r"[ \t]+", " ", s)
    return s.strip()


def normalize_opt(s):
    """多空选项的分隔符统一成 ` / `，去掉前后多余空格"""
    s = re.sub(r"\s*\\\s*", " / ", s)
    s = re.sub(r"\s+/\s+", " / ", s)
    s = re.sub(r"\s*／\s*", " / ", s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\s*/\s*", " / ", s)
    return s.strip()


def parse_file(path):
    """返回 (day_name, [ (heading, [question, ...]) , ...])"""
    name = os.path.basename(path)
    m = re.search(r"Day\s*(\d+)", name)
    day = "Day%d" % int(m.group(1)) if m else os.path.splitext(name)[0]

    lines = read_text(path).splitlines()
    groups = []
    cur_head = None
    cur_qs = []
    q = None  # 正在收集的题

    def flush_q():
        if q is not None:
            cur_qs.append(q)

    for raw in lines:
        line = raw.rstrip()
        if not line.strip():
            continue
        mh = RE_HEAD.match(line)
        if mh:
            flush_q(); q = None
            if cur_head is not None or cur_qs:
                groups.append((cur_head, cur_qs))
            cur_head, cur_qs = mh.group(1), []
            continue
        ma = RE_ANS.match(line)
        if ma and q is not None:
            q["ans"] = ma.group(1).upper()
            continue
        me = RE_EXP.match(line)
        if me and q is not None:
            q["exp"] = me.group(1).strip()
            continue
        mo = RE_OPT.match(line)
        if mo and q is not None and not q["opts"] is None:
            # 选项行：字母必须是紧接着那一轮的（A B C D 顺序出现）
            letter = mo.group(1).upper()
            if letter == chr(ord("A") + len(q["opts"])):
                q["opts"].append(normalize_opt(mo.group(2)))
                continue
        mq = RE_QNUM.match(line)
        if mq:
            flush_q()
            q = {"num": int(mq.group(1)), "stem": mq.group(2), "opts": [],
                 "ans": None, "exp": ""}
            continue
        # 题干续行（题干太长被换行）
        if q is not None and not q["opts"]:
            q["stem"] += line.strip()
        elif q is not None and q["opts"]:
            q["exp"] = (q["exp"] + line.strip())

    flush_q()
    if cur_head is not None or cur_qs:
        groups.append((cur_head, cur_qs))
    return day, groups


def collect(src_dir=None):
    if src_dir is None:
        src_dir = SRC_DIR
    files = [f for f in os.listdir(src_dir) if f.endswith(".txt")]
    files.sort(key=lambda f: int(re.search(r"Day(\d+)", f).group(1))
               if re.search(r"Day(\d+)", f) else 0)
    out = []
    for f in files:
        day, groups = parse_file(os.path.join(src_dir, f))
        out.append((f, day, groups))
    return out


def analyze():
    problems = []
    total_q = 0
    lines = []
    for fname, day, groups in collect():
        stat = {"q": 0, "no_ans": 0, "opt_counts": {}, "ans_bad": 0,
                "no_exp": 0, "n_dup": 0, "n_jump": 0}
        heads = []
        last_num = 0
        for head, qs in groups:
            heads.append("%s(%d)" % (head, len(qs)))
            seen_num = set()   # 题号在每个小标题内重新从 1 开始
            for q in qs:
                stat["q"] += 1
                total_q += 1
                n = len(q["opts"])
                stat["opt_counts"][n] = stat["opt_counts"].get(n, 0) + 1
                if q["ans"] is None:
                    stat["no_ans"] += 1
                    problems.append("%s %s Q%d 缺答案：%s" % (fname, head, q["num"], q["stem"][:40]))
                elif ord(q["ans"]) - 65 >= n:
                    stat["ans_bad"] += 1
                    problems.append("%s %s Q%d 答案 %s 超出 %d 个选项" % (fname, head, q["num"], q["ans"], n))
                if not q["exp"]:
                    stat["no_exp"] += 1
                    problems.append("%s %s Q%d 缺解析：%s" % (fname, head, q["num"], q["stem"][:40]))
                if q["num"] in seen_num:
                    stat["n_dup"] += 1
                    problems.append("%s %s 题号重复 %d" % (fname, head, q["num"]))
                seen_num.add(q["num"])
                last_num = q["num"]
                # 同题四个选项的内部结构应当一致：分空数不同 = 选项排版出错
                sep_counts = {len(RE_SEP.findall(o)) for o in q["opts"]}
                if len(sep_counts) > 1:
                    problems.append("%s %s Q%d 四个选项分空数不一致 %s：%s"
                                    % (fname, head, q["num"], sorted(sep_counts), q["stem"][:36]))
        lines.append("=== %-16s %-6s 题数=%-4d 无答案=%-3d 无解析=%-3d 选项数分布=%s 标题=%d"
                     % (fname, day, stat["q"], stat["no_ans"], stat["no_exp"],
                        stat["opt_counts"], len(groups)))
        lines.append("    标题:" + " | ".join(heads))
    lines.append("")
    lines.append("总题数 = %d，问题条目 = %d" % (total_q, len(problems)))
    lines.append("--- 问题明细 ---")
    lines.extend(problems)
    here = os.path.dirname(os.path.abspath(__file__))
    with io.open(os.path.join(here, "import_analyze.txt"), "w", encoding="utf-8", newline="") as fh:
        fh.write("\n".join(lines))
    print("report -> tools/import_analyze.txt  (总题数 %d, 问题 %d)" % (total_q, len(problems)))


def probe_exp():
    """看看「解析」到底是纯原文引用，还是另带讲解 —— 决定要不要保留 exp 字段"""
    lines = []
    n_wrap = 0
    n_with_expl = 0
    total = 0
    samples = []
    for fname, day, groups in collect():
        for head, qs in groups:
            for q in qs:
                total += 1
                e = q["exp"]
                if e.startswith("原文") and ("「" in e and "」" in e):
                    n_wrap += 1
                    inner = e[e.find("「") + 1:e.rfind("」")]
                else:
                    inner = e
                # 去掉填充词后的长度差：解析比题干长很多，说明另外写了讲解
                body = RE_BLANK.sub("", q["stem"])
                if len(inner) > len(body) * 2 + 30:
                    n_with_expl += 1
                    if len(samples) < 12:
                        samples.append("%s %s Q%d\n    题干: %s\n    解析: %s"
                                       % (fname, head, q["num"], q["stem"][:70], e[:200]))
    lines.append("总题数 %d，解析带「原文「」」包装 %d，疑似含额外讲解 %d" % (total, n_wrap, n_with_expl))
    lines.append("--- 疑似含讲解的样例 ---")
    lines.extend(samples)
    here = os.path.dirname(os.path.abspath(__file__))
    with io.open(os.path.join(here, "import_exp.txt"), "w", encoding="utf-8", newline="") as fh:
        fh.write("\n".join(lines))
    print("report -> tools/import_exp.txt")


CJK = r"\u4e00-\u9fff"
CJK_PUNCT = r"\u3000-\u303f\uff01-\uff65"
SENT = "\ue000"   # 空位哨兵（私用区字符，正文里不会出现）
# 中日韩字符之间（以及 CJK 与数字、与空位哨兵之间）的空格是"填空留下的填充空格"，不是原文的
RE_FILL_SPACE = re.compile(r"(?<=[%s%s0-9%s])[ \t]+(?=[%s%s0-9%s])"
                           % (CJK, CJK_PUNCT, SENT, CJK, CJK_PUNCT, SENT))


def tidy(s):
    """把填空时人为加在词两边的空格去掉（中文正文里不该有词间空格）"""
    s = s.replace("\u00a0", " ")
    s = RE_FILL_SPACE.sub("", s)
    s = re.sub(r"[ \t]{2,}", " ", s)
    return s.strip()


def clean_stem(s):
    s = normalize_stem(s)
    # 先把空位换成哨兵：tidy 会把「【 】」里的空格当填充空格吃掉
    s = s.replace("【 】", SENT)
    s = tidy(s)
    # 标点两侧不留空格（此时空位还是哨兵，不会被误伤）
    s = re.sub(r"[ \t]*([，。；：、）】”』])\s*", r"\1", s)
    s = re.sub(r"([（【“‘『])\s*", r"\1", s)
    s = s.replace(SENT, "【 】")
    return s.strip()


def clean_opt(s):
    s = normalize_opt(s)
    parts = [tidy(p) for p in s.split(" / ")]
    return " / ".join([p for p in parts if p != ""])


def clean_root(s):
    """解析 → 背诵原文：剥掉「原文」前缀和引号包装，去掉填充空格"""
    s = s.strip()
    s = re.sub(r"^\s*原文\s*", "", s)
    s = s.strip()
    for a, b in (("「", "」"), ("“", "”"), ("『", "』"), ("\"", "\"")):
        if s.startswith(a) and s.endswith(b) and len(s) > len(a) + len(b):
            s = s[len(a):-len(b)]
            break
    s = tidy(s)
    s = re.sub(r"[ \t]*([，。；：、）】”』])\s*", r"\1", s)
    s = re.sub(r"([（【“‘『])\s*", r"\1", s)
    return s.strip()


RE_ANY_BLANK = re.compile(r"【\s*】|_{2,}|\[\s*\]")


def fill_stem(stem, opt):
    """保底：把正确答案回填进题干，得到背诵原文（空位标记可能是 ____ 也可能是【 】）"""
    parts = opt.split(" / ")
    out = stem
    for p in parts:
        out = RE_ANY_BLANK.sub(lambda m: p, out, count=1)
    return RE_ANY_BLANK.sub("", out)


def emit(out_path, stats_path=None):
    days = []
    n_q = 0
    lines = []
    for fname, day, groups in collect():
        bigs = []
        for head, qs in groups:
            qlist = []
            for q in qs:
                if q["ans"] is None or len(q["opts"]) == 0:
                    continue
                stem = clean_stem(q["stem"])
                opts = [clean_opt(o) for o in q["opts"]]
                ai = ord(q["ans"]) - 65
                if ai >= len(opts):
                    continue
                root = clean_root(q["exp"]) or fill_stem(stem, opts[ai])
                if len(root) < 6 or root == stem:
                    root = fill_stem(stem, opts[ai])
                assert "\t" not in stem and "\t" not in root
                assert not any("\t" in o for o in opts)
                qlist.append((stem, opts, ai, root))
                n_q += 1
            if qlist:
                bigs.append((head, qlist))
        if bigs:
            days.append((day, bigs))

    with io.open(out_path, "w", encoding="utf-8", newline="\n") as fh:
        for day, bigs in days:
            fh.write("D\t%s\n" % day)
            for head, qs in bigs:
                fh.write("B\t%s\n" % head)
                for stem, opts, ai, root in qs:
                    fh.write("Q\t%s\t%s\t%d\t%s\n" % (stem, "\t".join(opts), ai, root))

    info = []
    info.append("day 数 = %d，论述题数 = %d，题目数 = %d"
                % (len(days), sum(len(b) for _, b in days), n_q))
    for day, bigs in days:
        info.append("%s: %d 个论述题 / %d 题  |  %s"
                    % (day, len(bigs), sum(len(q) for _, q in bigs),
                       "、".join(h for h, _ in bigs[:4]) + ("…" if len(bigs) > 4 else "")))
    info.append("输出文件大小 = %d 字节" % os.path.getsize(out_path))
    if stats_path:
        with io.open(stats_path, "w", encoding="utf-8", newline="") as fh:
            fh.write("\n".join(info))
    print("\n".join(info[:3]))


if __name__ == "__main__":
    if "--src" in sys.argv:
        SRC_DIR = sys.argv[sys.argv.index("--src") + 1]
    if "--analyze" in sys.argv:
        analyze()
    elif "--probe-exp" in sys.argv:
        probe_exp()
    elif "--emit" in sys.argv:
        out = sys.argv[sys.argv.index("--emit") + 1]
        stats = os.path.join(os.path.dirname(os.path.abspath(__file__)), "import_emit.txt")
        emit(out, stats)
    else:
        print("用法：python import_qbank.py [--src <题目txt目录>] --analyze | --probe-exp | --emit <out.tsv>")
