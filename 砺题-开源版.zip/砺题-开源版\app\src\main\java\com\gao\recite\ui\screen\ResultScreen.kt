package com.gao.recite.ui.screen

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.Scope
import com.gao.recite.vm.ScopeKind
import kotlin.math.roundToInt

/**
 * 结果分析页 —— 逐条对照原型 #result（.r-hero / .r-review / .r-tip / .r-actions）。
 */
@Composable
fun ResultScreen(vm: AppVm) {
    val p = LocalPalette.current
    val answered = vm.answeredCount
    val right = vm.answeredRight
    val wrong = vm.answeredWrong
    val total = if (answered > 0) answered else vm.qSet.size
    val pct = if (total > 0) (right * 100.0 / total).roundToInt() else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 24.dp),
    ) {
        // ---------------- .r-hero ----------------
        AppCard(
            modifier = Modifier.padding(bottom = 12.dp),
            padding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 16.dp),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // .r-donut：140×140，r=52，stroke-width 10，dasharray = pct/100 × 2πr
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(140.dp)) {
                    // 环色分档：>=80 绿 / >=60 橙 / 其他红（原型 showResult）
                    val arcColor = when {
                        pct >= 80 -> p.success
                        pct >= 60 -> p.warning
                        else -> p.danger
                    }
                    Canvas(modifier = Modifier.size(140.dp)) {
                        val stroke = 10.dp.toPx()
                        val r = 52.dp.toPx()
                        val topLeft = Offset(center.x - r, center.y - r)
                        val boxSize = Size(r * 2, r * 2)
                        drawArc(
                            color = p.track,
                            startAngle = -90f, sweepAngle = 360f, useCenter = false,
                            topLeft = topLeft, size = boxSize,
                            style = Stroke(width = stroke, cap = StrokeCap.Butt),
                        )
                        drawArc(
                            color = arcColor,
                            startAngle = -90f, sweepAngle = 360f * pct / 100f, useCenter = false,
                            topLeft = topLeft, size = boxSize,
                            style = Stroke(width = stroke, cap = StrokeCap.Round),
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$pct%", style = AppType.resultPct, color = p.text1)
                        Spacer(Modifier.height(2.dp))
                        Text("正确率", style = AppType.resultSub, color = p.text3)
                    }
                }
                Spacer(Modifier.height(12.dp))
                // 原型：#rTitle = wrong===0 ? '太棒了，全对！🎉' : '本组练习完成'
                Text(
                    if (wrong == 0 && answered > 0) "太棒了，全对！🎉" else "本组练习完成",
                    style = AppType.resultTitle,
                    color = p.text1,
                )
                Spacer(Modifier.height(12.dp))
                // .r-stats：三等分，格与格之间 60% 高的 1px 竖线
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    RStat(fmtElapsed(vm.seconds), "用时", p.text1, Modifier.weight(1f))
                    StatLine()
                    RStat("$right", "答对", p.success, Modifier.weight(1f))
                    StatLine()
                    RStat("$wrong", "答错", p.danger, Modifier.weight(1f))
                }
            }
        }

        // ---------------- 逐题回顾 ----------------
        // 原型 .r-review：标题 13px/700；rList 只收「已确认」的题，且序号按**列表序**从 1 排
        // （原型 qResults.forEach((r,i)=> i+1)，不是原题位次）
        val reviewed = vm.qSet.indices.filter { vm.answers[it]?.confirmed == true }
        AppCard(modifier = Modifier.padding(bottom = 12.dp)) {
            Text("逐题回顾", style = AppType.resultH4, color = p.text1)
            Spacer(Modifier.height(4.dp))
            reviewed.forEachIndexed { i, pos ->
                val q = vm.quiz[vm.qSet[pos]]
                val ok = vm.answers[pos]?.right == true
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .background(
                                if (ok) p.success.copy(alpha = .14f) else p.dangerSoft,
                                RoundedCornerShape(6.dp),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "${i + 1}",
                            style = AppType.rRowIdx,
                            color = if (ok) p.success else p.danger,
                        )
                    }
                    Text(
                        q.text,
                        style = AppType.reviewQ,
                        color = p.text1,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        if (ok) "答对" else "答错",
                        style = AppType.rRowSt,
                        color = if (ok) p.success else p.danger,
                    )
                }
                if (i != reviewed.lastIndex) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.cardBorder))
                }
            }
        }

        // ---------------- 背诵全文 ----------------
        // 原型：roots = qResults.length ? qResults : qSet —— 同样按列表序编号
        val roots = if (reviewed.isNotEmpty()) {
            reviewed.mapIndexed { i, pos -> (i + 1) to vm.quiz[vm.qSet[pos]].root }
        } else {
            vm.qSet.mapIndexed { pos, id -> (pos + 1) to vm.quiz[id].root }
        }
        AppCard(modifier = Modifier.padding(bottom = 12.dp)) {
            Text(vm.rootTitle(), style = AppType.resultH4, color = p.text1)
            Spacer(Modifier.height(4.dp))
            roots.forEachIndexed { i, (no, root) ->
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Text("$no", style = AppType.rRowIdx, color = p.primary)
                    Spacer(Modifier.height(2.dp))
                    Text(root, style = AppType.reciteRoot, color = p.text1)
                }
                if (i != roots.lastIndex) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(p.cardBorder))
                }
            }
        }

        // （原「AI 建议」卡已按用户要求删除，2026-09-22）

        // ---------------- .r-actions ----------------
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // 只练错题：有错题才出现
            if (wrong > 0) {
                ActionButton("只练错题", p.dangerSoft, p.danger, Modifier.weight(1f)) { vm.retryWrong() }
            }
            // .btn-ghost：primary-soft 底 + primary 字
            ActionButton("再练一遍", p.primarySoft, p.primary, Modifier.weight(1f)) {
                vm.startQuiz(vm.scope ?: Scope(ScopeKind.DAY, 0, 0))
            }
            ActionButton("返回首页", p.primary, p.onPrimary, Modifier.weight(1f)) { vm.closeResult() }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatLine() {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .width(1.dp)
            .fillMaxHeight(.6f)
            .background(p.cardBorder),
    )
}

@Composable
private fun RStat(num: String, label: String, color: Color, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(num, style = AppType.resultStatNum, color = color)
        Spacer(Modifier.height(2.dp))
        Text(label, style = AppType.resultSub, color = p.text2)
    }
}

/** .r-actions .btn —— flex 1 / 48 高 / 圆角 16 / 15px */
@Composable
private fun ActionButton(
    label: String,
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .height(48.dp)
            .background(bg, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = AppType.btnLg, color = fg, maxLines = 1)
    }
}

private fun fmtElapsed(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)
