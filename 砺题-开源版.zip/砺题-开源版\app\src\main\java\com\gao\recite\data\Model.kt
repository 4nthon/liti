package com.gao.recite.data

/** 第三级：一道论述题（原型 TREE.day[].big[]） */
data class BigTopic(
    val title: String,
    val done0: Int,
    val total: Int,
    val acc0: Int,
)

/** 第二级：一个 Day */
data class DayNode(
    val name: String,
    val big: List<BigTopic>,
)

/** 第一级：一个科目 */
data class Subject(
    val name: String,
    val short: String,
    val cls: String,
    val start: Int,
    val total: Int,
    /** 该科目预计收录的论述题总数（原型 TREE.ej） */
    val ej: Int,
    val range: String,
    val day: List<DayNode>,
)

/** 一道选择题（原型 QUIZ[]） */
data class Question(
    val id: Int,
    val src: String,
    val text: String,
    val opts: List<String>,
    val ans: Int,
    val root: String,
    val exp: String,
    /** [0] = 「马原 · Day1」，[1] = 论述题名 */
    val kp: List<String>,
)

/**
 * 错题本演示种子的一条（原型 DEMO_WRONG_BIG 的键值对）。
 * [title] 用的是**原型原文**的论述题名 —— 其中「意识的本质」与 QUIZ 里的
 * 「意识的起源与本质」差一个词（原型如此），因此该条查不到题目，题数为 0。
 */
data class WrongSeed(
    val si: Int,
    val di: Int,
    val bi: Int,
    /** 整题全对的累计次数（满 3 次消灭） */
    val n: Int,
    val title: String,
)

/** 分析页「薄弱论述题 TOP 5」的固定演示条目（原型 WEAK_DEMO） */
data class WeakDemo(val name: String, val v: Int)

/** 各层统计结果 */
data class Stats(
    val done: Int,
    val total: Int,
    val bigs: Int,          // 论述题总数
    val started: Int,       // 已开始（做过至少一题）的论述题数
    val correct: Int,
    val acc: Int,
    val pct: Int,
) {
    val remain: Int get() = (total - done).coerceAtLeast(0)
}
