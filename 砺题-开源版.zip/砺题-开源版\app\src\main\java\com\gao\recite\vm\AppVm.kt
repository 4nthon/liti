package com.gao.recite.vm

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import com.gao.recite.data.AnsLine
import com.gao.recite.data.Bank
import com.gao.recite.data.BigLine
import com.gao.recite.data.DayLine
import com.gao.recite.data.ID_SEP
import com.gao.recite.data.OrdLine
import com.gao.recite.data.ProgressSnapshot
import com.gao.recite.data.ProgressStore
import com.gao.recite.data.QbankParser
import com.gao.recite.data.Question
import com.gao.recite.data.SetLine
import com.gao.recite.data.Stats
import com.gao.recite.data.Subject
import com.gao.recite.data.TREE
import com.gao.recite.data.TOPICS
import com.gao.recite.data.WrongLine
import com.gao.recite.data.WRONG_SEED
import com.gao.recite.data.stableHash
import java.util.Calendar
import java.util.concurrent.Executors
import java.nio.charset.Charset
import kotlin.math.roundToInt

enum class ScopeKind { BIG, DAY, SUBJECT, FAV, WRONG_ALL, ALL, SINGLE }

/** 诊断日志 tag（选项「按不动」这类问题的排查入口：adb logcat -s ZhiyanVM） */
private const val TAG = "ZhiyanVM"

data class Scope(
    val kind: ScopeKind,
    val si: Int = -1,
    val di: Int = -1,
    val bi: Int = -1,
) {
    fun title(): String = when (kind) {
        ScopeKind.BIG -> TREE[si].short + " · " + TREE[si].day[di].name + " · 论述题「" + TREE[si].day[di].big[bi].title + "」"
        ScopeKind.DAY -> TREE[si].short + " · " + TREE[si].day[di].name
        ScopeKind.SUBJECT -> TREE[si].short + " · 整科背诵"
        ScopeKind.FAV -> "我的收藏"
        ScopeKind.WRONG_ALL -> "错题重练 · 全部"
        ScopeKind.ALL -> "随机背诵 · 全部"
        ScopeKind.SINGLE -> "错题重练 · 单题"
    }
}

data class AnswerRec(val selected: Int, val right: Boolean, val confirmed: Boolean = false)

/** 题库导入的状态机：空闲 → 解析中 → 成功（待重启生效）/ 失败 */
sealed interface ImportState {
    object Idle : ImportState
    object Working : ImportState
    data class Done(val message: String) : ImportState
    data class Failed(val message: String) : ImportState
}

/**
 * 首页顶部那张「继续上次背诵」卡要显示的内容。
 * 原型里这张卡是写死的（Day1 · 论述题「物质的定义」/ 75% / 9-12 题），
 * 换上真题后落点会随实际答题变化，所以改成从数据算。
 */
data class ContinueCard(
    /** 「继续上次背诵 · 马原」/「开始背诵 · 马原」 */
    val title: String,
    /** Day 名，用来拼顶部标题（原型 pendingTopic 的形式：继续上次背诵 · 马原 · Day1） */
    val day: String,
    /** 「Day1 · 论述题「马克思主义」」 */
    val sub: String,
    val pct: Int,
    /** 「上次做到 3/8 题」/「共 8 道题」拆成三段，保留原来的字重差（数字加粗） */
    val footPre: String,
    val footNum: String,
    val footSuffix: String,
    val scope: Scope,
    /**
     * true = 点这张卡是**续上上次那一轮**（同一个题目表、同一题位、已答记录还在）；
     * false = 只是落到某道论述题上重新开一轮。
     */
    val resume: Boolean = false,
)

/**
 * 从 `progress.tsv` 里恢复出来、还没被接管的会话存档。
 *
 * 启动时先把快照放在这儿；等用户点了「继续上次背诵」才由 [AppVm.resumeSession] 灌进真正的
 * 会话状态。这样做的原因：会话的一半状态（`answers` / `counted` / `optOrder`）是
 * `mutableStateMapOf`，启动时直接灌进去会让首页也带着一堆答题态。
 */
private class SavedSession(
    val scope: Scope,
    val topic: String,
    val backMode: Boolean,
    val qIdx: Int,
    val seconds: Int,
    val resultPhase: Boolean,
    val ids: List<Int>,
    val answers: Map<Int, AnswerRec>,
    val counted: Set<Int>,
    val bigProgress: Map<String, Set<String>>,
    val optOrder: Map<Int, List<Int>>,
)

class AppVm(app: Application) : AndroidViewModel(app) {

    // 用 get() 取而不是快照：Bank 在 ensure() 之前是空列表，这样属性初始化顺序不会坑到自己
    val quiz: List<Question> get() = Bank.quiz
    val tree: List<Subject> get() = Bank.tree

    // ---------- 题目 → 论述题 的定位索引 ----------
    // 真题有 2100+ 题、160+ 论述题，原来每个题都现扫一遍 TREE（locate）会拖垮题库页与错题重练。
    // 装载后一次性建表：题号 → 所属论述题，以及 论述题/Day/科目 → 题号集合。
    // 注意：这些必须先声明再 init（Kotlin 按声明顺序初始化），否则 buildIndex 会写到 null。
    private var bigOfQ: Array<Triple<Int, Int, Int>?> = emptyArray()
    private val qidsByBig = HashMap<String, List<Int>>()
    private val qidsByDay = HashMap<String, List<Int>>()
    private val qidsBySubj = HashMap<Int, List<Int>>()

    // ---------- 稳定 ID 反查表（落盘用） ----------
    // 落盘一律用内容派生的 ID，读回来时再靠这两张表映回当前下标。
    // 题库增量追加后，老 ID 依然解得开，历史进度不受影响。
    private val bigIdToIdx = HashMap<String, Triple<Int, Int, Int>>()
    private var qidOfQ: Array<String> = emptyArray()
    private val qidToIdx = HashMap<String, Int>()

    init {
        // 题库装载必须排在最前面：下面的 doneMap 初始化、以及所有索引都依赖 tree / quiz
        Bank.ensure(app.applicationContext)
        buildIndex()
    }

    /**
     * 论述题的稳定 ID：科目简称 + Day 名 + 论述题标题。
     * 不含任何下标 —— Day18 之后追加进来时，已有的 ID 一个都不会变。
     */
    fun bigIdAt(si: Int, di: Int, bi: Int): String =
        tree[si].short + ID_SEP + tree[si].day[di].name + ID_SEP + tree[si].day[di].big[bi].title

    private fun buildIndex() {
        bigOfQ = arrayOfNulls(quiz.size)
        qidOfQ = Array(quiz.size) { "" }
        val bigAt = HashMap<String, Triple<Int, Int, Int>>()
        tree.forEachIndexed { si, sj ->
            sj.day.forEachIndexed { di, d ->
                d.big.forEachIndexed { bi, b ->
                    val t = Triple(si, di, bi)
                    bigAt[sj.short + " · " + d.name + ID_SEP + b.title] = t
                    bigIdToIdx[sj.short + ID_SEP + d.name + ID_SEP + b.title] = t
                }
            }
        }
        val byBig = HashMap<String, MutableList<Int>>()
        val byDay = HashMap<String, MutableList<Int>>()
        val bySubj = HashMap<Int, MutableList<Int>>()
        // 同一道论述题里题干完全相同的题（真题里偶有重复）靠出现序号区分，避免指纹撞车
        val occ = HashMap<String, Int>()
        quiz.forEachIndexed { i, q ->
            val t = bigAt[(q.kp.getOrNull(0).orEmpty()) + ID_SEP + (q.kp.getOrNull(1).orEmpty())]
                ?: return@forEachIndexed
            bigOfQ[i] = t
            val id = bigIdAt(t.first, t.second, t.third)
            val key = id + ID_SEP + q.text
            val n = occ.getOrDefault(key, 0)
            occ[key] = n + 1
            val qid = stableHash(key + ID_SEP + n)
            qidOfQ[i] = qid
            qidToIdx[qid] = i
            byBig.getOrPut(id) { mutableListOf() }.add(i)
            byDay.getOrPut("${t.first}#${t.second}") { mutableListOf() }.add(i)
            bySubj.getOrPut(t.first) { mutableListOf() }.add(i)
        }
        qidsByBig.putAll(byBig)
        qidsByDay.putAll(byDay)
        qidsBySubj.putAll(bySubj)
    }

    // ---------- 设置（对应原型 S.set，默认 light / false / true） ----------
    /** 外观三态：light / dark / auto（跟随系统） */
    var themeMode by mutableStateOf("light")
        private set

    /** 练习 · 选项乱序：只打乱展示顺序，判分仍按原始下标。2026-09-22 起默认打开 */
    var optShuffle by mutableStateOf(true)
        private set

    /**
     * 答题模式（设置页可改，2026-09-22 二次定义）：
     * back = 背题模式 —— 点选项作答后**立即判分**并显示答案与解析（对就是对、错就是错，计入统计）；
     * test = 测验模式 —— 作答只做标记不判分，**交卷后**统一算分再显示答案。
     * 默认 back。
     */
    var quizMode by mutableStateOf("back")
        private set

    /** 练习 · 显示答题计时 */
    var showTimer by mutableStateOf(true)
        private set

    var settingsOpen by mutableStateOf(false)
        private set

    fun openSettings() { settingsOpen = true }
    fun closeSettings() { settingsOpen = false }

    fun chooseTheme(v: String) {
        themeMode = v
        showToast(
            when (v) {
                "auto" -> "已跟随系统深浅色"
                "dark" -> "已切换到深色模式 🌙"
                else -> "已切换到浅色模式 ☀️"
            },
        )
        persist()
    }

    fun chooseQuizMode(v: String) {
        quizMode = v
        showToast(if (v == "back") "已切换到背题模式 📖" else "已切换到测验模式 ✍️")
        persist()
    }

    fun toggleOptShuffle(v: Boolean) {
        optShuffle = v
        showToast(if (v) "选项乱序已开启" else "选项乱序已关闭")
        persist()
    }

    fun toggleShowTimer(v: Boolean) {
        showTimer = v
        showToast(if (v) "答题计时已显示" else "答题计时已隐藏")
        persist()
    }

    // ---------- 题库导入（开源版：App 内直接导入 DayN.txt，替换示例题库） ----------

    var importState by mutableStateOf<ImportState>(ImportState.Idle)
        private set

    /** 由 MainActivity 注册文件选择器后注入（SAF 的 launcher 必须在 Activity 上注册） */
    var onPickFiles: (() -> Unit)? = null

    fun startPickFiles() {
        if (onPickFiles == null) {
            showToast("文件选择器未就绪，请重启应用")
        } else {
            onPickFiles?.invoke()
        }
    }

    /**
     * 导入题库：后台读取所选 txt → [QbankParser] 解析 → 落盘 `qbank_imported.tsv`。
     * 新题库在**下次进程启动**时由 [com.gao.recite.data.Bank.ensure] 装载（导入成功后提示重启）。
     */
    fun importQbank(uris: List<Uri>) {
        if (importState == ImportState.Working) return
        importState = ImportState.Working
        io.execute {
            try {
                val ctx = getApplication<Application>()
                val files = uris.mapNotNull { u ->
                    val bytes = ctx.contentResolver.openInputStream(u)?.use { it.readBytes() }
                        ?: return@mapNotNull null
                    queryDisplayName(ctx, u) to decodeText(bytes)
                }
                if (files.isEmpty()) {
                    importState = ImportState.Failed("读取文件失败，请重试")
                    return@execute
                }
                val st = QbankParser.emit(files)
                if (st.qCount == 0) {
                    importState = ImportState.Failed(
                        "没有解析出任何题目。请确认选择的是「DayN.txt」格式的题库文件：\n" +
                            "【小标题】+ 题号题干 + A–D 选项 + 答案：X + 解析",
                    )
                    return@execute
                }
                Bank.importedFile(ctx).writeText(st.tsv, Charsets.UTF_8)
                val head = "共导入 ${st.dayCount} 个 Day · ${st.bigCount} 个论述题 · ${st.qCount} 道选择题"
                val detail = if (st.perDay.isNotEmpty()) "\n" + st.perDay.joinToString("\n") else ""
                val warn = if (st.skipped > 0) "\n\n跳过 ${st.skipped} 题：" + st.warnings.joinToString("；") else ""
                importState = ImportState.Done(head + detail + warn + "\n\n重启应用后生效，历史进度里相同内容的题目会自动对应上。")
            } catch (e: Exception) {
                Log.e(TAG, "qbank import failed", e)
                importState = ImportState.Failed("导入失败：${e.message ?: "未知错误"}")
            }
        }
    }

    /** 删除导入的题库，恢复 assets 内置示例（重启后生效） */
    fun restoreSampleQbank() {
        if (importState == ImportState.Working) return
        importState = ImportState.Working
        io.execute {
            val f = Bank.importedFile(getApplication<Application>())
            if (f.exists()) f.delete()
            importState = ImportState.Done("已删除导入的题库，将恢复内置示例题库。\n\n重启应用后生效。")
        }
    }

    fun dismissImport() {
        importState = ImportState.Idle
    }

    /** 重启应用让新题库生效：重启 launcher + 结束当前进程 */
    fun restartToApply() {
        val ctx = getApplication<Application>()
        val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            ctx.startActivity(i)
        }
        Runtime.getRuntime().exit(0)
    }

    private fun queryDisplayName(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "imported_${System.currentTimeMillis()}.txt"
        } catch (e: Exception) {
            "imported_${System.currentTimeMillis()}.txt"
        }

    /** UTF-8 优先，解出乱码（U+FFFD）时退回 GBK */
    private fun decodeText(bytes: ByteArray): String {
        val utf8 = String(bytes, Charsets.UTF_8)
        if (!utf8.contains('\uFFFD')) return utf8.removePrefix("\uFEFF")
        return try {
            String(bytes, Charset.forName("GBK"))
        } catch (e: Exception) {
            utf8
        }
    }

    // ---------- Tab ----------
    var tab by mutableIntStateOf(0)

    // ---------- 首页折叠（原型默认全部折叠，含科目与 Day） ----------
    val openSubjects = mutableStateListOf<Int>()
    val openDays = mutableStateListOf<String>()
    fun key(si: Int, di: Int) = "$si#$di"

    fun toggleSubject(si: Int) {
        if (openSubjects.contains(si)) openSubjects.remove(si) else openSubjects.add(si)
    }
    fun toggleDay(si: Int, di: Int) {
        val k = key(si, di)
        if (openDays.contains(k)) {
            openDays.remove(k)
        } else {
            // 手风琴：展开一个 Day 时折起其他已展开的（「全部展开」按钮不受影响）
            openDays.clear()
            openDays.add(k)
        }
    }

    /** 是否处于「全部展开」态（按钮文案随此变化） */
    val allExpanded: Boolean
        get() = openSubjects.size == tree.size && openDays.size == tree.sumOf { it.day.size }

    fun expandAll(open: Boolean) {
        openSubjects.clear()
        openDays.clear()
        if (open) {
            tree.indices.forEach { openSubjects.add(it) }
            tree.forEachIndexed { si, sj ->
                sj.day.indices.forEach { di -> openDays.add(key(si, di)) }
            }
        }
    }
    fun isSubjectOpen(si: Int) = openSubjects.contains(si)
    fun isDayOpen(si: Int, di: Int) = openDays.contains(key(si, di))

    /** 未开始的 Day（TREE 里没有数据、只有编号）也允许折叠展开，同样手风琴 */
    fun isDayOpen(si: Int, dayName: String) = openDays.contains("$si@$dayName")
    fun toggleEmptyDay(si: Int, dayName: String) {
        val k = "$si@$dayName"
        if (openDays.contains(k)) {
            openDays.remove(k)
        } else {
            openDays.clear()
            openDays.add(k)
        }
    }

    // ---------- 进度：按论述题记录 done / correct ----------
    private val doneMap = mutableStateMapOf<String, Int>()
    private val correctMap = mutableStateMapOf<String, Int>()

    /** 被真实答题改过的论述题（未改过的直接用原型种子里的 acc0，保证初始态与原型的取整完全一致） */
    private val touchedBig = mutableStateMapOf<String, Boolean>()

    init {
        tree.forEachIndexed { si, sj ->
            sj.day.forEachIndexed { di, d ->
                d.big.forEachIndexed { bi, b ->
                    doneMap[bigIdAt(si, di, bi)] = b.done0
                }
            }
        }
    }

    private fun doneOf(k: String) = doneMap[k] ?: 0
    private fun correctOf(k: String) = correctMap[k] ?: 0

    fun statBig(si: Int, di: Int, bi: Int): Stats {
        val b = tree[si].day[di].big[bi]
        val k = bigIdAt(si, di, bi)
        val done = doneOf(k)
        val cor = correctOf(k)
        // 未作答时为 0；未被动过时直接用种子 acc0（避免 round(cor*100/done) 的二次取整偏差，
        // 例如原型 12/30@76 —— 用计数反推会算成 77）；动过之后才按真实计数算。
        val acc = when {
            done == 0 -> 0
            touchedBig[k] != true -> b.acc0
            else -> (cor * 100.0 / done).roundToInt()
        }
        return Stats(
            done = done, total = b.total, bigs = 1,
            started = if (done > 0) 1 else 0,
            correct = cor,
            acc = acc,
            pct = if (b.total > 0) (done * 100.0 / b.total).roundToInt() else 0,
        )
    }

    fun statDay(si: Int, di: Int): Stats {
        val d = tree[si].day[di]
        var done = 0; var total = 0; var cor = 0; var started = 0
        var accW = 0
        d.big.indices.forEach { bi ->
            val s = statBig(si, di, bi)
            done += s.done; total += s.total; cor += s.correct; started += s.started
            // 原型 statDay：accW += b.acc*b.done，最后 round(accW/done)
            // —— 用**各论述题已取整的 acc** 加权，与原型逐位一致
            accW += s.acc * s.done
        }
        return Stats(
            done = done, total = total, bigs = d.big.size, started = started, correct = cor,
            acc = if (done > 0) (accW.toDouble() / done).roundToInt() else 0,
            pct = if (total > 0) (done * 100.0 / total).roundToInt() else 0,
        )
    }

    fun statSj(si: Int): Stats {
        val sj = tree[si]
        var done = 0; var total = 0; var cor = 0; var bigs = 0; var started = 0
        var accW = 0
        sj.day.indices.forEach { di ->
            val s = statDay(si, di)
            done += s.done; total += s.total; cor += s.correct; bigs += s.bigs; started += s.started
            // 原型 statSj：accW += s.acc*s.done（s 为 Day 级、已取整的 acc）
            accW += s.acc * s.done
        }
        return Stats(
            done = done, total = total, bigs = bigs, started = started, correct = cor,
            acc = if (done > 0) (accW.toDouble() / done).roundToInt() else 0,
            pct = if (total > 0) (done * 100.0 / total).roundToInt() else 0,
        )
    }

    // ---------- 全局统计 ----------
    // 2026-09-22 起全部从 0 开始：换真题后不再沿用原型的演示数字（累计 2847 题、正确率 86% 那些）。
    // 单一事实来源是下面的 dayStats（按日账本，落盘为 progress.tsv 的 H 行）；
    // 首页/分析页的所有数字都从它派生，不再有「今日/本周独立计数器 + 跨天清零」的双份账。
    private class DayStat {
        var ans = 0
        var cor = 0
        var secs = 0
    }

    /** key = yyyyMMdd。LinkedHashMap 保持插入序，只影响落盘行序，取数全按日期键 */
    private val dayStats = LinkedHashMap<String, DayStat>()

    var totalAnswered by mutableIntStateOf(0)
        private set
    var totalCorrect by mutableIntStateOf(0)
        private set
    var todayCount by mutableIntStateOf(0)
        private set
    var weekCount by mutableIntStateOf(0)
        private set
    var weekWrong by mutableIntStateOf(0)
        private set
    var killedCount by mutableIntStateOf(0)
        private set
    var favCount by mutableIntStateOf(0)
        private set

    /** 本周 / 累计用时（秒）；分析页「本周用时 / 累计用时」 */
    var weekSecs by mutableIntStateOf(0)
        private set
    var totalSecs by mutableIntStateOf(0)
        private set

    /** 正确率环比：本周正确率 - 上周正确率（百分点，可负） */
    var accDelta by mutableIntStateOf(0)
        private set

    private fun dayStamp(c: Calendar = Calendar.getInstance()): String =
        "%04d%02d%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))

    /** 距今天 offset 天的日期戳（offset=0 就是今天，-1 是昨天） */
    private fun dayAt(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_MONTH, offset)
        return dayStamp(c)
    }

    private fun entryToday(): DayStat = dayStats.getOrPut(dayStamp()) { DayStat() }

    /** dayStats 变了就整体重算一遍派生量（条目数 = 学习过的天数，量级很小，随便算） */
    private fun recomputeCounters() {
        var ta = 0
        var tc = 0
        var ts = 0
        dayStats.values.forEach { ta += it.ans; tc += it.cor; ts += it.secs }
        totalAnswered = ta
        totalCorrect = tc
        totalSecs = ts
        todayCount = dayStats[dayStamp()]?.ans ?: 0

        var wa = 0
        var wc = 0
        var ws = 0
        for (i in 0 until 7) {
            dayStats[dayAt(-i)]?.let { wa += it.ans; wc += it.cor; ws += it.secs }
        }
        weekCount = wa
        weekWrong = wa - wc
        weekSecs = ws

        // 上周（day-13 .. day-7）的正确率，用于环比
        var pa = 0
        var pc = 0
        for (i in 7 until 14) {
            dayStats[dayAt(-i)]?.let { pa += it.ans; pc += it.cor }
        }
        accDelta = when {
            wa == 0 && pa == 0 -> 0
            pa == 0 -> 100 // 上周没做题，本周开张了就按 +100 显示，避免除零
            else -> (wc * 100.0 / wa).roundToInt() - (pc * 100.0 / pa).roundToInt()
        }
    }

    /** confirm() 里首次判分时记账 */
    private fun recordAnswer(right: Boolean) {
        val e = entryToday()
        e.ans++
        if (right) e.cor++
        recomputeCounters()
    }

    // ---------- 分析页取数（全部来自按日历史） ----------

    private fun parseStamp(stamp: String): Calendar {
        val c = Calendar.getInstance()
        c.set(
            stamp.substring(0, 4).toInt(),
            stamp.substring(4, 6).toInt() - 1,
            stamp.substring(6, 8).toInt(),
            0, 0, 0,
        )
        c.set(Calendar.MILLISECOND, 0)
        return c
    }

    private fun daysBetween(fromStamp: String, toStamp: String): Int =
        ((parseStamp(toStamp).timeInMillis - parseStamp(fromStamp).timeInMillis) / 86400000L).toInt()

    private fun shiftStamp(stamp: String, days: Int): String {
        val c = parseStamp(stamp)
        c.add(Calendar.DAY_OF_MONTH, days)
        return dayStamp(c)
    }

    /** "M/d" 形式的短日期（原型 X 轴 / 日历刻度的写法） */
    private fun shortDate(stamp: String): String =
        "${stamp.substring(4, 6).toInt()}/${stamp.substring(6, 8).toInt()}"

    /** 首次刷题的日期（yyyyMMdd），一天都没学过返回 null */
    fun firstStudyStamp(): String? = dayStats.entries.filter { it.value.ans > 0 }.minOfOrNull { it.key }

    /**
     * 历史正确率折线采样：(X 轴标签, 截至该日的累计正确率)。
     * 从首刷日到今天均匀取 ≤7 个点（不足 7 天就一天一个点）；没有记录返回空表。
     * 最后一个点的标签固定是「至今」（同原型）。
     */
    fun trendSamples(): List<Pair<String, Int>> {
        val first = firstStudyStamp() ?: return emptyList()
        val n = daysBetween(first, dayStamp()) + 1
        val offsets = if (n >= 7) {
            (0 until 7).map { Math.round(it * (n - 1) / 6.0).toInt() }
        } else {
            (0 until n).toList()
        }
        // 截至某日的累计正确率：把日期键 <= 该日的账全部加起来（yyyyMMdd 字符串可直接比较）
        return offsets.map { off ->
            val stamp = shiftStamp(first, off)
            var a = 0
            var c = 0
            dayStats.forEach { (k, e) ->
                if (k <= stamp) { a += e.ans; c += e.cor }
            }
            val label = if (stamp == dayStamp()) "至今" else shortDate(stamp)
            label to if (a > 0) (c * 100.0 / a).roundToInt() else 0
        }
    }

    /**
     * 打卡日历：**当月日历**（2026-09-22 反馈：不再显示滚动 35 天窗口）。
     * 周一起始，从包含本月 1 号的那一周到包含本月最后一天的那一周；
     * 行首标签 = 该行周一的 M/d；跨月格子与未来日期没有数据，按 0（浅底）画。
     */
    fun calendarWeeks(): List<Pair<String, List<Int>>> {
        val today = Calendar.getInstance()
        val monthPrefix = "%04d%02d".format(today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1)
        // 本月最后一天：判断「包含月末的那一周」也要画出来
        val last = (today.clone() as Calendar).apply {
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
        }
        val c = (today.clone() as Calendar).apply {
            set(Calendar.DAY_OF_MONTH, 1)
            while (get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) add(Calendar.DAY_OF_MONTH, -1)
        }
        val weeks = mutableListOf<Pair<String, List<Int>>>()
        while (c.timeInMillis <= last.timeInMillis) {
            val counts = (0 until 7).map { o ->
                val d = (c.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, o) }
                val st = dayStamp(d)
                if (st.startsWith(monthPrefix)) dayStats[st]?.ans ?: 0 else 0
            }
            weeks.add(shortDate(dayStamp(c)) to counts)
            c.add(Calendar.DAY_OF_MONTH, 7)
        }
        return weeks
    }

    // ---------- 错题本：条目/计数以「选择题」为单位，消灭以「论述题整题全对满 3 次」为依据 ----------
    // （2026-09-22 老高拍板：错题本里一条 = 一道答错的选择题；但消灭不看单题，
    //   看它所在论述题整题全对的次数，满 3 次把这批错题一起清掉）

    /** key = 题目稳定 ID（qidOfQ），value = 它所在论述题当前的整题全对次数（满 3 次消灭这道题） */
    private val wrongQ = mutableStateMapOf<String, Int>()

    /** 显示顺序（首次答错的插入序；落盘 W 行和列表渲染都走它） */
    private val wrongQOrder = mutableStateListOf<String>()

    /** 题干原文（稳定 ID 里只有指纹，行渲染要显示题干，单独存一份） */
    private val wrongQStem = mutableStateMapOf<String, String>()

    /** 论述题整题全对次数（消灭时钟）。内存态：重启后从 W 行按论述题取 max 重建 */
    private val bigKill = mutableMapOf<String, Int>()

    /** 待消灭错题（选择题数） */
    val wrongLeft: Int get() = wrongQ.size

    /** 错题本里全部题目下标（按首次答错的插入顺序） */
    fun wrongQAll(): List<Int> = wrongQOrder.mapNotNull { qidToIdx[it] }

    /** 某道错题已累计的答对次数 */
    fun wrongKillOf(qi: Int): Int = wrongQ[qidOfQ.getOrNull(qi).orEmpty()] ?: 0

    /** 错题本：某科目的错题（选择题）数 */
    fun wrongCountOfSubject(short: String): Int =
        wrongQAll().count { qi -> bigOf(qi)?.let { tree[it.first].short } == short }

    val favIds = mutableStateListOf<Int>()

    /** 收藏总数（原型 S.favBase + favQids.length） */
    val favTotal: Int get() = favCount

    /**
     * 题本页收藏预览 chips（对应原型 renderBookExtras 的 fav-chips）：
     * 有真实收藏时取最近 3 道题的论述题名；没有收藏时给 3 个 ghost 演示 chip。
     */
    fun favChipNames(): List<Pair<String, Boolean>> {
        if (favIds.isNotEmpty()) {
            return favIds.takeLast(3).reversed().map { id ->
                val q = quiz[id]
                val big = q.kp.getOrNull(1)?.trim('「', '」').orEmpty()
                (big.ifBlank { q.src.split(" · ").last() }) to false
            }
        }
        return listOf(
            "量变质变规律" to true,
            "十个明确" to true,
            "新民主主义革命的总路线" to true,
        )
    }

    fun toggleFav(qid: Int) {
        if (favIds.contains(qid)) { favIds.remove(qid); favCount-- } else { favIds.add(qid); favCount++ }
    }

    // ---------- 答题会话 ----------
    var scope: Scope? by mutableStateOf(null)
        private set

    /**
     * 本次会话的**原始**入口文案（对应原型 pendingTopic / quizTopic）。
     * 原型不重拼标题，而是把入口串原样留用，所以结果页会看到
     * 「背诵全文 · 继续上次背诵 · 马原 · Day1」这种带入口前缀的标题。
     */
    var sessionTopic by mutableStateOf("")
        private set

    var quizVisible by mutableStateOf(false)
        private set
    var resultVisible by mutableStateOf(false)
        private set
    var qSet: List<Int> by mutableStateOf(emptyList())
        private set
    var qIdx by mutableIntStateOf(0)
        private set
    val answers = mutableStateMapOf<Int, AnswerRec>()
    var seconds by mutableIntStateOf(0)
        private set

    /** 最近答过题的论述题 —— 首页「继续上次背诵」卡的落点 */
    var lastBig by mutableStateOf<Triple<Int, Int, Int>?>(null)
        private set

    /** 从 progress.tsv 捞回来、还没被接管的会话存档（点了「继续上次背诵」才会灌进真正的会话状态） */
    private var savedSession: SavedSession? = null
    var autoNextToken by mutableIntStateOf(0)
        private set

    /**
     * 一次性自动跳题信号（背题模式答对 0.8s 后跳下一题）。
     * 注意不要用 lastAnswerRight 直接判断：goNext/goPrev/jumpTo 也会自增
     * autoNextToken，若只看 lastAnswerRight，跳题会把自己再次触发，
     * 导致连续跳过题目。这里由 answerReveal 置位、界面消费后立即清除。
     */
    var pendingAutoNext by mutableStateOf(false)
        private set

    fun consumeAutoNext(): Boolean {
        val v = pendingAutoNext
        if (v) pendingAutoNext = false
        return v
    }

    /** answerReveal 记下的作答题位；autoAdvance 用它判断用户是否已手动移动 */
    private var autoAdvanceFrom = -1

    /** 自动跳题的执行端（答题页 delay 800ms 后调用）。用户手动移动过题位就不跳 */
    fun autoAdvance() {
        val from = autoAdvanceFrom
        autoAdvanceFrom = -1
        if (from == -1 || qIdx != from) return
        goNext()
    }

    var lastAnswerRight by mutableStateOf(false)
        private set

    /**
     * 每秒一次：会话计时 +1，同时把这一秒记进当天的用时账。
     * 落盘不用每秒都做 —— 每 15 秒随 persist() 刷一次；被杀进程最多丢最后十几秒的用时统计，
     * 答题进度本身在每个 confirm/exit 都已落盘。
     */
    fun tick() {
        seconds++
        entryToday().secs++
        recomputeCounters()
        if (seconds % 15 == 0) persist()
    }

    /** 某题所属的论述题（装载时一次性建好的表，不再现扫 TREE） */
    fun bigOf(id: Int): Triple<Int, Int, Int>? = bigOfQ.getOrNull(id)

    /** 某论述题对应的全部题目下标 */
    fun qidsOfBig(si: Int, di: Int, bi: Int): List<Int> =
        qidsByBig[bigIdAt(si, di, bi)] ?: emptyList()

    /** 某范围对应的全部题目下标 */
    fun questionIdsOf(scope: Scope): List<Int> = when (scope.kind) {
        ScopeKind.BIG -> qidsOfBig(scope.si, scope.di, scope.bi)
        ScopeKind.DAY -> qidsByDay["${scope.si}#${scope.di}"] ?: emptyList()
        ScopeKind.SUBJECT -> qidsBySubj[scope.si] ?: emptyList()
        ScopeKind.FAV -> quiz.indices.filter { favIds.contains(it) }
        ScopeKind.WRONG_ALL -> quiz.indices.filter { i -> wrongQ.containsKey(qidOfQ.getOrNull(i).orEmpty()) }
        ScopeKind.SINGLE -> listOfNotNull(scope.si.takeIf { it in quiz.indices })
        ScopeKind.ALL -> quiz.indices.toList()
    }

    /** 本次会话是否为背题模式（= 设置页的全局模式，或入口显式指定背题） */
    var backMode by mutableStateOf(false)
        private set

    /** 本次会话中「刚作答」的题位；-1 = 当前题是翻回来重看的。 */
    var justAnsweredPos by mutableIntStateOf(-1)
        private set

    /** 每题选项的展示顺序（存原始下标）。未乱序时为空，回退到原始顺序。 */
    private val optOrder = mutableStateMapOf<Int, List<Int>>()

    /** 取某题在当前会话中的选项展示顺序 */
    fun orderOf(pos: Int, size: Int): List<Int> = optOrder[pos] ?: (0 until size).toList()

    var toastText by mutableStateOf("")
        private set
    var toastSeq by mutableIntStateOf(0)
        private set
    private fun showToast(s: String) { toastText = s; toastSeq++ }

    /** 未开始的 Day：原型 scopeHit 命中不到题目时只弹提示，不进入答题 */
    fun startEmptyDay() { showToast("本 Day 还没有录入题目") }

    fun startQuiz(scope: Scope, back: Boolean = false, topic: String? = null) {
        var eff = scope
        var ids = questionIdsOf(eff)
        if (ids.isEmpty() && eff.kind == ScopeKind.BIG) {
            eff = Scope(ScopeKind.DAY, scope.si, scope.di)
            ids = questionIdsOf(eff)
            if (ids.isEmpty()) eff = Scope(ScopeKind.SUBJECT, scope.si).also { ids = questionIdsOf(it) }
        } else if (ids.isEmpty() && eff.kind == ScopeKind.DAY) {
            eff = Scope(ScopeKind.SUBJECT, scope.si)
            ids = questionIdsOf(eff)
        }
        if (ids.isEmpty()) {
            showToast("这个范围还没有录入题目")
            return
        }
        this.scope = eff
        sessionTopic = topic ?: eff.title()
        // 答题模式（背题/测验）跟随设置页的全局 quizMode —— 题库页的「背题模式」入口已删（2026-09-22）
        backMode = quizMode == "back"
        beginSession(ids)
    }

    /** 开始一轮练习：重置会话状态（同原型 beginQuiz 里那段复位） */
    private fun beginSession(ids: List<Int>) {
        qSet = ids
        qIdx = 0
        answers.clear()
        counted.clear()
        bigProgress.clear()
        optOrder.clear()
        if (optShuffle) {
            // 只打乱展示顺序，判分仍按原始下标（与原型 "仅打乱展示顺序，判分仍按原始下标" 一致）
            qSet.forEachIndexed { pos, id -> optOrder[pos] = quiz[id].opts.indices.shuffled() }
        }
        seconds = 0
        pendingAutoNext = false
        autoAdvanceFrom = -1
        justAnsweredPos = -1
        autoNextToken++
        roundOver = false
        finishPrompt = false
        quizVisible = true
        resultVisible = false
        Log.d(TAG, "beginSession size=%d mode=%s shuffle=%b" .format(qSet.size, if (backMode) "back" else "test", optShuffle))
    }

    /** 只练错题：把本组答错的题抽出来重练（同原型 retryWrong） */
    fun retryWrong() {
        val ids = qSet.filterIndexed { pos, _ ->
            val r = answers[pos]
            r != null && r.confirmed && !r.right
        }
        if (ids.isEmpty()) {
            showToast("本组没有错题 🎉")
            return
        }
        beginSession(ids)
    }

    val currentQuestion: Question?
        get() = qSet.getOrNull(qIdx)?.let { quiz.getOrNull(it) }

    /** 首次判分记账：论述题进度 / 按日账本 / 错题本。返回是否首次（false = 重复记账跳过） */
    private fun recordJudged(pos: Int): Boolean {
        val rec = answers[pos] ?: return false
        if (!counted.add(pos)) return false
        val t = bigOf(qSet[pos])
        if (t != null) {
            lastBig = t
            val k = bigIdAt(t.first, t.second, t.third)
            doneMap[k] = (doneMap[k] ?: 0) + 1
            if (rec.right) correctMap[k] = (correctMap[k] ?: 0) + 1
            touchedBig[k] = true
        }
        recordAnswer(rec.right)
        // 错题本以「选择题」记账，消灭以「论述题整题全对满 3 次」为依据（2026-09-22 老高拍板）
        val qkey = qidOfQ.getOrNull(qSet[pos])
        val tBig = bigOf(qSet[pos])
        if (qkey != null && tBig != null) {
            val bkey = bigIdAt(tBig.first, tBig.second, tBig.third)
            if (rec.right) recordBigRightQ(bkey, qkey)
            else markQWrong(bkey, qkey, quiz[qSet[pos]].text)
        }
        return true
    }

    /**
     * 背题模式：点选项作答 = **立即判分**并显示答案与解析（2026-09-22 二次定义）。
     * 对就是对、错就是错：真实计入今日题数/正确率/论述题进度/错题本。
     * 答对 0.8s 自动下一题（pendingAutoNext 信号）；答错停留原地读解析。
     */
    fun answerReveal(optIdx: Int) {
        val pos = qIdx
        if (!backMode) { Log.d(TAG, "ansReveal IGNORE mode!=back pos=$pos"); return }
        if (answers[pos]?.confirmed == true) { Log.d(TAG, "ansReveal IGNORE alreadyConfirmed pos=$pos"); return }
        val id = qSet.getOrNull(pos) ?: run { Log.d(TAG, "ansReveal IGNORE badPos pos=$pos"); return }
        answers[pos] = AnswerRec(optIdx, quiz[id].ans == optIdx, confirmed = true)
        recordJudged(pos)
        lastAnswerRight = answers[pos]!!.right
        justAnsweredPos = pos
        autoAdvanceFrom = pos
        pendingAutoNext = lastAnswerRight && pos < qSet.lastIndex
        autoNextToken++
        Log.d(TAG, "ansReveal pos=$pos opt=$optIdx right=%b auto=%b" .format(lastAnswerRight, pendingAutoNext))
        persist()
    }

    /**
     * 测验模式：点选项只做标记（可改选），**不判分、不显示答案**。
     * 交卷时由 [submitExam] 统一算分。
     */
    fun selectExam(optIdx: Int) {
        val pos = qIdx
        if (backMode) { Log.d(TAG, "selExam IGNORE mode==back pos=$pos"); return }
        if (answers[pos]?.confirmed == true) { Log.d(TAG, "selExam IGNORE alreadyConfirmed pos=$pos"); return }
        val id = qSet.getOrNull(pos) ?: run { Log.d(TAG, "selExam IGNORE badPos pos=$pos"); return }
        answers[pos] = AnswerRec(optIdx, quiz[id].ans == optIdx, confirmed = false)
        persist()
    }

    /** 测验模式 · 交卷：所有已选中的题统一判分记账；还有没作答的题先弹确认（2026-09-23） */
    fun submitExam() {
        if (backMode) return
        qSet.indices.forEach { pos ->
            val rec = answers[pos] ?: return@forEach
            if (rec.confirmed) return@forEach
            answers[pos] = rec.copy(confirmed = true)
            recordJudged(pos)
        }
        justAnsweredPos = -1
        persist()
        askFinishOrDone()
    }

    private val counted = mutableSetOf<Int>()

    /** 本轮里「某论述题已答对」的题目**稳定 ID** 集合，用于判断整题是否全对（对应原型 wrongBig[key].p） */
    private val bigProgress = mutableStateMapOf<String, MutableSet<String>>()

    /** 答错 → 这道选择题进错题本（计数 = 它所在论述题当前的整题全对次数），本轮全对进度清零。
     *  ⚠️ 必须同时登记 wrongQOrder / wrongQStem —— 落盘（snapshot.wrongs）和列表渲染都走 wrongQOrder，
     *  只写 wrongQ 的话错题会在下次落盘/重启时凭空消失（2026-09-22 自动化测试抓到的 bug）。 */
    private fun markQWrong(bkey: String, qkey: String, stem: String) {
        if (!wrongQ.containsKey(qkey)) wrongQ[qkey] = bigKill[bkey] ?: 0
        if (!wrongQOrder.contains(qkey)) wrongQOrder.add(qkey)
        if (wrongQStem[qkey] == null) wrongQStem[qkey] = stem
        bigProgress[bkey] = mutableSetOf()
    }

    /**
     * 答对 → 记本题本轮进度；所在论述题**整题全部答对**算 1 次（消灭时钟 +1），
     * 累计 3 次 = 消灭该论述题下的所有错题条目（每道题各计 1 个「已消灭」，三张表一起摘，防幽灵条目）。
     */
    private fun recordBigRightQ(bkey: String, qkey: String) {
        val qs = qidsByBig[bkey] ?: emptyList()
        val hasWrong = qs.any { wrongQ.containsKey(qidOfQ.getOrNull(it).orEmpty()) }
        if (!hasWrong && bigKill[bkey] == null) return
        val set = bigProgress.getOrPut(bkey) { mutableSetOf() }
        set.add(qkey)
        if (qs.isEmpty() || !qs.all { qidOfQ.getOrNull(it)?.let { s -> s in set } == true }) return
        val n = (bigKill[bkey] ?: 0) + 1
        bigProgress[bkey] = mutableSetOf()
        if (n >= 3) {
            qs.forEach { qi ->
                val k = qidOfQ.getOrNull(qi) ?: return@forEach
                if (wrongQ.containsKey(k)) {
                    wrongQ.remove(k)
                    wrongQOrder.remove(k)
                    wrongQStem.remove(k)
                    killedCount++
                }
            }
            bigKill.remove(bkey)
        } else {
            bigKill[bkey] = n
            qs.forEach { qi ->
                val k = qidOfQ.getOrNull(qi) ?: return@forEach
                if (wrongQ.containsKey(k)) wrongQ[k] = n
            }
        }
    }

    val allAnswered: Boolean get() = qSet.indices.all { answers[it]?.confirmed == true }
    val answeredCount: Int get() = answers.values.count { it.confirmed }
    val answeredRight: Int get() = answers.values.count { it.confirmed && it.right }
    val answeredWrong: Int get() = answers.values.count { it.confirmed && !it.right }

    fun goPrev() {
        if (qIdx > 0) { qIdx--; justAnsweredPos = -1; autoNextToken++; persist() }
    }

    fun goNext() {
        if (qIdx < qSet.lastIndex) {
            qIdx++; justAnsweredPos = -1; autoNextToken++; persist()
        } else if (backMode) {
            // 背题模式翻完末题收尾（有未作答会先弹确认）；测验模式必须走「交卷」统一算分
            askFinishOrDone()
        }
    }

    fun jumpTo(pos: Int) {
        if (pos in qSet.indices) { qIdx = pos; justAnsweredPos = -1; autoNextToken++; persist() }
    }

    fun finishToResult() {
        roundOver = true
        quizVisible = false
        resultVisible = true
        persist()
    }

    // ---------- 收尾确认（2026-09-23 老高：有未作答题先提示；不返回则全部按答错记账） ----------

    /** 完成/交卷时还有没作答的题 → 弹确认框 */
    var finishPrompt by mutableStateOf(false)
        private set

    /** 弹框里提示的未作答题数 */
    var finishUnanswered by mutableIntStateOf(0)
        private set

    /** 一轮已收尾（结果页开着）：会话不再算「可续答」，快照里也不再写会话行——
     *  下次进来同一论述题是干净的未作答状态，而不是复活上一轮的完成态 */
    private var roundOver = false

    private fun askFinishOrDone() {
        val n = qSet.indices.count { answers[it] == null }
        if (n > 0) {
            finishUnanswered = n
            finishPrompt = true
            return
        }
        doFinish()
    }

    /** 弹框选择：goBack=true 返回继续作答；false=未作答的全部按答错记账后收尾 */
    fun resolveFinish(goBack: Boolean) {
        finishPrompt = false
        if (goBack) return
        qSet.indices.forEach { pos ->
            if (answers[pos] == null) {
                // 没作的题按答错记账：论述题进度/按日账本/错题本都走 recordJudged，与真实答错完全一致
                answers[pos] = AnswerRec(-1, right = false, confirmed = true)
                recordJudged(pos)
            }
        }
        persist()
        doFinish()
    }

    /**
     * 一轮作答收尾：
     * ① **作答状态归零**——本轮覆盖的论述题 doneMap/correctMap 清回「未作答」，
     *    题库页/首页进度重新显示未开始，同一论述题可以再次作答（2026-09-23 老高拍板：
     *    作答记录分两部分，第一部分=答题界面的作答状态，完成即重置；第二部分=正确率/
     *    答题数量/错题这些历史数据，保留且**每次作答都全额累计**——同一论述题 30 题做两遍，
     *    做题总量 +60，历史只算「做的题」，不按题去重）；
     * ② 收尾跳转：背题模式直接退出，测验模式进结果页看对错统计。
     */
    private fun doFinish() {
        qSet.mapNotNull { bigOf(it) }.distinct().forEach { (si, di, bi) ->
            val k = bigIdAt(si, di, bi)
            doneMap[k] = 0
            correctMap[k] = 0
            touchedBig.remove(k)
        }
        if (backMode) {
            showToast("背题完成 ✍️ 换测验模式检验一下记忆吧")
            // 背题模式没有结果页：直接清掉会话回到答题前的页面，
            // 不留「已完成」的续答卡（2026-09-23：完成后的作答状态重置为未作答）
            quizVisible = false
            clearRound()
            persist()
        } else {
            finishToResult()
        }
    }

    /**
     * 关掉结果页 = 这一轮算收尾了，把会话清空：
     * 下次启动的「继续上次背诵」就回落到「最近答过的那道论述题」，
     * 而不是又弹出一个「上次做到 156/156 题」的续答卡。
     */
    fun closeResult() {
        resultVisible = false
        tab = 0
        clearRound()
        persist()
    }

    /** 清空当前会话（关闭结果页 / 背题模式一轮收尾时调用） */
    private fun clearRound() {
        scope = null
        qSet = emptyList()
        answers.clear()
        counted.clear()
        bigProgress.clear()
        optOrder.clear()
        sessionTopic = ""
        seconds = 0
        savedSession = null
        pendingAutoNext = false
        autoAdvanceFrom = -1
        roundOver = false
        finishPrompt = false
    }

    /** 中途退出答题：**保留**会话（下次从「继续上次背诵」接着答） */
    fun exitQuiz() {
        quizVisible = false
        resultVisible = false
        roundOver = false
        pendingAutoNext = false
        autoAdvanceFrom = -1
        persist()
    }

    /**
     * 首页「继续 / 开始背诵」卡，三种情况按优先级：
     *
     * 1. **当前还留着会话**（答题中途按返回键退出、或刚杀进程启动后捞到存档）
     *    → 出续答卡，点进去回到原来的题目表、原题位、已答记录都在；
     * 2. 没有会话，但有答过题 → 落在最近答过的那道论述题上；
     * 3. 一题都没答过 → 落在马原 Day1 的第一个论述题。题库为空时返回 null（卡片不显示）。
     */
    fun continueCard(): ContinueCard? {
        // -- 1. 续答（一轮已收尾的不算：那轮的作答状态已重置，不该再被复活）
        val live = scope != null && qSet.isNotEmpty() && !roundOver
        if (live) {
            return resumeCard(scope!!, sessionTopic, qSet.size, qIdx, answeredCount)
        }
        savedSession?.let { s ->
            return resumeCard(
                s.scope, s.topic, s.ids.size, s.qIdx,
                s.answers.values.count { it.confirmed },
            )
        }

        // -- 2 / 3. 落到某道论述题
        val t = lastBig ?: run {
            val d0 = tree.firstOrNull()?.day?.firstOrNull() ?: return null
            if (d0.big.isEmpty()) return null
            Triple(0, 0, 0)
        }
        val (si, di, bi) = t
        val day = tree.getOrNull(si)?.day?.getOrNull(di) ?: return null
        val big = day.big.getOrNull(bi) ?: return null
        val s = statBig(si, di, bi)
        val started = s.done > 0
        val short = tree[si].short
        return ContinueCard(
            title = if (started) "继续上次背诵 · $short" else "开始背诵 · $short",
            day = day.name,
            sub = "${day.name} · 论述题「${big.title}」",
            pct = s.pct,
            footPre = if (started) "上次做到 " else "共 ",
            footNum = if (started) "${s.done}/${big.total}" else "${big.total}",
            footSuffix = if (started) " 题" else " 道题",
            scope = Scope(ScopeKind.BIG, si, di, bi),
        )
    }

    /** 续答卡的内容：题目表长度、当前题位、已答数都由存档给，不再从论述题进度推 */
    private fun resumeCard(sc: Scope, topic: String, total: Int, at: Int, done: Int): ContinueCard {
        val short = tree.getOrNull(sc.si)?.short.orEmpty()
        val dayName = when (sc.kind) {
            ScopeKind.BIG, ScopeKind.DAY -> tree.getOrNull(sc.si)?.day?.getOrNull(sc.di)?.name.orEmpty()
            else -> ""
        }
        val sub = sc.title()
        return ContinueCard(
            title = "继续上次背诵 · $short",
            day = dayName,
            sub = sub,
            pct = if (total > 0) (done * 100.0 / total).roundToInt() else 0,
            footPre = "上次做到 ",
            footNum = "${(at + 1).coerceAtMost(total)}/$total",
            footSuffix = " 题",
            scope = sc,
            resume = true,
        )
    }

    /**
     * 点续答卡：把上次那一轮原样接回来（题目表 / 题位 / 已答 / 计时 / 背题模式）。
     * 会话还在内存里（中途退出答题）时只是把界面切回去。
     */
    fun resumeSession() {
        if (scope == null || qSet.isEmpty()) {
            val s = savedSession ?: return
            scope = s.scope
            sessionTopic = s.topic
            // 模式跟随设置页当前全局模式（2026-09-22 二次定义）：用户切了模式，续答按新模式走
            backMode = quizMode == "back"
            qSet = s.ids
            qIdx = s.qIdx
            answers.clear()
            answers.putAll(s.answers)
            counted.clear()
            counted.addAll(s.counted)
            bigProgress.clear()
            s.bigProgress.forEach { (k, v) -> bigProgress[k] = v.toMutableSet() }
            optOrder.clear()
            optOrder.putAll(s.optOrder)
            seconds = s.seconds
            // 上次停在结果页的，就把结果页一并还原
            quizVisible = !s.resultPhase
            resultVisible = s.resultPhase
            savedSession = null
        } else {
            quizVisible = true
            resultVisible = false
        }
        justAnsweredPos = -1
        lastAnswerRight = false
        autoNextToken++
        persist()
    }

    // ---------- 题库页 ----------
    var bankQuery by mutableStateOf("")
    var bankSubject by mutableIntStateOf(0)

    /** 题库页搜索：只匹配论述题标题（同原型 SEARCH_POOL 的 title.indexOf） */
    fun searchHits(): List<Triple<Int, Int, Int>> {
        val q = bankQuery.trim()
        if (q.isEmpty()) return emptyList()
        val out = mutableListOf<Triple<Int, Int, Int>>()
        tree.forEachIndexed { si, sj ->
            sj.day.forEachIndexed { di, d ->
                d.big.forEachIndexed { bi, b ->
                    if (b.title.contains(q)) out.add(Triple(si, di, bi))
                }
            }
        }
        return out
    }

    fun searchResults(): List<Int> {
        val q = bankQuery.trim()
        return quiz.indices.filter { i ->
            val item = quiz[i]
            val subj = tree.getOrNull(bankSubject)
            val hitSubj = subj == null || item.kp.getOrNull(0)?.startsWith(subj.short + " · ") == true
            val hitText = q.isEmpty() || item.text.contains(q) || item.kp.joinToString(" ").contains(q) ||
                item.src.contains(q) || item.root.contains(q)
            hitSubj && hitText
        }
    }

    /** 薄弱论述题：按正确率升序（只取已开始的） */
    fun weakTopics(limit: Int = 4): List<Triple<Int, Int, Int>> {
        val all = mutableListOf<Triple<Int, Int, Int>>()
        tree.forEachIndexed { si, sj ->
            sj.day.forEachIndexed { di, d ->
                d.big.forEachIndexed { bi, _ ->
                    if (statBig(si, di, bi).done > 0) all.add(Triple(si, di, bi))
                }
            }
        }
        all.sortBy { statBig(it.first, it.second, it.third).acc }
        return all.take(limit)
    }

    fun startedDays(si: Int): List<Int> =
        tree[si].day.indices.filter { di -> statDay(si, di).pct > 0 }

    /** 切换科目：默认落在进度最高的那个 Day（与原型的 setSubj 一致） */
    fun selectSubject(si: Int) {
        bankSubject = si
        val sj = tree[si]
        if (sj.day.isEmpty()) { bkDay = "Day${sj.start}"; return }
        var best = 0
        sj.day.indices.forEach { di -> if (statDay(si, di).pct > statDay(si, best).pct) best = di }
        bkDay = sj.day[best].name
    }

    // ---------- 题库页 · 背诵模式（对应原型 bkMode / bkRand / bkDay） ----------
    /** 顺序背诵 / 随机背诵 —— 只管「背什么」；「怎么答」（背题/测验）由设置页全局 quizMode 决定（2026-09-22 反馈：题库页不再出现背题模式入口） */
    var bkMode by mutableStateOf("顺序背诵")
        private set

    /** 随机层级：day = 随机到 Day；big = Day 内随机论述题 */
    var bkRand by mutableStateOf("day")
        private set

    /** 当前选中的 Day 名（对应原型 bkDay —— 存的是名字而非下标，未开始的 Day 也能被选中） */
    var bkDay by mutableStateOf("Day1")
        private set

    fun chooseBkMode(m: String) { bkMode = m }
    fun chooseBkRand(l: String) { bkRand = l }

    /** 当前 Day 对应的节点；未开始的 Day 返回 null（同原型 sj.day.find） */
    fun curDayNode(si: Int = bankSubject): com.gao.recite.data.DayNode? =
        tree[si].day.firstOrNull { it.name == bkDay }

    /** 当前 Day 在 sj.day 里的下标；未开始返回 -1 */
    fun curDayIdx(si: Int = bankSubject): Int =
        tree[si].day.indexOfFirst { it.name == bkDay }

    fun pickDayInDir(day: String) {
        bkDay = day
        showToast("已选择 ${tree[bankSubject].short} · $day")
    }

    /** scope 行是否显示：随机到 Day 时该行隐藏（同原型 updateScopeRow） */
    val scopeRowVisible: Boolean get() = !(bkMode == "随机背诵" && bkRand == "day")

    /** 开始按钮文案，逐字对齐原型 updateStartBtn() */
    fun startBtnLabel(): String {
        val sj = tree[bankSubject]
        return if (bkMode == "随机背诵" && bkRand == "day") "开始 随机背诵 · ${sj.short} · 随机 Day"
        else "开始 $bkMode · ${sj.short} · $bkDay"
    }

    /** 开始背诵：按当前模式落到对应范围（同原型 startCombo，并沿用它的入口文案） */
    fun startCombo() {
        val sj = tree[bankSubject]
        if (bkMode == "随机背诵" && bkRand == "day") {
            startQuiz(
                Scope(ScopeKind.SUBJECT, bankSubject),
                topic = "随机背诵 · 随机 Day · ${sj.short}",
            )
            return
        }
        val di = curDayIdx()
        if (di < 0) { showToast("$bkDay 还没有录入题目"); return }
        val topic = if (bkMode == "随机背诵") {
            "随机背诵 · ${sj.short} · $bkDay · Day 内随机论述题"
        } else {
            "$bkMode · ${sj.short} · $bkDay"
        }
        startQuiz(Scope(ScopeKind.DAY, bankSubject, di), topic = topic)
    }

    // ---------- 覆盖式面板（原型 #daydir / #listdir） ----------
    /** 题单面板：null=关闭；"wrong" 错题本；"fav" 我的收藏；"weakall" 全部薄弱；"topic:i" 单个专题 */
    var listSheet by mutableStateOf<String?>(null)
    var dayDirOpen by mutableStateOf(false)
    /** true=选择 Day（题库 scope 行进入）；false=Day 目录（点行直接开背） */
    var dayDirPick by mutableStateOf(true)
    /** 错题本面板里当前选中的科目简称（对应原型 ldSubj） */
    var listSubj by mutableStateOf<String?>(null)

    fun openList(mode: String) {
        listSheet = mode
        listSubj = null
    }
    fun closeList() { listSheet = null }
    fun chooseListSubj(short: String) { listSubj = short }
    fun openDayDir(pick: Boolean = true) {
        dayDirPick = pick
        dayDirOpen = true
    }
    fun closeDayDir() { dayDirOpen = false }

    /**
     * 错题本：按「科目 · Day」分组的错题（选择题，2026-09-22 起不再按论述题）。
     * 组间按 Day 名字典序，不是插入序（曾因此把 Day3 排在 Day1 前面）。
     */
    fun wrongGrouped(subject: String): List<Pair<String, List<Int>>> {
        val out = linkedMapOf<String, MutableList<Int>>()
        wrongQAll()
            .mapNotNull { qi -> bigOf(qi)?.let { qi to it } }
            .filter { (_, t) -> tree[t.first].short == subject }
            .forEach { (qi, t) -> out.getOrPut(tree[t.first].day[t.second].name) { mutableListOf() }.add(qi) }
        return out.entries.sortedBy { it.key }.map { it.key to it.value.toList() }
    }

    /** 有错题的科目简称（按 TREE 顺序） */
    fun wrongSubjects(): List<String> =
        tree.map { it.short }.filter { s -> wrongCountOfSubject(s) > 0 }

    /** 某个专题面板的标题（对应原型 ldTitle） */
    fun listTitle(): String = when {
        listSheet == null -> ""
        listSheet!!.startsWith("topic:") -> "专题「${topicGroups().getOrNull(listSheet!!.removePrefix("topic:").toInt())?.name ?: ""}」"
        listSheet == "weakall" -> "薄弱论述题 · 全部"
        listSheet == "wrong" -> {
            // 2026-09-22 起错题本以选择题为单位
            val n = wrongLeft
            if (n == 0) "错题本" else "错题本 · $n 道选择题"
        }
        else -> "我的收藏 · $favTotal 题"
    }

    /** 题单面板右上角动作文案（对应原型 ldAction） */
    fun listActionLabel(): String = when {
        listSheet?.startsWith("topic:") == true -> "重练本专题"
        listSheet == "weakall" -> "错题重练"
        listSheet == "wrong" -> "全部重练"
        else -> "开始背诵"
    }

    /** 题单面板右上角动作（对应原型 ldDoAll，入口文案也照抄） */
    fun runListAction() {
        val mode = listSheet ?: return
        closeList()
        when {
            mode.startsWith("topic:") -> {
                val g = topicGroups().getOrNull(mode.removePrefix("topic:").toInt()) ?: return
                val src = g.items.firstOrNull()?.src.orEmpty()
                val scope = scopeFromSrc(src) ?: return
                startQuiz(scope, topic = "错题重练 · 专题「${g.name}」")
            }
            mode == "weakall" || mode == "wrong" -> startQuiz(Scope(ScopeKind.WRONG_ALL), topic = "错题重练 · 全部")
            // 收藏夹入口：按设置页的全局答题模式走
            else -> startQuiz(Scope(ScopeKind.FAV), topic = "我的收藏 $favTotal 题")
        }
    }

    /** 题目/论述题来源串 → 答题范围。找不到该论述题就退回它所在的 Day，再退回整科 */
    fun scopeFromSrc(src: String): Scope? {
        val parts = src.replace("继续上次背诵 · ", "").split(" · ")
        if (parts.size < 2) return null
        val short = parts[0]
        val dayName = parts[1]
        val title = parts.getOrNull(2)?.substringAfter("「")?.substringBefore("」")
        val si = tree.indexOfFirst { it.short == short }
        if (si < 0) return null
        val di = tree[si].day.indexOfFirst { it.name == dayName }
        if (di < 0) return Scope(ScopeKind.SUBJECT, si)
        if (title != null) {
            val bi = tree[si].day[di].big.indexOfFirst { it.title == title }
            if (bi >= 0) return Scope(ScopeKind.BIG, si, di, bi)
        }
        return Scope(ScopeKind.DAY, si, di)
    }

    /** 薄弱专题（对应原型 TOPICS；动态部分取真实薄弱论述题，静态部分照抄演示数据） */
    fun topicGroups(): List<com.gao.recite.data.TopicGroup> = TOPICS

    /**
     * 某专题的平均正确率：原型 renderTopicList 用 `Math.round(Σv/n)`。
     * 注意不能用整数除法 —— 128/3 会被截成 42，原型是 43；32.5 原型取 33（四舍五入）。
     */
    fun topicAvg(g: com.gao.recite.data.TopicGroup): Int =
        if (g.items.isEmpty()) 0 else (g.items.sumOf { it.v }.toDouble() / g.items.size).roundToInt()

    // ---------- 题库页 · Day 目录（对应原型 renderDayList） ----------

    /** 「最近在学」的 Day 下标：只取做过的，最多 3 个 */
    fun recentDayIdx(si: Int): List<Int> =
        tree[si].day.indices.filter { statDay(si, it).done > 0 }.take(3)

    /** scope 行副标题，同原型 updateScopeRow 的 scopeSub 文案 */
    fun scopeSubText(): String {
        val di = curDayIdx()
        val d = curDayNode() ?: return "未开始 · 点击更换 Day"
        val s = statDay(bankSubject, di)
        return "论述题 ${s.started}/${d.big.size} · 选择题 ${s.done}/${s.total} · 正确率 ${s.acc}% · 点击更换 Day"
    }

    // ---------- 结果页文案（对应原型 showResult） ----------

    /** 「背诵全文 · <入口文案>」——原型用的是 quizTopic（不重新拼范围） */
    fun rootTitle(): String = "背诵全文 · " + sessionTopic

    // （「AI 建议」tipText 已按用户要求删除，2026-09-22）

    // ------------------------------------------------------------------ 落盘 / 恢复
    //
    // 题库是**全部内置、分批增量给**的：往 assets/qbank.tsv 追加新 Day、重装 APK 之后，
    // 历史答题数据必须原样对得上。所以落盘里一个数组下标都不用 ——
    //   论述题 → 科目简称 + Day 名 + 论述题标题
    //   题目   → 上面这个串 + 题干（同一论述题里题干重复时再加出现序号）的 SHA-1 前 8 字节
    // 追加新题只会新增键，已有键一个都不会变。

    /** 落盘跑在后台单线程上：写的是完整快照，串行执行天然保证「后写的赢」 */
    private val io = Executors.newSingleThreadExecutor()

    private fun persist() {
        val text = snapshot().encode()
        val app = getApplication<Application>()
        io.execute { ProgressStore.write(app, text) }
    }

    /**
     * 生命周期兜底（Activity onStop 调）：**同步**写一次。
     * 答题计时每秒都在变，不可能每跳一秒落一次盘，就靠这里在切出时存一个准数。
     */
    fun persistNow() {
        ProgressStore.write(getApplication(), snapshot().encode())
    }

    private fun scopeRef(sc: Scope): String = runCatching {
        when (sc.kind) {
            ScopeKind.BIG -> bigIdAt(sc.si, sc.di, sc.bi)
            ScopeKind.DAY -> tree[sc.si].short + ID_SEP + tree[sc.si].day[sc.di].name
            ScopeKind.SUBJECT -> tree[sc.si].short
            ScopeKind.SINGLE -> qidOfQ.getOrNull(sc.si).orEmpty()
            else -> ""
        }
    }.getOrDefault("")

    private fun scopeFromStable(kind: String, ref: String): Scope? {
        val k = runCatching { ScopeKind.valueOf(kind) }.getOrNull() ?: return null
        return when (k) {
            ScopeKind.BIG -> bigIdToIdx[ref]?.let { Scope(ScopeKind.BIG, it.first, it.second, it.third) }
            ScopeKind.DAY -> {
                val p = ref.split(ID_SEP)
                if (p.size != 2) return null
                val si = tree.indexOfFirst { it.short == p[0] }
                val di = if (si < 0) -1 else tree[si].day.indexOfFirst { it.name == p[1] }
                if (si < 0 || di < 0) null else Scope(ScopeKind.DAY, si, di)
            }
            ScopeKind.SUBJECT -> tree.indexOfFirst { it.short == ref }
                .takeIf { it >= 0 }?.let { Scope(ScopeKind.SUBJECT, it) }
            ScopeKind.FAV -> Scope(ScopeKind.FAV)
            ScopeKind.WRONG_ALL -> Scope(ScopeKind.WRONG_ALL)
            ScopeKind.ALL -> Scope(ScopeKind.ALL)
            ScopeKind.SINGLE -> qidToIdx[ref]?.let { Scope(ScopeKind.SINGLE, it) }
        }
    }

    private fun snapshot(): ProgressSnapshot {
        val s = ProgressSnapshot()
        s.themeMode = themeMode
        s.optShuffle = optShuffle
        s.showTimer = showTimer
        s.quizMode = quizMode
        s.totalAnswered = totalAnswered
        s.totalCorrect = totalCorrect
        s.killedCount = killedCount
        dayStats.forEach { (d, e) ->
            if (e.ans > 0 || e.secs > 0) s.days.add(DayLine(d, e.ans, e.cor, e.secs))
        }

        doneMap.forEach { (id, done) ->
            val cor = correctMap[id] ?: 0
            if (done > 0 || cor > 0) s.bigs.add(BigLine(id, done, cor))
        }
        wrongQOrder.forEach { id -> s.wrongs.add(WrongLine(id, wrongQ[id] ?: 0, wrongQStem[id].orEmpty())) }
        favIds.forEach { qidOfQ.getOrNull(it)?.let { id -> s.favs.add(id) } }
        s.lastBigId = lastBig?.let { bigIdAt(it.first, it.second, it.third) }.orEmpty()

        // 会话：内存里有活的就用活的；否则把启动时捞回来的存档原样写回去。
        // ⚠️ 这一支不能省 —— 启动后如果用户什么都没干就切出，快照会变成「没有会话」，
        // 存档就被自己抹掉了。
        // （`scope` 是委托属性，smart cast 用不了，所以先捞进局部量。）
        val liveScope = scope
        val stash = if (roundOver) null else savedSession
        val live = liveScope != null && qSet.isNotEmpty() && !roundOver
        val sc = if (live) liveScope else stash?.scope
        val ids = if (live) qSet else stash?.ids
        if (sc == null || ids == null || ids.isEmpty()) return s

        val at = if (live) qIdx else stash?.qIdx ?: 0
        val secs = if (live) seconds else stash?.seconds ?: 0
        val back = if (live) backMode else stash?.backMode ?: false
        val phase = if (live) resultVisible else stash?.resultPhase ?: false
        val topic = if (live) sessionTopic else stash?.topic.orEmpty()
        val ans: Map<Int, AnswerRec> = if (live) answers else stash?.answers ?: emptyMap()
        val cnt: Set<Int> = if (live) counted.toSet() else stash?.counted ?: emptySet()
        val bp: Map<String, Set<String>> =
            if (live) bigProgress.mapValues { it.value.toSet() } else stash?.bigProgress ?: emptyMap()
        val oo: Map<Int, List<Int>> =
            if (live) optOrder.mapValues { it.value } else stash?.optOrder ?: emptyMap()

        s.hasSession = true
        s.sScopeKind = sc.kind.name
        s.sScopeRef = scopeRef(sc)
        s.sTopic = topic
        s.sBackMode = back
        s.sResultPhase = phase
        s.sQIdx = at
        s.sSeconds = secs
        ids.forEach { qidOfQ.getOrNull(it)?.let { id -> s.sQIds.add(id) } }
        ans.forEach { (pos, r) -> s.sAnswers.add(AnsLine(pos, r.selected, r.right, r.confirmed)) }
        cnt.forEach { s.sCounted.add(it) }
        bp.forEach { (k, v) -> s.sBigProgress.add(SetLine(k, v.toList())) }
        oo.forEach { (pos, o) -> s.sOptOrder.add(OrdLine(pos, o)) }
        return s
    }

    private fun restore() {
        val text = ProgressStore.read(getApplication()) ?: return
        val snap = ProgressSnapshot.decode(text)
        if (snap.version != ProgressSnapshot.VERSION) return

        themeMode = snap.themeMode
        optShuffle = snap.optShuffle
        showTimer = snap.showTimer
        quizMode = snap.quizMode

        // 按日历史灌回来，派生量整体重算。
        snap.days.forEach { dl ->
            val e = DayStat()
            e.ans = dl.ans
            e.cor = dl.cor
            e.secs = dl.secs
            dayStats[dl.date] = e
        }
        // 老格式迁移：v1 早期文件只有 C 行汇总、没有 H 行历史 —— 把汇总折算成「存档当天」的一条，
        // 用时未知按 0 记，保证累计刷题/正确率这些数字不因为升级而归零。
        if (dayStats.isEmpty() && snap.totalAnswered > 0) {
            val e = DayStat()
            e.ans = snap.totalAnswered
            e.cor = snap.totalCorrect
            val d = snap.todayStamp.ifEmpty { dayStamp() }
            dayStats[d] = e
        }
        recomputeCounters()
        killedCount = snap.killedCount

        snap.bigs.forEach { b ->
            doneMap[b.id] = b.done
            correctMap[b.id] = b.correct
            // 做过题的论述题必须标记为「动过」，否则 statBig 会去用种子 acc0（恒 0），正确率显示不出来
            if (b.done > 0) touchedBig[b.id] = true
        }
        snap.wrongs.forEach { wl ->
            // 只收题目稳定 ID 能对上题库的行：旧版论述题级的 W 行（升级前的存档）直接丢弃
            if (qidToIdx.containsKey(wl.id)) {
                bigOf(qidToIdx[wl.id]!!)?.let { t ->
                    val bkey = bigIdAt(t.first, t.second, t.third)
                    // 消灭时钟 = 该论述题下错题行计数的最大值（后进本的题计数可能更低）
                    bigKill[bkey] = maxOf(bigKill[bkey] ?: 0, wl.kill)
                }
                wrongQ[wl.id] = wl.kill
                if (!wrongQOrder.contains(wl.id)) wrongQOrder.add(wl.id)
                wrongQStem[wl.id] = wl.title
            }
        }
        snap.favs.forEach { id ->
            qidToIdx[id]?.let { if (!favIds.contains(it)) favIds.add(it) }
        }
        favCount = favIds.size
        if (snap.lastBigId.isNotEmpty()) lastBig = bigIdToIdx[snap.lastBigId]

        if (snap.hasSession) restoreSession(snap)
    }

    private fun restoreSession(snap: ProgressSnapshot) {
        val sc = scopeFromStable(snap.sScopeKind, snap.sScopeRef) ?: return
        // 题目表整体解不开就整段丢掉：宁可让用户重开一轮，也不能把答案错位到别的题上
        val ids = snap.sQIds.map { qidToIdx[it] ?: return }
        if (ids.isEmpty()) return
        val ans = HashMap<Int, AnswerRec>()
        snap.sAnswers.forEach { a -> ans[a.pos] = AnswerRec(a.sel, a.right, a.confirmed) }
        val bp = HashMap<String, Set<String>>()
        snap.sBigProgress.forEach { bp[it.bigId] = it.ids.toSet() }
        val oo = HashMap<Int, List<Int>>()
        snap.sOptOrder.forEach { oo[it.pos] = it.order }
        savedSession = SavedSession(
            scope = sc,
            topic = snap.sTopic,
            backMode = snap.sBackMode,
            // 题位与已答数都按当前题库长度夹一下，避免题库变短后越界
            qIdx = snap.sQIdx.coerceIn(0, ids.lastIndex),
            seconds = snap.sSeconds,
            resultPhase = snap.sResultPhase && snap.sAnswers.isNotEmpty(),
            ids = ids,
            answers = ans,
            counted = snap.sCounted.toSet(),
            bigProgress = bp,
            optOrder = oo,
        )
    }

    init {
        // 必须放在类体最末尾：Kotlin 按声明顺序初始化，上面的 doneMap / wrongQ / favIds
        // 以及第一段 init 里的 buildIndex 都要先跑完，这里才有东西可灌。
        restore()
    }
}

