package com.gao.recite.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.theme.AppPalette
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.DarkPalette
import com.gao.recite.ui.theme.DayBgDark
import com.gao.recite.ui.theme.LightPalette
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.theme.SectionBgDark
import com.gao.recite.ui.theme.ToneAmber
import com.gao.recite.ui.theme.ToneBlue
import com.gao.recite.ui.theme.ToneGreen
import com.gao.recite.ui.theme.SubjectTone
import com.gao.recite.ui.screen.BankScreen
import com.gao.recite.ui.screen.BookScreen
import com.gao.recite.ui.screen.HomeScreen
import com.gao.recite.ui.screen.QuizScreen
import com.gao.recite.ui.screen.DayDirSheet
import com.gao.recite.ui.screen.ListSheet
import com.gao.recite.ui.screen.ResultScreen
import com.gao.recite.ui.screen.SettingsSheet
import com.gao.recite.ui.screen.StatsScreen
import com.gao.recite.vm.AppVm
import kotlin.math.roundToInt

/**
 * 页面层级严格照抄原型的 z-index 关系：
 * - `#quiz`(z35) / `#result`(z36) 都是 top:44 → bottom:0，**盖住 Tab 栏** → 全屏层，且底下的页面不再渲染；
 * - `#daydir`(z34) 是 top:44 → bottom:98，**只盖内容区，Tab 栏仍可见**；
 * - 设置抽屉是贴底的半屏 sheet（z41），首页上半部分仍然可见。
 */
@Composable
fun ReciteAppRoot(vm: AppVm) {
    val p = LocalPalette.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(vm.toastSeq) {
        if (vm.toastSeq > 0) {
            android.widget.Toast.makeText(ctx, vm.toastText, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    // 全屏覆盖层：出现时底下的页面与 Tab 栏都不画（原型里它们被完全遮住）
    val fullOverlay = vm.quizVisible || vm.resultVisible
    // 系统返回键：逐层关闭覆盖层（答题/结果/设置/列表/Day 目录），而不是直接退出 App
    BackHandler(
        enabled = vm.quizVisible || vm.resultVisible || vm.settingsOpen ||
            vm.listSheet != null || vm.dayDirOpen,
    ) {
        when {
            vm.quizVisible -> vm.exitQuiz()
            vm.resultVisible -> vm.closeResult()
            vm.settingsOpen -> vm.closeSettings()
            vm.listSheet != null -> vm.closeList()
            vm.dayDirOpen -> vm.closeDayDir()
        }
    }
    Scaffold(containerColor = p.bg) { pad ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad),
        ) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    if (!fullOverlay) {
                        when {
                            vm.dayDirOpen -> DayDirSheet(vm)
                            vm.listSheet != null -> ListSheet(vm)
                            vm.tab == 0 -> HomeScreen(vm)
                            vm.tab == 1 -> BankScreen(vm)
                            vm.tab == 2 -> BookScreen(vm)
                            else -> StatsScreen(vm)
                        }
                    }
                }
                if (!fullOverlay) TabBar(vm)
            }
            if (vm.quizVisible) QuizScreen(vm)
            if (vm.resultVisible) ResultScreen(vm)
            if (vm.settingsOpen) SettingsSheet(vm)
        }
    }
}

@Composable
fun TabBar(vm: AppVm) {
    val p = LocalPalette.current
    val items = listOf(
        AppIcons.Home to "首页",
        AppIcons.OpenBook to "题库",
        AppIcons.Bookmark to "题本",
        AppIcons.Chart to "分析",
    )
    // 原型 .tabbar：浮起的圆角胶囊（左右各 14、高 64、圆角 24、6/10 内边距、毛玻璃+投影）
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .height(64.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(p.surface)
            .border(1.dp, p.cardBorder, RoundedCornerShape(24.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val on = vm.tab == i
            val c = if (on) p.primary else p.text3
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .then(if (on) Modifier.background(p.primarySoft) else Modifier)
                    .clickable {
                        vm.tab = i
                        vm.closeDayDir()
                        vm.closeList()
                    }
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                AppIcon(icon, size = 24.dp, strokeWidth = 1.8f, tint = c)
                Text(label, style = AppType.tab, color = c, fontWeight = if (on) FontWeight.Medium else FontWeight.Medium)
            }
        }
    }
}

// ---------------------------------------------------------------- 通用小件

fun themeOf(dark: Boolean): AppPalette = if (dark) DarkPalette else LightPalette

fun toneOf(cls: String): SubjectTone = when (cls) {
    "amber" -> ToneAmber
    "green" -> ToneGreen
    else -> ToneBlue
}

@Composable
fun DayBoxBg(cls: String): Color =
    if (LocalPalette.current === LightPalette) toneOf(cls).dayBg else DayBgDark

@Composable
fun SectionBoxBg(): Color =
    if (LocalPalette.current === LightPalette) LightPalette.surface else SectionBgDark

/** 「标签 + 加粗数字」的计量行，段之间用 · 连接 */
@Composable
fun MetaStat(
    parts: List<Pair<String, String>>,
    color: Color? = null,
    fontSize: Dp = 11.dp,
    maxLines: Int = 2,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val c = color ?: p.text2
    val text = buildAnnotatedString {
        parts.forEachIndexed { i, (label, value) ->
            if (i > 0) append(" · ")
            append(label)
            pushStyle(SpanStyle(fontWeight = FontWeight.Bold, color = p.text1))
            append(value)
            pop()
        }
    }
    Text(
        text,
        modifier = modifier,
        style = AppType.mini.copy(fontSize = fontSize.value.sp, lineHeight = 16.sp, color = c),
        maxLines = maxLines,
    )
}

@Composable
fun GradientDot(tone: SubjectTone, size: Dp = 10.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .background(Brush.linearGradient(listOf(tone.main, tone.gradEnd)), androidx.compose.foundation.shape.CircleShape),
    )
}

@Composable
fun PlayDot(tone: SubjectTone, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(26.dp)
            .clip(RoundedCornerShape(999.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        AppIcon(AppIcons.PlayFilled, size = 14.dp, tint = tone.main)
    }
}

@Composable
fun PctText(v: Int, color: Color, mod: Modifier = Modifier) {
    Text("$v%", modifier = mod, style = AppType.cap.copy(fontWeight = FontWeight.Bold, color = color))
}

@Composable
fun GutterRow(content: @Composable () -> Unit) {
    Row(content = { content() }, verticalAlignment = Alignment.CenterVertically)
}

fun pctOf(done: Int, total: Int): Int =
    if (total > 0) (done * 100.0 / total).roundToInt() else 0

@Composable
fun VSpacer(h: Dp) = Spacer(Modifier.height(h))
@Composable
fun HSpacer(w: Dp) = Spacer(Modifier.width(w))
