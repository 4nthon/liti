package com.gao.recite.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gao.recite.BuildConfig
import com.gao.recite.ui.components.BottomSheet
import com.gao.recite.ui.components.Divider1
import com.gao.recite.ui.components.Segmented
import com.gao.recite.ui.components.SetLabel
import com.gao.recite.ui.components.SetRow
import com.gao.recite.ui.components.SheetHeader
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.ImportState

/** 外观选项：与原型 #setThemeSeg 的三个按钮一一对应 */
private val THEME_LABELS = listOf("浅色", "深色", "跟随系统")
private val THEME_VALUES = listOf("light", "dark", "auto")

/** 设置里的动作行（与 SetRow 同款排版，右侧是 › 而不是开关） */
@Composable
private fun SetActionRow(
    title: String,
    desc: String,
    onClick: () -> Unit,
    showDivider: Boolean = true,
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = AppType.setRowT, color = p.text1)
            Spacer(Modifier.height(2.dp))
            Text(desc, style = AppType.setRowD, color = p.text3)
        }
        Spacer(Modifier.width(12.dp))
        Text("›", style = AppType.setRowT, color = p.text3)
    }
    if (showDivider) Divider1()
}

/**
 * 设置抽屉，对应原型的 #setSheet：
 * 标题「设置」+ 副标题「外观与练习偏好 · 实时生效并本地保存」，
 * 答题模式二选（背题 / 测验，默认背题），外观三选，练习两个开关，
 * 题库导入 / 恢复示例（开源版），版本号。
 */
@Composable
fun SettingsSheet(vm: AppVm) {
    val p = LocalPalette.current
    BottomSheet(onDismiss = { vm.closeSettings() }) {
        SheetHeader("设置", "外观与练习偏好 · 实时生效并本地保存")

        SetLabel("外观")
        Segmented(
            options = THEME_LABELS,
            selected = THEME_VALUES.indexOf(vm.themeMode).coerceAtLeast(0),
            onSelect = { vm.chooseTheme(THEME_VALUES[it]) },
        )

        SetLabel("答题模式")
        Segmented(
            options = listOf("背题模式", "测验模式"),
            selected = if (vm.quizMode == "test") 1 else 0,
            onSelect = { vm.chooseQuizMode(if (it == 1) "test" else "back") },
        )

        SetLabel("练习")
        SetRow(
            title = "选项乱序",
            desc = "每次出题打乱 ABCD 选项顺序",
            checked = vm.optShuffle,
            onChange = { vm.toggleOptShuffle(it) },
        )
        SetRow(
            title = "显示答题计时",
            desc = "关闭后答题页不显示倒计时",
            checked = vm.showTimer,
            onChange = { vm.toggleShowTimer(it) },
            showDivider = false,
        )

        SetLabel("题库")
        SetActionRow(
            title = "导入题库",
            desc = "选择一个或多个 DayN.txt（替换示例题库）",
            onClick = { vm.startPickFiles() },
        )
        SetActionRow(
            title = "恢复示例题库",
            desc = "删除已导入的题库，恢复内置示例",
            onClick = { vm.restoreSampleQbank() },
            showDivider = false,
        )

        // 版本号（跟 build.gradle.kts 的 versionName 走，不用手维护）
        Box(modifier = Modifier.fillMaxWidth().padding(top = 18.dp), contentAlignment = Alignment.Center) {
            Text(
                "砺题 v" + BuildConfig.VERSION_NAME,
                style = AppType.qSrc,
                color = p.text3,
            )
        }
    }

    // ---------- 导入结果弹窗 ----------
    when (val st = vm.importState) {
        is ImportState.Working -> {
            AlertDialog(
                onDismissRequest = {},
                containerColor = p.surface,
                title = { Text("正在导入…", color = p.text1, style = AppType.title) },
                text = { Text("正在解析题库文件，请稍候。", color = p.text2) },
                confirmButton = {},
            )
        }
        is ImportState.Done -> {
            AlertDialog(
                onDismissRequest = { vm.dismissImport() },
                containerColor = p.surface,
                title = { Text("导入完成", color = p.text1, style = AppType.title) },
                text = { Text(st.message, color = p.text2) },
                confirmButton = {
                    TextButton(onClick = { vm.restartToApply() }) {
                        Text("重启应用", color = p.primary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { vm.dismissImport() }) {
                        Text("稍后", color = p.text3)
                    }
                },
            )
        }
        is ImportState.Failed -> {
            AlertDialog(
                onDismissRequest = { vm.dismissImport() },
                containerColor = p.surface,
                title = { Text("导入失败", color = p.text1, style = AppType.title) },
                text = { Text(st.message, color = p.text2) },
                confirmButton = {
                    TextButton(onClick = { vm.dismissImport() }) {
                        Text("知道了", color = p.primary)
                    }
                },
            )
        }
        else -> {}
    }
}
