# -*- coding: utf-8 -*-
"""把用户提供的 zhiyan 图标接入 ReciteApp res 目录。"""
import os
from PIL import Image

SRC = r"C:\Users\Admin\WorkBuddy\2026-09-22-19-49-47\zhiyan-icon\png"
RES = r"C:\Users\Admin\WorkBuddy\2026-09-21-17-28-44\ReciteApp\app\src\main\res"

DENSITIES = ["mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"]
LEGACY = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}   # 48dp
FG     = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432} # 108dp
MONO   = FG

def save(img, folder, name, size):
    d = os.path.join(RES, folder)
    os.makedirs(d, exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(os.path.join(d, name))
    print(folder, name, size)

# 1) legacy 图标（自带背景的成品图）
legacy_src = Image.open(os.path.join(SRC, "zhiyan-icon-512.png")).convert("RGBA")
for den, size in LEGACY.items():
    save(legacy_src, f"mipmap-{den}", "ic_launcher.png", size)

# 2) 自适应前景（透明底，内容在安全区）
fg_src = Image.open(os.path.join(SRC, "adaptive-foreground", "zhiyan-foreground-1024.png")).convert("RGBA")
for den, size in FG.items():
    save(fg_src, f"mipmap-{den}", "ic_launcher_fg.png", size)

# 3) mono（主题图标，只看 alpha）
mono_src = Image.open(os.path.join(SRC, "mono", "zhiyan-mono-black-1024.png")).convert("RGBA")
for den, size in MONO.items():
    save(mono_src, f"mipmap-{den}", "ic_launcher_mono.png", size)

# 4) 取原图四角+中心颜色，用于背景渐变
full = Image.open(os.path.join(SRC, "zhiyan-icon-1024.png")).convert("RGB")
w, h = full.size
pts = {"top-left": (8, 8), "top-right": (w-9, 8), "bottom-left": (8, h-9), "bottom-right": (w-9, h-9), "center-top": (w//2, 8), "center-bottom": (w//2, h-9)}
for k, p in pts.items():
    print(k, "#%02X%02X%02X" % full.getpixel(p))
print("DONE")
