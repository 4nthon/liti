package com.gao.recite.data

/**
 * 题库 txt 解析器（`tools/import_qbank.py` 的 Kotlin 移植版），
 * 供 App 内「导入题库」直接解析用户选择的 `DayN.txt` 文件。
 *
 * 与脚本完全同一套宽容解析规则：
 *
 *   小标题      【马克思主义】
 *   题干        1、马克思主义是由…… ____ 所不断发展的科学理论体系。
 *   选项        A. 后继者        （也可能是  A、后继者）
 *   多空选项    A. 唯物论 \ 辩证法  /  A. 唯物论 / 辩证法   （分隔符统一成 ` / `）
 *   答案        答案：A           正确答案：A
 *   解析        解析：原文「……」   解析：填充后的整句（缺解析时自动用正确答案回填题干）
 *
 * 产物是与 `assets/qbank.tsv` 相同的行式 TSV：
 *   D\tDay名
 *   B\t论述题标题
 *   Q\t题干\tA\tB\tC\tD\t答案下标\t背诵原文
 */
object QbankParser {

    // ---------------------------------------------------------------- 正则（与脚本一致）

    private val RE_HEAD = Regex("""^\s*【\s*(.+?)\s*】\s*$""")
    private val RE_QNUM = Regex("""^\s*(\d+)\s*[、.．]\s*(.*)$""")
    private val RE_OPT = Regex("""^\s*([A-Da-d])\s*[、.．:：]\s*(.*)$""")
    private val RE_ANS = Regex("""^\s*(?:正确)?答案\s*[：:]\s*([A-Da-d])\s*$""")
    private val RE_EXP = Regex("""^\s*(?:解析|分析|解答)\s*[：:]\s*(.*)$""")
    private val RE_DAYNUM = Regex("""Day\s*(\d+)""")
    private val RE_ANY_BLANK = Regex("""【\s*】|_{2,}|\[\s*\]""")

    /** CJK 字符类（含全角标点、数字、空位哨兵）：它们之间的空格是「填空留下的填充空格」 */
    private const val CJK_CLS = "\\u4e00-\\u9fff\\u3000-\\u303f\\uff01-\\uff650-9\\ue000"
    private val RE_FILL_SPACE = Regex("(?<=[$CJK_CLS])[ \t]+(?=[$CJK_CLS])")

    private val RE_BACKSLASH_SEP = Regex("\\s*\\\\\\s*")
    private val RE_SLASH_SEP = Regex("\\s+/\\s+")
    private val RE_FW_SLASH = Regex("\\s*／\\s*")
    private val RE_ANY_SLASH = Regex("\\s*/\\s*")
    private val RE_SPACES = Regex("[ \t]+")
    private val RE_MULTI_SPACE = Regex("[ \t]{2,}")
    private val RE_PUNCT_AFTER = Regex("[ \t]*([，。；：、）】”』])\\s*")
    private val RE_PUNCT_BEFORE = Regex("([（【“‘『])\\s*")
    private val RE_ORIG_PREFIX = Regex("^\\s*原文\\s*")

    /** 空位哨兵（私用区字符，正文里不会出现） */
    private const val SENT = "\ue000"

    /** 解析时剥掉的「原文」包装引号 */
    private val WRAPS = listOf(
        "「" to "」",
        "“" to "”",
        "『" to "』",
        "\"" to "\"",
    )

    // ---------------------------------------------------------------- 数据结构

    /** 正在收集的一道题 */
    private class Q(
        val num: Int,
        var stem: String,
        val opts: MutableList<String> = mutableListOf(),
        var ans: Char? = null,
        var exp: String = "",
    )

    /** 一个小标题分组（= 一个论述题） */
    private class Group(val head: String?, val qs: MutableList<Q> = mutableListOf())

    /** 一个解析完成的 txt 文件 */
    private class ParsedFile(val day: String, val groups: List<Group>)

    data class Stats(
        val dayCount: Int,
        val bigCount: Int,
        val qCount: Int,
        val tsv: String,
        /** 每个文件一行的统计说明 */
        val perDay: List<String>,
        /** 因缺答案 / 选项不足 / 答案越界被跳过的题数 */
        val skipped: Int,
        val warnings: List<String>,
    )

    // ---------------------------------------------------------------- 清洗（与脚本一致）

    /** 只挤多余空白，空位标记（____ / 【 】）保持原样不转换 */
    private fun normalizeStem(s: String): String = s.replace(RE_SPACES, " ").trim()

    /** 把填空时人为加在词两边的空格去掉（中文正文里不该有词间空格） */
    private fun tidy(s: String): String {
        var t = s.replace('\u00A0', ' ')
        t = RE_FILL_SPACE.replace(t, "")
        t = t.replace(RE_MULTI_SPACE, " ")
        return t.trim()
    }

    private fun cleanStem(s: String): String {
        var t = normalizeStem(s)
        // 先把空位换成哨兵：tidy 会把「【 】」里的空格当填充空格吃掉
        t = t.replace("【 】", SENT)
        t = tidy(t)
        // 标点两侧不留空格（此时空位还是哨兵，不会被误伤）
        t = RE_PUNCT_AFTER.replace(t) { it.groupValues[1] }
        t = RE_PUNCT_BEFORE.replace(t) { it.groupValues[1] }
        return t.replace(SENT, "【 】").trim()
    }

    /** 多空选项的分隔符统一成 ` / `，去掉前后多余空格 */
    private fun normalizeOpt(s: String): String {
        var t = s.replace(RE_BACKSLASH_SEP, " / ")
        t = t.replace(RE_SLASH_SEP, " / ")
        t = t.replace(RE_FW_SLASH, " / ")
        t = t.replace(RE_SPACES, " ")
        t = t.replace(RE_ANY_SLASH, " / ")
        return t
    }

    private fun cleanOpt(s: String): String =
        normalizeOpt(s).split(" / ").map { tidy(it) }.filter { it.isNotEmpty() }.joinToString(" / ")

    /** 解析 → 背诵原文：剥掉「原文」前缀和引号包装，去掉填充空格 */
    private fun cleanRoot(s: String): String {
        var t = s.trim().replace(RE_ORIG_PREFIX, "").trim()
        for ((a, b) in WRAPS) {
            if (t.length > a.length + b.length && t.startsWith(a) && t.endsWith(b)) {
                t = t.substring(a.length, t.length - b.length)
                break
            }
        }
        t = tidy(t)
        t = RE_PUNCT_AFTER.replace(t) { it.groupValues[1] }
        t = RE_PUNCT_BEFORE.replace(t) { it.groupValues[1] }
        return t.trim()
    }

    /** 保底：把正确答案回填进题干，得到背诵原文 */
    private fun fillStem(stem: String, opt: String): String {
        var out = stem
        for (p in opt.split(" / ")) {
            if (p.isNotEmpty()) out = RE_ANY_BLANK.replaceFirst(out, Regex.escapeReplacement(p))
        }
        return RE_ANY_BLANK.replace(out, "")
    }

    // ---------------------------------------------------------------- 主解析流程

    /**
     * 解析单个 DayN.txt。文件名含 "DayN" 时 Day 名取 N，否则用文件名去扩展名。
     */
    private fun parseDayFile(fileName: String, text: String): ParsedFile {
        val m = RE_DAYNUM.find(fileName)
        val day = if (m != null) "Day" + m.groupValues[1].toInt() else fileName.substringBeforeLast('.')

        val groups = mutableListOf<Group>()
        var curHead: String? = null
        var curQs = mutableListOf<Q>()
        var q: Q? = null

        fun flushQ() {
            q?.let { curQs.add(it) }
            q = null
        }
        fun pushGroup() {
            if (curHead != null || curQs.isNotEmpty()) {
                groups.add(Group(curHead, curQs))
                curQs = mutableListOf()
            }
        }

        for (raw in text.lineSequence()) {
            val line = raw.trimEnd()
            if (line.isBlank()) continue

            val mh = RE_HEAD.matchEntire(line)
            if (mh != null) {
                flushQ()
                pushGroup()
                curHead = mh.groupValues[1]
                continue
            }

            val qq = q
            if (qq != null) {
                val ma = RE_ANS.matchEntire(line)
                if (ma != null) {
                    qq.ans = ma.groupValues[1].uppercase()[0]
                    continue
                }
                val me = RE_EXP.matchEntire(line)
                if (me != null) {
                    qq.exp = me.groupValues[1].trim()
                    continue
                }
                val mo = RE_OPT.matchEntire(line)
                if (mo != null) {
                    val letter = mo.groupValues[1].uppercase()[0]
                    // 选项字母必须按 A B C D 顺序出现，否则当普通续行处理
                    if (letter.code == 'A'.code + qq.opts.size) {
                        qq.opts.add(normalizeOpt(mo.groupValues[2]))
                        continue
                    }
                }
            }

            val mq = RE_QNUM.matchEntire(line)
            if (mq != null) {
                flushQ()
                q = Q(mq.groupValues[1].toInt(), mq.groupValues[2])
                continue
            }

            val q2 = q ?: continue
            // 题干续行（题干太长被换行）；已出现选项后则当解析续行
            if (q2.opts.isEmpty()) q2.stem += line.trim() else q2.exp += line.trim()
        }

        flushQ()
        pushGroup()
        return ParsedFile(day, groups)
    }

    /**
     * 把多个 txt 文件解析并合并为 TSV。文件按 Day 序号排序。
     */
    fun emit(files: List<Pair<String, String>>): Stats {
        val sorted = files.sortedWith(
            compareBy { RE_DAYNUM.find(it.first)?.groupValues?.get(1)?.toIntOrNull() ?: Int.MAX_VALUE },
        )
        val tsv = StringBuilder()
        val perDay = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val seenDays = HashSet<String>()
        var nBig = 0
        var nQ = 0
        var skippedTotal = 0

        for ((fname, text) in sorted) {
            val pf = parseDayFile(fname, text)
            val dayName = if (!seenDays.add(pf.day)) pf.day + "·" + (seenDays.size + 1) else pf.day

            val dayBlock = StringBuilder()
            var bigInFile = 0
            var qInFile = 0
            var skipped = 0

            for (g in pf.groups) {
                val head = g.head ?: "练习组"
                val qLines = StringBuilder()
                var qn = 0
                for (q in g.qs) {
                    val ans = q.ans
                    if (ans == null || q.opts.isEmpty() || q.stem.isBlank()) {
                        skipped++
                        continue
                    }
                    val stem = cleanStem(q.stem)
                    val opts = q.opts.map { cleanOpt(it) }
                    val ai = ans.code - 'A'.code
                    if (stem.isEmpty() || opts.size != 4 || ai !in opts.indices) {
                        skipped++
                        continue
                    }
                    var root = cleanRoot(q.exp)
                    if (root.length < 6 || root == stem) root = fillStem(stem, opts[ai])
                    if (root.contains('\t') || opts.any { it.contains('\t') }) {
                        skipped++
                        continue
                    }
                    qLines.append("Q\t").append(stem).append('\t')
                        .append(opts[0]).append('\t').append(opts[1]).append('\t')
                        .append(opts[2]).append('\t').append(opts[3]).append('\t')
                        .append(ai).append('\t').append(root).append('\n')
                    qn++
                }
                if (qn > 0) {
                    dayBlock.append("B\t").append(head).append('\n').append(qLines)
                    bigInFile++
                    qInFile += qn
                }
            }

            if (bigInFile > 0) {
                tsv.append("D\t").append(dayName).append('\n').append(dayBlock)
                perDay.add("$dayName：$bigInFile 个论述题 / $qInFile 题")
                nBig += bigInFile
                nQ += qInFile
            }
            if (skipped > 0) {
                skippedTotal += skipped
                warnings.add("$fname：跳过 $skipped 题（缺答案 / 选项不足 4 个 / 答案越界 / 含制表符）")
            }
        }

        return Stats(perDay.size, nBig, nQ, tsv.toString(), perDay, skippedTotal, warnings)
    }
}
