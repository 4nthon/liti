package com.gao.recite.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * 色板与原型 quiz-app-prototype.html 的 :root / [data-theme="dark"] 一一对应。
 */
data class AppPalette(
    val bg: Color,
    val surface: Color,
    val surface2: Color,
    val track: Color,
    val border: Color,
    val text1: Color,
    val text2: Color,
    val text3: Color,
    val primary: Color,
    val primary2: Color,
    val primarySoft: Color,
    val primaryInk: Color,
    val onPrimary: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val dangerSoft: Color,
    val shadow: Color,
    val cardBorder: Color,
)

val LightPalette = AppPalette(
    bg = Color(0xFFF6F7FB),
    surface = Color(0xFFFFFFFF),
    surface2 = Color(0xFFEEF1F7),
    track = Color(0xFFE6E9F2),
    border = Color(0x0F171A26),
    text1 = Color(0xFF1A1D26),
    text2 = Color(0xFF6B7280),
    text3 = Color(0xFF9CA3AF),
    primary = Color(0xFF4F6BFF),
    primary2 = Color(0xFF7C9BFF),
    primarySoft = Color(0xFFE9EDFF),
    primaryInk = Color(0xFF3A52C9),
    onPrimary = Color(0xFFFFFFFF),
    success = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    danger = Color(0xFFEF4444),
    dangerSoft = Color(0xFFFDECEC),
    shadow = Color(0x0F171A26),
    cardBorder = Color(0x0F171A26),
)

val DarkPalette = AppPalette(
    bg = Color(0xFF0B0E15),
    surface = Color(0xFF151A24),
    surface2 = Color(0xFF1C2230),
    track = Color(0xFF232B3B),
    border = Color(0x2497A8CD),
    text1 = Color(0xFFB3BCCD),
    text2 = Color(0xFF7D8599),
    text3 = Color(0xFF4E5769),
    primary = Color(0xFF7B92FF),
    primary2 = Color(0xFF9BACFF),
    primarySoft = Color(0x267B92FF),
    primaryInk = Color(0xFFA9B8FF),
    onPrimary = Color(0xFF0B0E15),
    success = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    danger = Color(0xFFEF4444),
    dangerSoft = Color(0x26EF4444),
    shadow = Color(0x1A000000),
    cardBorder = Color(0x2497A8CD),
)

/** 科目色 */
data class SubjectTone(
    val main: Color,
    val gradEnd: Color,
    val dayBg: Color,
    val soft: Color,
)

val ToneBlue = SubjectTone(
    main = Color(0xFF4F6BFF),
    gradEnd = Color(0xFF7C9BFF),
    dayBg = Color(0xFFEEF2FF),
    soft = Color(0xFFE9EDFF),
)
val ToneAmber = SubjectTone(
    main = Color(0xFFF59E0B),
    gradEnd = Color(0xFFFBBF4B),
    dayBg = Color(0xFFFEF4E7),
    soft = Color(0xFFFEF3E2),
)
val ToneGreen = SubjectTone(
    main = Color(0xFF22C55E),
    gradEnd = Color(0xFF4ADE80),
    dayBg = Color(0xFFEBFAF1),
    soft = Color(0xFFE8F7EF),
)

/** 深色模式下 Day 层底框 */
val DayBgDark = Color(0xFF1B2130)
val SectionBgDark = Color(0xFF252D3D)

val LocalThemeIsDark = androidx.compose.runtime.staticCompositionLocalOf { false }

/** 当前调色板 */
val LocalPalette = androidx.compose.runtime.staticCompositionLocalOf { LightPalette }

fun paletteFor(dark: Boolean) = if (dark) DarkPalette else LightPalette
