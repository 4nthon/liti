package com.gao.recite.ui.theme

import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * 字体族。
 * 原型 body 上写的是 -apple-system,"PingFang SC","Noto Sans SC","Microsoft YaHei",sans-serif。
 * Android 上中文字面会落到系统 sans-serif（Noto Sans CJK SC），这里显式声明，
 * 避免被主题或默认值改掉。
 */
val AppFontFamily: FontFamily = FontFamily.SansSerif

/**
 * 字阶 —— 逐条对照原型 quiz-app-prototype.html 的 CSS 规则，不是凭感觉分的档位。
 *
 * 重要：原型里定义了 `--f-display:24px`，但**全文没有任何选择器使用它**。
 * 早期 Compose 版本把页面标题、结果页大数字都写成了 24sp，这正是"字体不对"的根源。
 * 页面标题的真实规格是 `.page-title` = 18px/700。
 */
object AppType {

    // ================= 原型 --f-* 变量 =================
    val display = TextStyle(fontFamily = AppFontFamily, fontSize = 24.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold)
    val title = TextStyle(fontFamily = AppFontFamily, fontSize = 18.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)
    val body = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal)
    val cap = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal)
    val mini = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    // ================= 首页 · 欢迎栏 =================
    /** .welcome h1 — 20px / 700 / letter-spacing .2px */
    val welcomeTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp)

    /** .welcome .date — 13px / --text-2 */
    val welcomeDate = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal)

    /** .welcome .quote — 11px / line-height 1.5 / --text-3 */
    val welcomeQuote = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.5.sp, fontWeight = FontWeight.Normal)

    // ================= 页面标题 =================
    /** .page-title — 18px / 700 */
    val pageTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 18.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)

    /** .page-sub — 13px / --text-2 */
    val pageSub = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal)

    // ================= 区块标题 =================
    /** .sec-head h3 — 15px / 700 */
    val secHead = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold)

    /** .foldall — 13px / 500 */
    val foldAll = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium)

    // ================= 数字 =================
    /** .stat .num — 17px / 700 */
    val statNum = TextStyle(fontFamily = AppFontFamily, fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold)

    /** .stat .lbl — 11px / --text-2 */
    val statLbl = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .r-pct — 28px / 800 */
    val resultPct = TextStyle(fontFamily = AppFontFamily, fontSize = 28.sp, lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold)

    /** .r-stat .num — 18px / 700 */
    val resultStatNum = TextStyle(fontFamily = AppFontFamily, fontSize = 18.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)

    /** .bh-nums b — 22px / 800 */
    val heroNum = TextStyle(fontFamily = AppFontFamily, fontSize = 22.sp, lineHeight = 30.sp, fontWeight = FontWeight.ExtraBold)

    /** .bh-nums span — 11px */
    val heroNumLbl = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .bh-count b — 20px / 800 */
    val favCountNum = TextStyle(fontFamily = AppFontFamily, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold)

    /** .bh-count em — 11px */
    val favCountUnit = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    // ================= 卡片文案 =================
    /** .c-info h4 / .bank-card h4 / .book-card h4 / .bh-name / .r-review h4 / .r-tip h4 — 13px / 700 */
    val cardTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold)

    /** .c-sub — 11px / line-height 1.4 */
    val cardSub = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 15.4.sp, fontWeight = FontWeight.Normal)

    /** .bh-name small — 11px / 400 */
    val cardSubLight = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .bh-nums span 等紧随数字的说明 — 11px */
    val numCaption = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    // ================= 答题页 =================
    /** .q-tag — 10px / 700 / letter-spacing .5px */
    val qTag = TextStyle(fontFamily = AppFontFamily, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)

    /** .q-count — 10px / 700 */
    val qCount = TextStyle(fontFamily = AppFontFamily, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold)

    /** .quiz-title .t1 — 13px / 700 */
    val quizT1 = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold)

    /** .quiz-title 第二行 / .q-srcbox — 11px / line-height 1.45 */
    val qSrc = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .q-text — 16px / 600 / line-height 1.65 */
    val qText = TextStyle(fontFamily = AppFontFamily, fontSize = 16.sp, lineHeight = 26.4.sp, fontWeight = FontWeight.SemiBold)

    /** .opt .letter — 13px / 700 */
    val optLetter = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold)

    /** .opt .txt — 15px / line-height 1.5 */
    val optText = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 22.5.sp, fontWeight = FontWeight.Normal)

    /** .exp h5 / .exp .ans — 13px / 700 */
    val expTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold)

    /** .exp p — 13px / line-height 1.7 */
    val expText = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal)

    /** .qcard-title — 13px / 700 */
    val qcardTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold)

    /** .qc — 12px / 700 */
    val qc = TextStyle(fontFamily = AppFontFamily, fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Bold)

    /** .q-nav>button — 11px / 600 */
    val navBtn = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold)

    // ================= 结果页 =================
    /** .r-title — 18px / 700 */
    val resultTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 18.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)

    /** .r-sub — 11px */
    val resultSub = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .r-row .rq — 13px */
    val reviewQ = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Normal)

    /** .r-root — 13px / line-height 1.85 */
    val reciteRoot = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal)

    /** .r-review h4 / .r-tip h4 — 13px / 700（注意：不是 15px 的 .card-title） */
    val resultH4 = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold)

    /** .r-root .no / .root-box .root-label — 10~11px / 700 */
    val rootLabel = TextStyle(fontFamily = AppFontFamily, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp)

    /** .r-tip p — 13px / line-height 1.7 */
    val tipText = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal)

    // ================= 抽屉 / 设置 =================
    /** .sheet h3 / .dd-top h3 — 18px / 700 */
    val sheetTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 18.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold)

    /** .sheet .s-sub — 11px */
    val sheetSub = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .set-label — 11px / 600 / letter-spacing .5px */
    val setLabel = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)

    /** .seg button — 13px / 600 */
    val segBtn = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)

    /** .sr-t — 15px / 600 */
    val setRowT = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold)

    /** .sr-t small — 11px / 400 */
    val setRowD = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    // ================= 按钮 =================
    /** .btn — 13px / 600 */
    val btn = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)

    /** #confirmBtn / .r-actions .btn — 15px */
    val btnLg = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold)

    /** .start-btn — 15px / 700 */
    val startBtn = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold)

    /** .wrong-quick — 13px / 600 */
    val wrongQuick = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)

    /** .scope-row .s-t — 15px / 700 */
    val scopeT = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold)

    /** .scope-row .s-d — 11px */
    val scopeD = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .chip — 13px */
    val chip = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal)

    /** .tag — 10px / 600 */
    val tag = TextStyle(fontFamily = AppFontFamily, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold)

    /** .tab — 11px / 500 */
    val tab = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)

    /** .empty — 13px；.empty .big — 28px */
    val emptyBig = TextStyle(fontFamily = AppFontFamily, fontSize = 28.sp, lineHeight = 38.sp, fontWeight = FontWeight.Normal)

    // ================= 零碎条目（原型里各自独立的小规则） =================
    /** .quiz-timer — 11px / 600 */
    val quizTimer = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold)

    /** .qcard-exit — 11px */
    val qcardExit = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .qcard-legend — 10px */
    val qcardLegend = TextStyle(fontFamily = AppFontFamily, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Normal)

    /** .r-row .idx — 11px / 700 */
    val rRowIdx = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Bold)

    /** .r-row .st — 11px / 600 */
    val rRowSt = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold)

    /** .ov b — 15px / 700（分析页概览数字） */
    val overviewNum = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold)

    /** .ov — 11px */
    val overviewLbl = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .dir-row .dr-name — 13px / 600 */
    val dirName = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)

    /** .dir-row .dr-meta / .dr-pct — 11px */
    val dirMeta = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .dir-head .dh-name — 13px / 700 */
    val dirHead = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold)

    /** .day-tail — 11px */
    val dayTail = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    // ================= 题库页科目大卡 / 题单行（原型 .subj-card / .q-row） =================
    /** .subj-card .sc-ic 首字 — 13px / 700 */
    val subjIc = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold)

    /** .subj-card .sc-t — 15px / 700 */
    val subjT = TextStyle(fontFamily = AppFontFamily, fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold)

    /** .subj-card .sc-m — 11px */
    val subjM = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)

    /** .dir-row.todo .dr-name — 13px / 500 */
    val dirNameTodo = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium)

    /** .q-stem — 13px / 500 / line-height 1.55 */
    val qStem = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)

    /** .q-badge — 10px / 600 */
    val qBadge = TextStyle(fontFamily = AppFontFamily, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold)

    /** .search placeholder / input — 13px */
    val searchTxt = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal)

    // ================= 首页层级树（.head-title / .ch-title / .sec-title / 加粗小字） =================
    /** .head-title — 13px / 600 */
    val headTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)

    /** .ch-title — 13px / 600 */
    val chTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold)

    /** .sec-title — 13px / 400 */
    val secTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 13.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal)

    /** .c-foot b — 11px / 600 */
    val miniBold = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold)

    /** .head-top .pct — 11px / 600 */
    val miniSemi = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold)

    /** .wbar .row b — 11px / 600 / --text-1（薄弱榜单的论述题名） */
    val wbarTitle = TextStyle(fontFamily = AppFontFamily, fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold)
}

/** 圆角 */
object AppRadius {
    val card = 16
    val inner = 12
}
