package com.gao.recite.ui.icons

import android.graphics.Paint
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.PathParser

/**
 * 图标方案：直接复用原型 HTML 里的 SVG path 数据（d 属性原样搬过来），
 * 用 androidx.core.graphics.PathParser 解析后用原生 Paint 绘制，
 * 因此 View/tree 里的图标跟原型是逐像素一致的，也不依赖 material-icons 扩展包。
 */

data class DrawOp(
    val d: String? = null,
    val cx: Float? = null,
    val cy: Float? = null,
    val r: Float? = null,
    val fill: Boolean = false,
)

data class IconSpec(val viewport: Float = 24f, val ops: List<DrawOp>)

private fun stroke(vararg d: String) = d.map { DrawOp(d = it, fill = false) }
private fun fillOf(vararg d: String) = d.map { DrawOp(d = it, fill = true) }

object AppIcons {
    val Home = IconSpec(ops = stroke(
        "M 3 10.5 L 12 3 l 9 7.5",
        "M 5.5 9.5 V 20 a 1 1 0 0 0 1 1 H 10 v -6 h 4 v 6 h 3.5 a 1 1 0 0 0 1 -1 V 9.5",
    ))

    val OpenBook = IconSpec(ops = stroke(
        "M 12 6.5 C 10.5 5 8.5 4.5 6 4.5 c -1.5 0 -2.8 0.3 -3.5 0.6 V 19 c 0.7 -0.3 2 -0.6 3.5 -0.6 c 2.5 0 4.5 0.5 6 2 c 1.5 -1.5 3.5 -2 6 -2 c 1.5 0 2.8 0.3 3.5 0.6 V 5.1 c -0.7 -0.3 -2 -0.6 -3.5 -0.6 c -2.5 0 -4.5 0.5 -6 2 Z",
        "M 12 6.5 v 14",
    ))

    val Bookmark = IconSpec(ops = stroke(
        "M 6 3 h 12 a 1 1 0 0 1 1 1 v 17 l -7 -4 l -7 4 V 4 a 1 1 0 0 1 1 -1 Z",
    ))

    val Chart = IconSpec(ops = stroke("M 4 20 V 10 M 10 20 V 4 M 16 20 v -8 M 21 20 H 3"))

    val Settings = IconSpec(ops = listOf(
        DrawOp(cx = 12f, cy = 12f, r = 3.2f, fill = false),
    ) + stroke(
        "M 19.4 15 a 1.7 1.7 0 0 0 0.34 1.87 l 0.06 0.06 a 2 2 0 1 1 -2.83 2.83 l -0.06 -0.06 a 1.7 1.7 0 0 0 -1.87 -0.34 a 1.7 1.7 0 0 0 -1 1.55 V 21 a 2 2 0 1 1 -4 0 v -0.09 a 1.7 1.7 0 0 0 -1 -1.55 a 1.7 1.7 0 0 0 -1.87 0.34 l -0.06 0.06 a 2 2 0 1 1 -2.83 -2.83 l 0.06 -0.06 a 1.7 1.7 0 0 0 0.34 -1.87 a 1.7 1.7 0 0 0 -1.55 -1 H 3 a 2 2 0 1 1 0 -4 h 0.09 a 1.7 1.7 0 0 0 1.55 -1 a 1.7 1.7 0 0 0 -0.34 -1.87 l -0.06 -0.06 a 2 2 0 1 1 2.83 -2.83 l 0.06 0.06 a 1.7 1.7 0 0 0 1.87 0.34 h 0.09 a 1.7 1.7 0 0 0 1 -1.55 V 3 a 2 2 0 1 1 4 0 v 0.09 a 1.7 1.7 0 0 0 1 1.55 a 1.7 1.7 0 0 0 1.87 -0.34 l 0.06 -0.06 a 2 2 0 1 1 2.83 2.83 l -0.06 0.06 a 1.7 1.7 0 0 0 -0.34 1.87 v 0.09 a 1.7 1.7 0 0 0 1.55 1 H 21 a 2 2 0 1 1 0 4 h -0.09 a 1.7 1.7 0 0 0 -1.55 1 Z",
    ))

    val Pen = IconSpec(ops = stroke(
        "M 16.5 3.5 l 4 4 L 7 21 H 3 v -4 Z",
        "M 14 6 l 4 4",
    ))

    val CheckCircle = IconSpec(ops = listOf(
        DrawOp(cx = 12f, cy = 12f, r = 9f, fill = false),
    ) + stroke("M 8.5 12.5 l 2.5 2.5 l 5 -5.5"))

    val Flame = IconSpec(ops = stroke(
        "M 12 3 s 5 4.2 5 9 a 5 5 0 0 1 -10 0 c 0 -1.8 0.8 -3.2 1.8 -4.3 c 0.2 1.8 1 2.8 2.2 3.3 c -0.4 -2.6 0.2 -5.8 1 -8 Z",
    ))

    val AlertCircle = IconSpec(ops = listOf(
        DrawOp(cx = 12f, cy = 12f, r = 9f, fill = false),
    ) + stroke("M 12 8 v 4 M 12 16 h 0.01"))

    val Search = IconSpec(ops = listOf(
        DrawOp(cx = 11f, cy = 11f, r = 7f, fill = false),
    ) + stroke("M 20 20 l -3.5 -3.5"))

    val Timer = IconSpec(ops = listOf(
        DrawOp(cx = 12f, cy = 12f, r = 9f, fill = false),
    ) + stroke("M 12 7 v 5 l 3 2"))

    val ChevronRight = IconSpec(ops = stroke("M 9 6 l 6 6 l -6 6"))
    val ChevronLeft = IconSpec(ops = stroke("M 15 5 l -7 7 l 7 7"))
    val ChevronDown = IconSpec(ops = stroke("M 6 9 l 6 6 l 6 -6"))
    val Close = IconSpec(ops = stroke("M 6 6 l 12 12 M 18 6 L 6 18"))

    val Star = IconSpec(ops = stroke(
        "M 12 3 l 2.7 5.6 l 6.1 0.8 l -4.5 4.3 l 1.1 6 l -5.4 -2.9 l -5.4 2.9 l 1.1 -6 L 3.2 9.4 l 6.1 -0.8 Z",
    ))
    val StarFilled = IconSpec(ops = fillOf(
        "M 12 3 l 2.7 5.6 l 6.1 0.8 l -4.5 4.3 l 1.1 6 l -5.4 -2.9 l -5.4 2.9 l 1.1 -6 L 3.2 9.4 l 6.1 -0.8 Z",
    ))

    val PlayFilled = IconSpec(ops = fillOf("M 8 5.5 v 13 l 11 -6.5 Z"))

    val GridCard = IconSpec(ops = stroke(
        "M 5 4 h 14 a 2 2 0 0 1 2 2 v 12 a 2 2 0 0 1 -2 2 H 5 a 2 2 0 0 1 -2 -2 V 6 a 2 2 0 0 1 2 -2 Z",
        "M 8 9 h 3 M 8 13 h 3 M 13 9 h 3 M 13 13 h 3",
    ))

    val Bulb = IconSpec(ops = stroke(
        "M 9 18 h 6 M 10 21 h 4 M 12 3 a 6 6 0 0 0 -3.5 10.9 c 0.8 0.6 1.5 1.3 1.5 2.1 h 4 c 0 -0.8 0.7 -1.5 1.5 -2.1 A 6 6 0 0 0 12 3 Z",
    ))

    /** .opt .mark —— 选项右侧的对勾标记（原型对答对/答错都用同一条 path） */
    val Mark = IconSpec(ops = stroke("M 5 12.5 l 4.5 4.5 L 19 7.5"))
}

@Composable
fun AppIcon(
    spec: IconSpec,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    strokeWidth: Float = 2f,
    tint: Color = Color.Unspecified,
) {
    val paths = remember(spec) {
        // 单个 path 数据解析失败不应让整个界面崩溃，失败时该路径留空跳过
        spec.ops.map { op ->
            op.d?.let {
                runCatching { PathParser.createPathFromPathData(it) }.getOrNull()
            }
        }
    }
    val paints = remember(spec, tint, strokeWidth) {
        spec.ops.map { op ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                if (tint != Color.Unspecified) color = tint.toArgb()
                style = if (op.fill) Paint.Style.FILL else Paint.Style.STROKE
                this.strokeWidth = strokeWidth
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
        }
    }
    androidx.compose.foundation.Canvas(modifier = modifier.size(size)) {
        val s = this.size.width / spec.viewport
        drawIntoCanvas { c ->
            c.save()
            c.scale(s, s)
            spec.ops.forEachIndexed { i, op ->
                val p = paths[i]
                if (p != null) {
                    c.nativeCanvas.drawPath(p, paints[i])
                } else if (op.r != null && op.cx != null && op.cy != null) {
                    c.nativeCanvas.drawCircle(op.cx, op.cy, op.r, paints[i])
                }
            }
            c.restore()
        }
    }
}

@Composable
@Suppress("UnusedPrivateMember")
private fun unusedCanvasCompat(
    modifier: Modifier,
    size: Dp,
) = Unit
