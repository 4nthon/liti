package com.gao.recite.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.gao.recite.data.FAV_DEMO
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.components.DirHead
import com.gao.recite.ui.components.Divider1
import com.gao.recite.ui.components.EmptyBox
import com.gao.recite.ui.components.QRow
import com.gao.recite.ui.components.SubjCard
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.toneOf
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.Scope
import com.gao.recite.vm.ScopeKind

/**
 * 覆盖式面板外壳 —— 原型 #daydir / #listdir 的形态：
 * 占满 Tab 栏以上的整个区域（top 44 / bottom 98），顶栏「返回 + 标题 + 右侧」，主体独立滚动。
 * 注意：原型里这两块**不是底部抽屉**，而是盖住页面的整屏面板。
 */
@Composable
private fun OverlayPanel(
    title: String,
    onBack: () -> Unit,
    trailing: @Composable () -> Unit = {},
    body: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalPalette.current
    Column(modifier = Modifier.fillMaxSize().background(p.bg)) {
        // .dd-top
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.surface)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center,
            ) {
                AppIcon(AppIcons.ChevronLeft, size = 20.dp, strokeWidth = 2f, tint = p.text1)
            }
            Text(title, style = AppType.sheetTitle, color = p.text1, modifier = Modifier.weight(1f), maxLines = 1)
            trailing()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.cardBorder))
        // .dd-body
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            content = body,
        )
    }
}

/**
 * Day 目录面板（原型 #daydir）。
 * pick=true → 标题「选择 Day」，点行只做选择并弹 toast；
 * pick=false → 标题「Day 目录」，点行直接开背。
 */
@Composable
fun DayDirSheet(vm: AppVm) {
    val p = LocalPalette.current
    val si = vm.bankSubject
    val sj = vm.tree[si]
    val pick = vm.dayDirPick

    OverlayPanel(
        title = if (pick) "选择 Day" else "Day 目录",
        onBack = { vm.closeDayDir() },
        trailing = {
            Text("${sj.short} · 共 ${sj.total} 个 Day", style = AppType.dirMeta, color = p.text3)
        },
    ) {
        // 原型 renderDayDir：dir-head（科目全名 + 范围）在卡片之外，先于卡片渲染
        DirHead(name = sj.name, range = sj.range, tone = toneOf(sj.cls))
        AppCard(padding = PaddingValues(vertical = 8.dp)) {
            sj.day.forEachIndexed { di, d ->
                val s = vm.statDay(si, di)
                val sel = pick && d.name == vm.bkDay
                if (di > 0) Divider1()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (sel) Modifier.background(p.primarySoft) else Modifier)
                        .clickable {
                            if (pick) {
                                vm.pickDayInDir(d.name)
                                vm.closeDayDir()
                            } else {
                                vm.closeDayDir()
                                vm.startQuiz(Scope(ScopeKind.DAY, si, di))
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, style = AppType.dirName, color = p.text1, maxLines = 1)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "论述题 ${s.started}/${s.bigs} · 选择题 ${s.done}/${s.total} · 正确率 ${s.acc}%",
                            style = AppType.dirMeta, color = p.text3, maxLines = 1,
                        )
                    }
                    Text("${s.pct}%", style = AppType.dirMeta, color = p.text2)
                    // pick 模式下不显示右侧箭头（同原型）
                    if (!pick) {
                        com.gao.recite.ui.components.PlayChevron(toneOf(sj.cls))
                    }
                }
            }
            // 未开始的 Day：原型会补足到 sj.total 个（.dir-row.todo）
            for (i in sj.day.size until sj.total) {
                val dayName = "Day${sj.start + i}"
                Divider1()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (pick) {
                                vm.pickDayInDir(dayName)
                                vm.closeDayDir()
                            } else {
                                vm.closeDayDir()
                                vm.startEmptyDay()
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(dayName, style = AppType.dirNameTodo, color = p.text2, maxLines = 1)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            if (pick) "未开始 · 点击选择" else "未开始 · 点击开始背诵",
                            style = AppType.dirMeta, color = p.text3, maxLines = 1,
                        )
                    }
                    if (!pick) {
                        com.gao.recite.ui.components.PlayChevron(toneOf(sj.cls), alpha = .45f)
                    }
                }
            }
        }
    }
}

/**
 * 题单面板（原型 #listdir）：错题本 / 我的收藏 / 全部薄弱 / 单个专题，四种形态共用一个外壳，
 * 右上角动作随形态变化。
 */
@Composable
fun ListSheet(vm: AppVm) {
    val p = LocalPalette.current
    val mode = vm.listSheet ?: return

    OverlayPanel(
        title = vm.listTitle(),
        onBack = { vm.closeList() },
        trailing = {
            Text(
                vm.listActionLabel(),
                style = AppType.foldAll,
                color = p.primary,
                modifier = Modifier.clickable { vm.runListAction() },
            )
        },
    ) {
        when {
            mode == "wrong" -> WrongPanel(vm)
            mode.startsWith("topic:") -> TopicPanel(vm, mode.removePrefix("topic:").toInt())
            mode == "weakall" -> WeakAllPanel(vm)
            else -> FavPanel(vm)
        }
    }
}

/** 错题本：科目网格（只列有错题的科目）+ 所选科目的 Day 分组列表 */
@Composable
private fun ColumnScope.WrongPanel(vm: AppVm) {
    val p = LocalPalette.current
    val subs = vm.wrongSubjects()
    if (subs.isEmpty()) {
        EmptyBox("🎉", "错题本已清空，保持住！")
        return
    }
    val cur = vm.listSubj?.takeIf { subs.contains(it) } ?: subs[0]
    vm.listSubj = cur

    // 科目网格（同题库大卡，但不带进度条；计量行换成「N 道错题」，N = 错题选择题数）
    var i = 0
    while (i < subs.size) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            for (k in 0 until 3) {
                val idx = i + k
                if (idx < subs.size) {
                    val short = subs[idx]
                    val sj = vm.tree.first { it.short == short }
                    val n = vm.wrongCountOfSubject(short)
                    SubjCard(
                        short = short,
                        cls = sj.cls,
                        tone = toneOf(sj.cls),
                        meta = "$n 道错题",
                        pct = 0,
                        selected = short == cur,
                        showBar = false,
                        onClick = { vm.chooseListSubj(short) },
                        modifier = Modifier.weight(1f),
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
        i += 3
    }
    Spacer(Modifier.height(2.dp))

    vm.wrongGrouped(cur).forEach { (dayName, list) ->
        DirHead(name = "$cur · $dayName", range = "${list.size} 道错题", tone = toneOf(vm.tree.first { it.short == cur }.cls))
        AppCard(modifier = Modifier.padding(bottom = 16.dp), padding = PaddingValues(vertical = 8.dp)) {
            list.forEachIndexed { idx, qi ->
                // 错题本以选择题为单位：一行 = 一道答错的小题（2026-09-22 老高拍板）
                val t = vm.bigOf(qi) ?: return@forEachIndexed
                val sj = vm.tree[t.first]
                val n = vm.wrongKillOf(qi)
                if (idx > 0) Divider1()
                QRow(
                    stem = vm.quiz[qi].text,
                    src = "${sj.short} · ${sj.day[t.second].name} · 答对 3 次消灭这道题",
                    badges = listOf(if (n > 0) "b-amber" to "已答对 $n/3 次" else "b-red" to "待攻克"),
                    tone = toneOf(sj.cls),
                    showFrom = false,
                    onClick = {
                        vm.closeList()
                        vm.startQuiz(Scope(ScopeKind.SINGLE, si = qi), topic = "错题重练 · 单题")
                    },
                )
            }
        }
    }
    PanelTail("错题按选择题记；所在论述题整题全部答对算 1 次，累计 3 次即可消灭")
}

/** 单个薄弱专题：按正确率从低到高排（TOPICS 里已按此顺序录入） */
@Composable
private fun ColumnScope.TopicPanel(vm: AppVm, ti: Int) {
    val p = LocalPalette.current
    val t = vm.topicGroups().getOrNull(ti) ?: return
    AppCard(padding = PaddingValues(vertical = 8.dp)) {
        t.items.forEachIndexed { i, it ->
            if (i > 0) Divider1()
            QRow(
                stem = it.stem,
                src = it.src,
                badges = listOf("b-red" to "正确率 ${it.v}%"),
                tone = toneOf(subjectClsOf(vm, it.src)),
                onClick = {
                    vm.closeList()
                    vm.scopeFromSrc(it.src)?.let { s -> vm.startQuiz(s) }
                },
            )
        }
        // 尾注在卡片内部（原型把 tail 挂在 card.dir-card 上）
        PanelTail("按正确率从低到高逐个消灭 · 全部答对后自动移出专题")
    }
}

/** 全部薄弱论述题：按专题分组 */
@Composable
private fun ColumnScope.WeakAllPanel(vm: AppVm) {
    vm.topicGroups().forEach { t ->
        DirHead(name = "专题「${t.name}」", range = "${t.items.size} 道薄弱论述题")
        AppCard(modifier = Modifier.padding(bottom = 16.dp), padding = PaddingValues(vertical = 8.dp)) {
            t.items.forEachIndexed { i, it ->
                if (i > 0) Divider1()
                QRow(
                    stem = it.stem,
                    src = it.src,
                    badges = listOf("b-red" to "正确率 ${it.v}%"),
                    tone = toneOf(subjectClsOf(vm, it.src)),
                    onClick = {
                        vm.closeList()
                        vm.scopeFromSrc(it.src)?.let { s -> vm.startQuiz(s, topic = it.src) }
                    },
                )
            }
        }
    }
}

/**
 * 我的收藏面板（原型 renderListDir 的 else 分支）：
 * 先渲染 FAVS 四条演示行，再接真实收藏的题（徽标「⭐ 刚收藏」），尾注在卡片内。
 */
@Composable
private fun ColumnScope.FavPanel(vm: AppVm) {
    val p = LocalPalette.current
    var first = true
    AppCard(padding = PaddingValues(vertical = 8.dp)) {
        FAV_DEMO.forEach { d ->
            if (!first) Divider1()
            first = false
            QRow(
                stem = d.stem,
                src = d.src,
                badges = listOf("b-star" to d.badge),
                tone = toneOf(d.cls),
                onClick = {
                    vm.closeList()
                    vm.startQuiz(Scope(ScopeKind.FAV), topic = d.src)
                },
            )
        }
        // 刷题时点 ⭐ 的题实时进列表（原型按插入顺序追加）
        vm.favIds.forEach { id ->
            val q = vm.quiz[id]
            if (!first) Divider1()
            first = false
            QRow(
                stem = q.text,
                src = q.src,
                badges = listOf("b-star" to "⭐ 刚收藏"),
                tone = toneOf(subjectClsOf(vm, q.kp.getOrNull(0).orEmpty())),
                onClick = {
                    vm.closeList()
                    vm.startQuiz(Scope(ScopeKind.FAV), topic = q.src)
                },
            )
        }
        PanelTail("刷题时点⭐即可把题目收进这里")
    }
}

/** .day-tail —— 面板尾注（挂在卡片内，padding 10px 12px 2px） */
@Composable
private fun PanelTail(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        style = AppType.dayTail, color = p.text3,
        modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 2.dp),
    )
}
