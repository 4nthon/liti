package com.gao.recite.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.components.DirHead
import com.gao.recite.ui.components.DirRow
import com.gao.recite.ui.components.Divider1
import com.gao.recite.ui.components.EmptyBox
import com.gao.recite.ui.components.PlayChevron
import com.gao.recite.ui.components.ProgressBar
import com.gao.recite.ui.components.SectionHead
import com.gao.recite.ui.components.Segmented
import com.gao.recite.ui.components.SubjCard
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.toneOf
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.Scope
import com.gao.recite.vm.ScopeKind

@Composable
fun BankScreen(vm: AppVm) {
    val p = LocalPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp),
    ) {
        Text("题库", style = AppType.pageTitle, color = p.text1)
        Spacer(Modifier.height(4.dp))
        // 页头统计全部实时计算（加科目 / 加 Day 自动更新，同原型 renderSubjChips 的收尾逻辑）
        val dayTotal = vm.tree.sumOf { it.total }
        val bigTotal = vm.tree.sumOf { sj -> sj.day.sumOf { it.big.size } }
        Text(
            "${vm.tree.size} 科 · $dayTotal 个 Day · $bigTotal 道论述题 · 按背诵范围组织",
            style = AppType.pageSub, color = p.text2,
        )
        Spacer(Modifier.height(16.dp))

        // ---------------- 搜索框（原型 .search：胶囊形 / 高 41 = 11+19+11）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(41.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(p.surface)
                .border(1.dp, p.cardBorder, RoundedCornerShape(999.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppIcon(AppIcons.Search, size = 16.dp, tint = p.text3)
            Spacer(Modifier.width(8.dp))
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                if (vm.bankQuery.isEmpty()) {
                    Text("搜索论述题标题 / 知识点关键词", style = AppType.searchTxt, color = p.text3)
                }
                BasicTextField(
                    value = vm.bankQuery,
                    onValueChange = { vm.bankQuery = it },
                    singleLine = true,
                    textStyle = AppType.searchTxt.copy(color = p.text1),
                    cursorBrush = SolidColor(p.primary),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        // ---------------- 科目网格大卡（3 列）
        var si = 0
        while (si < vm.tree.size) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                for (k in 0 until 3) {
                    val idx = si + k
                    if (idx < vm.tree.size) {
                        val subj = vm.tree[idx]
                        val s = vm.statSj(idx)
                        SubjCard(
                            short = subj.short,
                            cls = subj.cls,
                            tone = toneOf(subj.cls),
                            // 卡片只有 ~98dp 宽，两段必须各自成行（同原型 .sc-m 的 <br>），
                            // 否则 Compose 会在汉字中间断开（「· 正 / 确率 82%」）
                            meta = "选择题 ${s.done}/${s.total}\n正确率 ${s.acc}%",
                            pct = s.pct,
                            selected = vm.bankSubject == idx,
                            onClick = { vm.selectSubject(idx) },
                            modifier = Modifier.weight(1f),
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
            si += 3
        }
        // 原来这里还有「背诵模式」小标题撑空隙，标题删掉后直接用 Spacer 补回
        Spacer(Modifier.height(16.dp))

        if (vm.bankQuery.isNotBlank()) {
            // ---------------- 搜索结果
            val hits = vm.searchHits()
            if (hits.isEmpty()) {
                EmptyBox(big = "🔍", text = "没有找到匹配的论述题\n换个关键词试试")
            } else {
                SectionHead("找到 ${hits.size} 条")
                AppCard(padding = PaddingValues(vertical = 8.dp)) {
                    hits.forEachIndexed { i, (si, di, bi) ->
                        val sj = vm.tree[si]
                        val b = sj.day[di].big[bi]
                        val s = vm.statBig(si, di, bi)
                        if (i > 0) Divider1()
                        DirRow(
                            name = b.title,
                            meta = "${sj.short} · ${sj.day[di].name} · ${s.done}/${s.total} 题 · 正确率 ${s.acc}%",
                            pct = null,
                            pctColor = null,
                            tone = toneOf(sj.cls),
                            showPlay = true,
                            onClick = { vm.startQuiz(Scope(ScopeKind.BIG, si, di, bi)) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            return@Column
        }

        // ---------------- 背诵模式卡（「背诵模式」标题与「背题模式」chip 已按 2026-09-22 反馈删除：答题模式统一在设置页切）
        AppCard(
            modifier = Modifier.padding(bottom = 20.dp),
            padding = PaddingValues(14.dp),
        ) {
            val sj = vm.tree[vm.bankSubject]
            val tone = toneOf(sj.cls)
            val d = vm.curDayNode()

            Segmented(
                options = MODES,
                selected = MODES.indexOf(vm.bkMode).coerceAtLeast(0),
                onSelect = { vm.chooseBkMode(MODES[it]) },
            )
            if (vm.bkMode == "随机背诵") {
                Spacer(Modifier.height(10.dp))
                Segmented(
                    options = RAND_LEVELS,
                    selected = if (vm.bkRand == "day") 0 else 1,
                    onSelect = { vm.chooseBkRand(if (it == 0) "day" else "big") },
                )
            }

            if (vm.scopeRowVisible) {
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.surface2)
                        .clickable { vm.openDayDir() }
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Brush.linearGradient(listOf(tone.main, tone.gradEnd)), RoundedCornerShape(999.dp)),
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${sj.short} · ${d?.name ?: vm.bkDay}", style = AppType.scopeT, color = p.text1)
                        Spacer(Modifier.height(2.dp))
                        Text(vm.scopeSubText(), style = AppType.scopeD, color = p.text3, maxLines = 1)
                    }
                    AppIcon(AppIcons.ChevronRight, size = 16.dp, tint = p.text3)
                }
            }

            Spacer(Modifier.height(16.dp))
            // .start-btn：135° 主色渐变 + 0 4px 14px rgba(79,107,255,.28) 投影
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        8.dp, RoundedCornerShape(12.dp),
                        ambientColor = p.primary.copy(alpha = .28f),
                        spotColor = p.primary.copy(alpha = .28f),
                    )
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(p.primary, p.primary2)))
                    .clickable { vm.startCombo() }
                    .padding(vertical = 13.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(vm.startBtnLabel(), style = AppType.startBtn, color = p.onPrimary)
            }
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.dangerSoft)
                    .clickable { vm.startQuiz(Scope(ScopeKind.WRONG_ALL)) }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                Text("⚡ 错题重练 — 只练进错题本的论述题（跨科目）", style = AppType.wrongQuick, color = p.danger)
            }
        }

        // ---------------- 薄弱专题（按专题分组，点进去才展开具体论述题）
        SectionHead("薄弱专题", action = "全部 ›", onAction = { vm.openList("weakall") })
        AppCard(
            modifier = Modifier.padding(bottom = 20.dp),
            padding = PaddingValues(vertical = 8.dp),
        ) {
            vm.topicGroups().forEachIndexed { ti, g ->
                val avg = vm.topicAvg(g)
                val cls = subjectClsOf(vm, g.items.firstOrNull()?.src.orEmpty())
                if (ti > 0) Divider1()
                DirRow(
                    name = "专题「${g.name}」",
                    meta = "${g.items.size} 道薄弱论述题 · 平均正确率 $avg%",
                    pct = "$avg%",
                    pctColor = p.danger,
                    tone = toneOf(cls),
                    showPlay = true,
                    onClick = { vm.openList("topic:$ti") },
                )
            }
        }

        // ---------------- Day 目录（只列最近在学的，最多 3 个 + 查看全部）
        val sj = vm.tree[vm.bankSubject]
        SectionHead("${sj.short} · 最近在学")
        DirHead(name = sj.name, range = sj.range, tone = toneOf(sj.cls))
        AppCard(
            modifier = Modifier.padding(bottom = 0.dp),
            padding = PaddingValues(vertical = 8.dp),
        ) {
            val recent = vm.recentDayIdx(vm.bankSubject)
            if (recent.isEmpty()) {
                DirRow(
                    name = "Day${sj.start}",
                    meta = "未开始 · 点击开始背诵",
                    pct = null, pctColor = null,
                    tone = toneOf(sj.cls), showPlay = true, playAlpha = .45f, todo = true,
                    onClick = { vm.startEmptyDay() },
                )
            } else {
                recent.forEachIndexed { i, di ->
                    val d = sj.day[di]
                    val s = vm.statDay(vm.bankSubject, di)
                    if (i > 0) Divider1()
                    DirRow(
                        name = d.name,
                        meta = "论述题 ${s.started}/${s.bigs} · 选择题 ${s.done}/${s.total} · 正确率 ${s.acc}%",
                        pct = "${s.pct}%",
                        pctColor = p.text2,
                        tone = toneOf(sj.cls),
                        showPlay = true,
                        onClick = { vm.startQuiz(Scope(ScopeKind.DAY, vm.bankSubject, di)) },
                    )
                }
                Divider1()
            }
            DirRow(
                name = "查看全部 ${sj.total} 个 Day",
                meta = "含未开始的 Day · 点行直接开背",
                pct = null, pctColor = null,
                tone = toneOf(sj.cls), showPlay = true, playAlpha = .6f,
                onClick = { vm.openDayDir(pick = false) },
            )
        }
        Text(
            "科目在搜索栏下方选择 · 加英语 / 时政等新科目会自动出现 · Day 会随背诵内容不断增加",
            style = AppType.dayTail, color = p.text3,
            modifier = Modifier.padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

private val MODES = listOf("顺序背诵", "随机背诵")
private val RAND_LEVELS = listOf("随机到 Day", "Day 内随机论述题")

/** 由「马原 · Day3 · 论述题「…」」推出科目主题色（同原型 subjCls）。题库页与题单面板共用。 */
fun subjectClsOf(vm: AppVm, src: String): String {
    val short = src.substringBefore(" · ")
    return vm.tree.firstOrNull { it.short == short }?.cls ?: "blue"
}
