# 题库导入工具

App 里的题目**不是写死在 Kotlin 里的**，而是从 `app/src/main/assets/qbank.tsv` 读出来的。
本目录的脚本把「人写的题目 txt」转换成这个数据文件。仓库自带的示例题库
（`tools/qbank_src/` 里的 Day1.txt / Day2.txt）就是用它生成的，可作为格式参考。

```
tools/qbank_src/DayN.txt
        │  tools/import_qbank.py --emit app/src/main/assets/qbank.tsv
        ▼
app/src/main/assets/qbank.tsv   ← App 启动时由 data/Bank.kt 读进来
```

## 快速上手

1. 把你的题目 txt 放进 `tools/qbank_src/`（一天一个文件，文件名含 Day 号，如 `Day1.txt`）；
2. 运行：

```bash
cd LitiApp
python tools/import_qbank.py --emit app/src/main/assets/qbank.tsv
```

3. 重新构建 App 即可。`--src` 参数可指定其他题目目录：

```bash
python tools/import_qbank.py --src <你的题目目录> --emit app/src/main/assets/qbank.tsv
```

## 脚本命令

| 命令 | 作用 | 产物 |
| --- | --- | --- |
| `--analyze` | 体检：每个 txt 的 Day、小标题、题数、选项数、缺答案/缺解析、重复题号 | `tools/import_analyze.txt` |
| `--probe-exp` | 看「解析」是纯原文引用还是另外写了讲解 | `tools/import_exp.txt` |
| `--emit <out>` | 生成 App 用的数据文件 | `<out>` + `tools/import_emit.txt`（统计） |

## 答案键校验（--emit 之后建议跑一遍）

```bash
python tools/check_answers.py
```

原理：「背诵原文」= 题干填上正确答案后的原句，所以答案键指向的选项内容必须能在原文里找到。
对不上的题会报「答案键错误」，回 txt 改 `答案：X` 再重跑 `--emit` 即可。

## txt 书写格式

```
【小标题】                     ← 一个论述题（App 的第三级）
1、题干里用 ____ 表示空位
A. 选项一                      ← 也可能是 A、选项一
B. 选项二
答案：A                        ← 也可能是「正确答案：A」
解析：填充后的整句              ← 也写「解析：原文「…」」，外壳会被剥掉
```

兼容点：

- 空位标记（`____` / `______` / `【 】` / `[]`）保持原样不转换
- 多空选项的分隔符 ` \ ` 与 ` / ` → 统一成 ` / `
- 答案前缀 `答案：` 与 `正确答案：`
- 解析里 `原文「…」` 的外壳会剥掉，作为 App 的「背诵原文」
- 中文词之间因为填空加上的空格会去掉
- 解析缺省或与题干相同时，脚本会自动把正确答案回填进题干作为背诵原文

## 数据约定

- **一天一个 txt**，文件名里的数字就是 Day 号（`Day7.txt` → `Day7`）。
- 一个 `【小标题】` = 一个论述题；它下面的题就是这道论述题的题。
- 题号在每个小标题里从 1 开始，脚本不依赖题号，按出现顺序排。
- App 里的 `论述题` 计数 = 小标题个数；`选择题` 计数 = 题库里的题数。

## 科目与高级定制

- 当前版本只挂一个科目（马原），科目名/短名在
  `app/src/main/java/com/gao/recite/data/Bank.kt` 顶部的 `MA_NAME / MA_SHORT / MA_CLS` 常量里。
- 要支持多科目，可参照 `Bank.kt` 的装载逻辑为每个科目各生成一份 tsv 并扩展装载器。
