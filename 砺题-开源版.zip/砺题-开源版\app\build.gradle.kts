plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.gao.recite"
    compileSdk = 34
    buildToolsVersion = "34.0.0"

    signingConfigs {
        // 正式签名是可选的：不配置时 release 包用 debug 签名，直接可装可跑。
        // 要出正式签名包时，在 gradle.properties（勿提交）或环境变量里配置 LITI_* 四项，
        // 详见项目 README「签名」一节。
        if (project.hasProperty("LITI_STORE_FILE")) {
            create("release") {
                storeFile = rootProject.file(property("LITI_STORE_FILE") as String)
                storePassword = property("LITI_STORE_PASSWORD") as String
                keyAlias = property("LITI_KEY_ALIAS") as String
                keyPassword = property("LITI_KEY_PASSWORD") as String
            }
        }
    }

    defaultConfig {
        applicationId = "com.gao.liti"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = if (signingConfigs.findByName("release") != null)
                signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.compose.ui:ui:1.7.0")
    implementation("androidx.compose.ui:ui-graphics:1.7.0")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.0")
    implementation("androidx.compose.foundation:foundation:1.7.0")
    implementation("androidx.compose.material3:material3:1.3.0")
    debugImplementation("androidx.compose.ui:ui-tooling:1.7.0")
}
