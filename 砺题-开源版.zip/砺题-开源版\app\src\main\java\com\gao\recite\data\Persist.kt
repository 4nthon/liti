package com.gao.recite.data

import android.content.Context
import java.io.File
import java.security.MessageDigest

/**
 * 稳定 ID 内部的分隔符。用不可见控制字符，避免与题库文本里随处可见的「 · 」「 」撞车。
 */
const val ID_SEP = "\u0001"

private const val HEX = "0123456789abcdef"

/**
 * 内容指纹：[s] 的 SHA-1 前 8 字节，转成 16 位十六进制。
 *
 * 为什么不用 `QUIZ` 数组下标当主键：题库是**分批增量**给的，往 `qbank.tsv` 里追加新 Day
 * 会让原有题目的下标整体后移，用下标存下来的历史答题记录就会串到别的题上去。
 * 用「科目/论述题标题 + 题干」派生出来的指纹，追加新题时已有记录的键一个都不会变。
 */
fun stableHash(s: String): String {
    val d = MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8))
    val sb = StringBuilder(16)
    for (i in 0 until 8) {
        val b = d[i].toInt()
        sb.append(HEX[(b shr 4) and 0xF]).append(HEX[b and 0xF])
    }
    return sb.toString()
}

// ---------------------------------------------------------------- 快照里的一行

/** 一道论述题的累计进度 */
class BigLine(val id: String, val done: Int, val correct: Int)

/** 错题本里的一道论述题 */
class WrongLine(val id: String, val kill: Int, val title: String)

/** 会话里一道题的作答记录（pos = 在 qSet 里的位置） */
class AnsLine(val pos: Int, val sel: Int, val right: Boolean, val confirmed: Boolean)

/** 会话里某道论述题本轮已答对的题（值是题目的稳定 ID） */
class SetLine(val bigId: String, val ids: List<String>)

/** 会话里某题的选项展示顺序（乱序设置开启时才有） */
class OrdLine(val pos: Int, val order: List<Int>)

/** 按日历史：某天的答题数 / 答对数 / 用时秒数（分析页折线图、打卡日历、用时统计的数据源） */
class DayLine(val date: String, val ans: Int, val cor: Int, val secs: Int)

/**
 * 落盘的全部进度。
 *
 * 格式是行式 TSV —— 和题库同一套思路：可读、能直接 diff、不用引序列化库、出错一眼看得出是哪一行。
 *
 * ```
 * v1
 * TS   20260922  20260921                       日期口径（当天 / 本周一），用来判断要不要把当日、本周计数归零
 * CFG  light  0  1                              外观 / 选项乱序 / 显示计时
 * C    37  30  12  37  7  1                     累计答 / 累计对 / 今日 / 本周 / 本周错 / 已消灭
 * B    <论述题ID>  5  4                         论述题：做过 5 题、对 4 题
 * W    <题目ID>  2  <题干原文>                  错题本：一行 = 一道错题选择题；数字 = 它所在论述题的整题全对次数（满 3 次消灭这批错题）
 * F    <题目ID>                                 收藏
 * L    <论述题ID>                               最近答过的那道论述题（首页卡片落点）
 * S    顺序/…   <范围ID>  <入口文案>  0  0  11  63   会话：范围 / 文案 / 背题模式 / 停在结果页 / 题位 / 秒数
 * Q    0  <题目ID>                              会话题目表（按位置）
 * A    0  2  1  1                               某位置的作答：选了 2、答对、已判分
 * N    0                                        该位置已经计过分（避免续答后重复计数）
 * G    <论述题ID>  <题目ID>,<题目ID>             本轮已答对的题（整题全对满 3 次消灭）
 * O    0  2,0,3,1                               该位置的选项展示顺序
 * H    20260922  12  10  1830                   按日历史：答题数 / 答对数 / 用时秒（分析页折线、日历、用时的数据源）
 * ```
 *
 * **所有键都是内容派生的稳定 ID，一个数组下标都没有。**
 */
class ProgressSnapshot {

    companion object {
        /** 格式版本。改结构就 +1，老数据会被丢弃（宁可重来，也不要把错的进度读进来）。 */
        const val VERSION = 2

        private fun esc(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')

        fun decode(text: String): ProgressSnapshot {
            val s = ProgressSnapshot()
            var sawHeader = false
            text.lineSequence().forEach { line ->
                if (line.isEmpty()) return@forEach
                val f = line.split('\t')
                if (!sawHeader) {
                    sawHeader = true
                    // 第一行必须是 `v<数字>`。读不出来就当成坏文件（version = -1），
                    // 调用方看到版本不符会整段丢弃 —— 宁可从头记，也不要把错的进度读进来。
                    val v = f.getOrNull(0)?.removePrefix("v")?.toIntOrNull()
                    s.version = v ?: -1
                    if (v != VERSION) return s
                    return@forEach
                }
                when (f[0]) {
                    "TS" -> {
                        s.todayStamp = f.getOrNull(1).orEmpty()
                        s.weekStamp = f.getOrNull(2).orEmpty()
                    }
                    "CFG" -> {
                        s.themeMode = f.getOrNull(1) ?: "light"
                        s.optShuffle = f.getOrNull(2) == "1"
                        s.showTimer = f.getOrNull(3) != "0"
                        s.quizMode = f.getOrNull(4) ?: "back"
                    }
                    "C" -> {
                        s.totalAnswered = f.getOrNull(1)?.toIntOrNull() ?: 0
                        s.totalCorrect = f.getOrNull(2)?.toIntOrNull() ?: 0
                        s.todayCount = f.getOrNull(3)?.toIntOrNull() ?: 0
                        s.weekCount = f.getOrNull(4)?.toIntOrNull() ?: 0
                        s.weekWrong = f.getOrNull(5)?.toIntOrNull() ?: 0
                        s.killedCount = f.getOrNull(6)?.toIntOrNull() ?: 0
                    }
                    "B" -> f.getOrNull(1)?.let {
                        s.bigs.add(BigLine(it, f.getOrNull(2)?.toIntOrNull() ?: 0, f.getOrNull(3)?.toIntOrNull() ?: 0))
                    }
                    "W" -> f.getOrNull(1)?.let {
                        s.wrongs.add(WrongLine(it, f.getOrNull(2)?.toIntOrNull() ?: 0, f.getOrNull(3).orEmpty()))
                    }
                    "F" -> f.getOrNull(1)?.let { s.favs.add(it) }
                    "L" -> s.lastBigId = f.getOrNull(1).orEmpty()
                    "S" -> {
                        s.hasSession = true
                        s.sScopeKind = f.getOrNull(1).orEmpty()
                        s.sScopeRef = f.getOrNull(2).orEmpty()
                        s.sTopic = f.getOrNull(3).orEmpty()
                        s.sBackMode = f.getOrNull(4) == "1"
                        s.sResultPhase = f.getOrNull(5) == "1"
                        s.sQIdx = f.getOrNull(6)?.toIntOrNull() ?: 0
                        s.sSeconds = f.getOrNull(7)?.toIntOrNull() ?: 0
                    }
                    "Q" -> f.getOrNull(2)?.let { s.sQIds.add(it) }
                    "A" -> {
                        val pos = f.getOrNull(1)?.toIntOrNull()
                        if (pos != null) s.sAnswers.add(
                            AnsLine(
                                pos,
                                f.getOrNull(2)?.toIntOrNull() ?: 0,
                                f.getOrNull(3) == "1",
                                f.getOrNull(4) == "1",
                            ),
                        )
                    }
                    "N" -> f.getOrNull(1)?.toIntOrNull()?.let { s.sCounted.add(it) }
                    "G" -> f.getOrNull(1)?.let { id ->
                        val ids = f.getOrNull(2).orEmpty().split(',').filter { it.isNotEmpty() }
                        s.sBigProgress.add(SetLine(id, ids))
                    }
                    "O" -> {
                        val pos = f.getOrNull(1)?.toIntOrNull()
                        if (pos != null) {
                            val o = f.getOrNull(2).orEmpty().split(',').mapNotNull { it.toIntOrNull() }
                            s.sOptOrder.add(OrdLine(pos, o))
                        }
                    }
                    "H" -> f.getOrNull(1)?.let {
                        s.days.add(
                            DayLine(
                                it,
                                f.getOrNull(2)?.toIntOrNull() ?: 0,
                                f.getOrNull(3)?.toIntOrNull() ?: 0,
                                f.getOrNull(4)?.toIntOrNull() ?: 0,
                            ),
                        )
                    }
                }
            }
            return s
        }
    }

    var version = VERSION

    var todayStamp = ""
    var weekStamp = ""
    var themeMode = "light"
    var optShuffle = false
    var showTimer = true

    /** 答题模式：back = 背题（点屏显答案）/ test = 测验（点选项判分自动下一题） */
    var quizMode = "back"

    var totalAnswered = 0
    var totalCorrect = 0
    var todayCount = 0
    var weekCount = 0
    var weekWrong = 0
    var killedCount = 0

    var lastBigId = ""

    val bigs = mutableListOf<BigLine>()
    val wrongs = mutableListOf<WrongLine>()
    val favs = mutableListOf<String>()

    var hasSession = false
    var sScopeKind = ""
    var sScopeRef = ""
    var sTopic = ""
    var sBackMode = false
    var sResultPhase = false
    var sQIdx = 0
    var sSeconds = 0

    val sQIds = mutableListOf<String>()
    val sAnswers = mutableListOf<AnsLine>()
    val sCounted = mutableListOf<Int>()
    val sBigProgress = mutableListOf<SetLine>()
    val sOptOrder = mutableListOf<OrdLine>()
    val days = mutableListOf<DayLine>()

    fun encode(): String {
        val sb = StringBuilder(4096)
        sb.append('v').append(version).append('\n')
        sb.append("TS\t").append(todayStamp).append('\t').append(weekStamp).append('\n')
        sb.append("CFG\t").append(themeMode).append('\t')
            .append(if (optShuffle) 1 else 0).append('\t')
            .append(if (showTimer) 1 else 0).append('\t')
            .append(quizMode).append('\n')
        sb.append("C\t").append(totalAnswered).append('\t').append(totalCorrect).append('\t')
            .append(todayCount).append('\t').append(weekCount).append('\t')
            .append(weekWrong).append('\t').append(killedCount).append('\n')
        bigs.forEach { sb.append("B\t").append(esc(it.id)).append('\t').append(it.done).append('\t').append(it.correct).append('\n') }
        wrongs.forEach {
            sb.append("W\t").append(esc(it.id)).append('\t').append(it.kill).append('\t').append(esc(it.title)).append('\n')
        }
        favs.forEach { sb.append("F\t").append(esc(it)).append('\n') }
        if (lastBigId.isNotEmpty()) sb.append("L\t").append(esc(lastBigId)).append('\n')
        if (hasSession) {
            sb.append("S\t").append(sScopeKind).append('\t').append(esc(sScopeRef)).append('\t')
                .append(esc(sTopic)).append('\t')
                .append(if (sBackMode) 1 else 0).append('\t')
                .append(if (sResultPhase) 1 else 0).append('\t')
                .append(sQIdx).append('\t').append(sSeconds).append('\n')
            sQIds.forEachIndexed { i, id -> sb.append("Q\t").append(i).append('\t').append(esc(id)).append('\n') }
            sAnswers.forEach {
                sb.append("A\t").append(it.pos).append('\t').append(it.sel).append('\t')
                    .append(if (it.right) 1 else 0).append('\t').append(if (it.confirmed) 1 else 0).append('\n')
            }
            sCounted.forEach { sb.append("N\t").append(it).append('\n') }
            sBigProgress.forEach {
                sb.append("G\t").append(esc(it.bigId)).append('\t').append(it.ids.joinToString(",")).append('\n')
            }
            sOptOrder.forEach {
                sb.append("O\t").append(it.pos).append('\t').append(it.order.joinToString(",")).append('\n')
            }
        }
        // 按日历史（H 行是追加式的：老文件没有 H 行也能读，新文件多了 H 行老版本也只是忽略）
        days.forEach {
            sb.append("H\t").append(esc(it.date)).append('\t').append(it.ans).append('\t')
                .append(it.cor).append('\t').append(it.secs).append('\n')
        }
        return sb.toString()
    }
}

/**
 * 进度文件读写。放在 `filesDir`（应用私有目录），不需要任何权限，也不需要导入导出界面。
 */
object ProgressStore {

    private const val FILE = "progress.tsv"

    fun read(ctx: Context): String? = runCatching {
        val f = File(ctx.filesDir, FILE)
        if (f.exists()) f.readText(Charsets.UTF_8) else null
    }.getOrNull()

    /**
     * 先写临时文件再改名 —— 直接覆盖写如果中途被杀进程，会留下半个文件，
     * 下次启动解析失败就等于进度全丢。改名是原子的，要么旧内容要么新内容。
     */
    fun write(ctx: Context, text: String) {
        runCatching {
            val dir = ctx.filesDir
            val target = File(dir, FILE)
            val tmp = File(dir, "$FILE.tmp")
            tmp.writeText(text, Charsets.UTF_8)
            if (target.exists() && !target.delete()) return
            if (!tmp.renameTo(target)) {
                // 极少数机型 rename 失败，退化成直接写
                target.writeText(text, Charsets.UTF_8)
                tmp.delete()
            }
        }
    }
}
