package com.gao.recite.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.IconSpec
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.theme.SubjectTone

/**
 * 原型 .card —— 白底 / 圆角 16 / 1px 描边 / 阴影。
 * 注意：原型里 .card **没有统一内边距**，各卡片自己声明
 * （.chart-card 16、.bk-hero2 16、.continue 12/16、.dir-card 8/0、.stats 12/0 …），
 * 所以这里必须把内边距做成参数，不能写死。
 */
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit,
) {
    val p = LocalPalette.current
    val base = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(p.surface)
        .border(1.dp, p.cardBorder, RoundedCornerShape(16.dp))
        .padding(padding)
    // 注意：卡片内容必须纵向排列。这里用 Column 而不是 Box ——
    // 多处卡片会把 forEach 产生的多个子项直接交给 AppCard，
    // 若宿主是 Box，所有子项会叠在同一位置（曾经出现过文字重叠的 bug）。
    Column(modifier = if (onClick != null) modifier.then(base).clickable { onClick() } else modifier.then(base)) {
        content()
    }
}

/** 1px 分隔线（原型里到处用 var(--border) 的 1px 线） */
@Composable
fun Divider1(modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Box(modifier.fillMaxWidth().height(1.dp).background(p.cardBorder))
}

/** 渐变进度条，默认高 6（原型 .progress-track） */
@Composable
fun ProgressBar(
    pct: Int,
    color: Color,
    gradEnd: Color? = null,
    modifier: Modifier = Modifier,
    height: Dp = 6.dp,
) {
    val p = LocalPalette.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(999.dp))
            .background(p.track),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(pct.coerceIn(0, 100) / 100f)
                .height(height)
                .clip(RoundedCornerShape(999.dp))
                .background(
                    if (gradEnd != null) Brush.horizontalGradient(listOf(color, gradEnd)) else Brush.horizontalGradient(listOf(color, color)),
                ),
        )
    }
}

/**
 * .sec-head —— 左侧区块标题（15px/700），右侧动作（13px/500 primary，无边框无底色）。
 * 原型 margin 左右各 4px，而页面本身有 16px 内边距，所以这里合计 20px。
 */
@Composable
fun SectionHead(
    title: String,
    action: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = AppType.secHead,
            color = p.text1,
            modifier = Modifier.weight(1f),
        )
        if (action != null) {
            Text(
                action,
                style = AppType.foldAll,
                color = p.primary,
                modifier = Modifier.clickable { onAction?.invoke() },
            )
        }
    }
}

/** .icon-btn —— 44×44 / 圆角 12 / surface-2 底 + 1px 描边 / 图标 20px */@Composable
fun IconButton24(
    spec: IconSpec,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 20.dp,
) {
    val p = LocalPalette.current
    Box(
        modifier = modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(p.surface2)
            .border(1.dp, p.cardBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        AppIcon(spec, size = size, strokeWidth = 1.8f, tint = tint)
    }
}

/** .play-btn —— 22×22 的 ">" 小箭头（13px、线宽 2.6），颜色跟科目走，没有底色 */
@Composable
fun PlayChevron(
    tone: SubjectTone,
    modifier: Modifier = Modifier,
    alpha: Float = 1f,
    onClick: (() -> Unit)? = null,
) {
    Box(
        modifier = modifier
            .size(22.dp)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        AppIcon(
            com.gao.recite.ui.icons.AppIcons.ChevronRight,
            size = 13.dp,
            strokeWidth = 2.6f,
            tint = tone.main.copy(alpha = alpha),
        )
    }
}

/**
 * .stat 单元格：图标（或空）+ 数字（+ em 后缀）+ 说明，配色内数字用图标色。
 * 原型 .stat .num em = 11px/500/--text-3。
 */
@Composable
fun StatCell(
    icon: IconSpec?,
    tint: Color,
    num: String,
    suffix: String?,
    label: String,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        if (icon != null) {
            AppIcon(icon, size = 17.dp, strokeWidth = 1.8f, tint = tint)
            Spacer(Modifier.height(5.dp))
        }
        Text(
            buildAnnotatedString {
                append(num)
                if (!suffix.isNullOrEmpty()) {
                    pushStyle(SpanStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, color = p.text3))
                    append(suffix)
                    pop()
                }
            },
            style = AppType.statNum,
            // 原型 .stat .num{color:var(--text-1)}：数字是深色，只有图标跟科目色走
            color = p.text1,
        )
        Spacer(Modifier.height(3.dp))
        Text(label, style = AppType.statLbl, color = p.text2)
    }
}

/**
 * 一组计量格，格与格之间有 1px 竖线（原型 .stat:not(:last-child)::after）。
 * dividerHeightRatio 控制竖线高度比例（首页 68%、分析页 68%、结果页 60%）。
 */
@Composable
fun StatRow(
    modifier: Modifier = Modifier,
    dividerRatio: Float = 0.68f,
    content: @Composable () -> Unit,
) {
    Row(
        modifier = modifier.fillMaxWidth().height(IntrinsicSize.Min),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        content()
    }
}

/** 计量格之间的竖线 */
@Composable
fun StatDivider(ratio: Float = 0.68f) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .width(1.dp)
            .fillMaxHeight(ratio)
            .background(p.cardBorder),
    )
}

/** 空态块 .empty —— 1.5px 虚线描边 + 居中说明 + 可选大图标 */
@Composable
fun EmptyBox(big: String?, text: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.5.dp,
                color = p.track,
                shape = RoundedCornerShape(16.dp),
            )
            .padding(horizontal = 16.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (big != null) {
            Text(big, style = AppType.emptyBig, color = p.text3)
            Spacer(Modifier.height(8.dp))
        }
        Text(text, style = AppType.cap, color = p.text3)
    }
}

/**
 * .subj-card —— 题库页科目网格大卡（3 列）：
 * 首字方块（28×28 / 圆角 9 / 科目渐变底 / 白色 13px 首字）+ 科目名 15px/700
 * + 计量行 11px/--text-3 + 底部 3px 进度条；选中 = 软色底 + 1.5px 科色内描边。
 */
@Composable
fun SubjCard(
    short: String,
    cls: String,
    tone: SubjectTone,
    meta: String,
    pct: Int,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showBar: Boolean = true,
) {
    val p = LocalPalette.current
    val onTitle = when {
        !selected -> p.text1
        cls == "amber" -> Color(0xFFD97706)
        cls == "green" -> Color(0xFF16A34A)
        else -> p.primary
    }
    val bg = if (selected) tone.soft else p.surface
    val ring = when {
        !selected -> p.cardBorder
        cls == "amber" -> Color(0xFFF59E0B)
        cls == "green" -> Color(0xFF22C55E)
        else -> p.primary
    }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(13.dp))
            .background(bg)
            .border(if (selected) 1.5.dp else 1.dp, ring, RoundedCornerShape(13.dp))
            .clickable { onClick() }
            .padding(11.dp),
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Brush.linearGradient(listOf(tone.main, tone.gradEnd))),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                short.take(1),
                style = AppType.subjIc,
                color = Color.White,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(short, style = AppType.subjT, color = onTitle, maxLines = 1)
        Spacer(Modifier.height(1.dp))
        // .sc-m 在原型里是 display:block（不截断，允许换两行）
        Text(meta, style = AppType.subjM, color = p.text3)
        if (showBar) {
            Spacer(Modifier.height(7.dp))
            ProgressBar(pct, tone.main, tone.gradEnd, height = 3.dp)
        }
    }
}

/** .dir-head —— 目录分组头：科目点 + 名称（13px/700）+ 右侧范围说明（11px/--text-3） */
@Composable
fun DirHead(
    name: String,
    range: String,
    tone: SubjectTone? = null,
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (tone != null) {
            Box(
                Modifier
                    .size(10.dp)
                    .background(Brush.linearGradient(listOf(tone.main, tone.gradEnd)), CircleShape),
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(name, style = AppType.dirHead, color = p.text1, modifier = Modifier.weight(1f), maxLines = 1)
        Spacer(Modifier.width(8.dp))
        Text(range, style = AppType.dirMeta, color = p.text3, maxLines = 1)
    }
}

/**
 * .dir-row —— 目录行：名称 + 计量行 + 右侧百分比 + 可选 ">" 箭头。
 * 行与行之间自动加 1px 分隔线（由调用方在 card 内用 Divider1 处理），
 * todo 态名称降为 --text-2 / 500。
 */
@Composable
fun DirRow(
    name: String,
    meta: String,
    pct: String?,
    pctColor: Color?,
    tone: SubjectTone?,
    showPlay: Boolean,
    playAlpha: Float = 1f,
    todo: Boolean = false,
    selected: Boolean = false,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (selected) Modifier.background(p.primarySoft) else Modifier)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                name,
                style = if (todo) AppType.dirNameTodo else AppType.dirName,
                color = if (todo) p.text2 else p.text1,
                maxLines = 1,
            )
            Spacer(Modifier.height(2.dp))
            Text(meta, style = AppType.dirMeta, color = p.text3, maxLines = 1)
        }
        if (pct != null) {
            Spacer(Modifier.width(10.dp))
            Text(pct, style = AppType.dirMeta, color = pctColor ?: p.text2)
        }
        if (showPlay && tone != null) {
            Spacer(Modifier.width(4.dp))
            PlayChevron(tone, alpha = playAlpha)
        }
    }
}

/**
 * .q-row —— 题单行：题干（最多两行）+ 来源 + 徽标，右侧 ">" 箭头。
 * 用在题本「最近错题」、错题本/收藏抽屉、薄弱专题列表。
 */
@Composable
fun QRow(
    stem: String,
    src: String,
    badges: List<Pair<String, String>>,
    tone: SubjectTone,
    onClick: () -> Unit,
    /** 原型 qRow() 会在来源前加「来自 」；bigRow()（错题本行）不加 */
    showFrom: Boolean = true,
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(stem, style = AppType.qStem, color = p.text1, maxLines = 2)
            Spacer(Modifier.height(3.dp))
            Text(if (showFrom) "来自 $src" else src, style = AppType.dirMeta, color = p.text3, maxLines = 1)
            if (badges.isNotEmpty()) {
                Spacer(Modifier.height(5.dp))
                Row {
                    badges.forEach { (cls, label) ->
                        Badge(cls, label)
                        Spacer(Modifier.width(6.dp))
                    }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        PlayChevron(tone)
    }
}

/** .q-badge —— b-red / b-blue / b-star / b-plain（原型 b-amber 没有样式，等价于无底纯文字） */
@Composable
fun Badge(cls: String, label: String) {
    val p = LocalPalette.current
    val (bg, fg) = when (cls) {
        "b-red" -> p.dangerSoft to p.danger
        "b-blue" -> p.primarySoft to p.primary
        "b-star" -> Color(0x1FF59E0B) to Color(0xFFF59E0B)
        else -> Color.Transparent to p.text2
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(bg)
            .padding(horizontal = 7.dp, vertical = 2.dp),
    ) {
        Text(label, style = AppType.qBadge, color = fg)
    }
}

@Composable
fun SmallIconLabel(icon: IconSpec, text: String, tint: Color, size: Dp = 13.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        AppIcon(icon, size = size, strokeWidth = 2f, tint = tint)
        Spacer(Modifier.width(5.dp))
        Text(text, style = AppType.mini, color = tint)
    }
}

@Composable
fun MetaLine(text: String, color: Color? = null, size: TextUnit = 11.sp, maxLines: Int = 2) {
    val p = LocalPalette.current
    Text(text, style = AppType.mini, color = color ?: p.text2, fontSize = size, maxLines = maxLines)
}

/** 半屏底部抽屉外壳（设置抽屉用），对应原型 .sheet-mask / .sheet */
@Composable
fun BottomSheet(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x660A0C14))
                .clickable { onDismiss() },
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(p.surface, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                .padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 34.dp),
            content = content,
        )
    }
}

/** 抽屉标题 + 副标题，对应 .sheet h3 / .sheet .s-sub */
@Composable
fun SheetHeader(title: String, sub: String? = null) {
    val p = LocalPalette.current
    Text(title, style = AppType.sheetTitle, color = p.text1)
    if (sub != null) {
        Spacer(Modifier.height(4.dp))
        Text(sub, style = AppType.sheetSub, color = p.text3, maxLines = 1)
    }
    Spacer(Modifier.height(14.dp))
}

/**
 * 分段控件 .seg：容器 surface-2 / 圆角 11 / 内边距 3 / 间距 3；
 * 按钮高 36、圆角 9、13px/600；选中 = surface 底 + text-1 字色。
 * 注意：原型里 .seg 的这条规则写在后面，会覆盖前面那条（后者 .on 字色是 text-1 而不是 primary），
 * 所以首页/题库/设置三处段控的选中字色都应该是 --text-1。
 */
@Composable
fun Segmented(
    options: List<String>,
    selected: Int,
    modifier: Modifier = Modifier,
    onSelect: (Int) -> Unit,
) {
    val p = LocalPalette.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(p.surface2, RoundedCornerShape(11.dp))
            .padding(3.dp),
    ) {
        options.forEachIndexed { i, label ->
            if (i > 0) Spacer(Modifier.width(3.dp))
            val on = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .then(
                        if (on) Modifier
                            .shadow(2.dp, RoundedCornerShape(9.dp), ambientColor = Color(0x1F0A0C14), spotColor = Color(0x1F0A0C14))
                            .background(p.surface)
                        else Modifier,
                    )
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = AppType.segBtn, color = if (on) p.text1 else p.text2, maxLines = 1)
            }
        }
    }
}

/** 开关 .switch：44x26，圆角 13，滑块 20px 白色，位移 18 */
@Composable
fun AppSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier = Modifier
            .size(44.dp, 26.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(if (checked) p.primary else p.surface2)
            .clickable { onChange(!checked) },
    ) {
        Box(
            modifier = Modifier
                .offset(x = if (checked) 18.dp else 0.dp)
                .padding(3.dp)
                .size(20.dp)
                .background(Color.White, CircleShape),
        )
    }
}

/** 设置分组标题 .set-label */
@Composable
fun SetLabel(text: String) {
    val p = LocalPalette.current
    Text(
        text,
        style = AppType.setLabel,
        color = p.text3,
        modifier = Modifier.padding(top = 14.dp, bottom = 8.dp),
    )
}

/** 设置行 .set-row：标题 + 说明 + 右侧开关 */
@Composable
fun SetRow(
    title: String,
    desc: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    showDivider: Boolean = true,
) {
    val p = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = AppType.setRowT, color = p.text1)
            Spacer(Modifier.height(2.dp))
            Text(desc, style = AppType.setRowD, color = p.text3)
        }
        Spacer(Modifier.width(12.dp))
        AppSwitch(checked, onChange)
    }
    if (showDivider) Divider1()
}

/**
 * 层级计量行（原型 .head-meta / .ch-meta / .sec-meta）：
 * 基础色 --text-3，数字加粗点亮为 --text-1，段之间用 · 连接。
 */
@Composable
fun MetaStat(
    parts: List<Pair<String, String>>,
    color: Color? = null,
    fontSize: Dp = 11.dp,
    maxLines: Int = 2,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val c = color ?: p.text3
    val text = buildAnnotatedString {
        parts.forEachIndexed { i, (label, value) ->
            // 段间用「 · 」分隔（两侧留空格）——紧贴数字会挤成一团，11px 下尤其明显
            if (i > 0) append(" · ")
            append(label)
            // 原型写作 `Day <b>4/14</b>`——标签与数值之间有一个空格，少了他会看出「Day4/14」不对
            append(" ")
            pushStyle(SpanStyle(fontWeight = FontWeight.Bold, color = p.text1))
            append(value)
            pop()
        }
    }
    Text(
        text,
        modifier = modifier,
        style = AppType.mini.copy(fontSize = fontSize.value.sp, lineHeight = 16.sp, color = c),
        maxLines = maxLines,
    )
}

@Composable
fun StatGrid(items: List<Triple<String, String, Color>>) {
    val p = LocalPalette.current
    AppCard {
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, (num, lbl, color) ->
                if (i > 0) StatDivider(0.6f)
                Column(
                    Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(num, style = AppType.resultStatNum, color = color)
                    Spacer(Modifier.height(2.dp))
                    Text(lbl, style = AppType.mini, color = p.text2)
                }
            }
        }
    }
}
