package com.gao.recite.data

import android.content.Context
import java.io.File

/**
 * 题库装载。
 *
 * 题库数据按优先级从两处来（都是行式 TSV：D 行 = Day、B 行 = 论述题、Q 行 = 选择题）：
 *
 * 1. `filesDir/qbank_imported.tsv` —— App 内「导入题库」生成的文件（[QbankParser] 解析
 *    用户选择的 DayN.txt 后落盘）。存在则优先使用；
 * 2. `assets/qbank.tsv` —— 仓库自带的**示例题库**（马原基础概念，仅演示结构与流程）。
 *
 * 装载只在 [ensure] 里做一次（进程启动时）；导入 / 恢复示例后通过重启应用重新装载。
 * [tree] / [quiz] 在装载前是空列表，所以 `Scope.title()` 这类顶层引用不会因为调用顺序崩掉。
 */
object Bank {

    /** 马原科目的展示元信息（Day 数与论述题数是从题库数据算出来的，不写死） */
    const val MA_NAME = "马克思主义基本原理"
    const val MA_SHORT = "马原"
    const val MA_CLS = "blue"

    var tree: List<Subject> = emptyList()
        private set

    var quiz: List<Question> = emptyList()
        private set

    var maDayCount: Int = 0
        private set

    var maBigCount: Int = 0
        private set

    private var loaded = false

    private const val ASSET = "qbank.tsv"

    /** 导入题库的落盘位置（存在即优先于 assets 示例） */
    fun importedFile(ctx: Context): File = File(ctx.filesDir, "qbank_imported.tsv")

    fun ensure(ctx: Context) {
        if (loaded) return
        loaded = true
        val imp = importedFile(ctx)
        build(
            if (imp.exists()) imp.bufferedReader(Charsets.UTF_8).useLines { parseTsv(it) }
            else parse(ctx),
        )
    }

    // ------------------------------------------------------------------ 解析 TSV

    /** 一道题：题干 / 选项 / 正确答案下标 / 背诵原文 */
    private class Row(val stem: String, val opts: List<String>, val ans: Int, val root: String)

    /** 一个论述题：名字 + 题目 */
    private class Big(val title: String, val rows: MutableList<Row> = mutableListOf())

    /** 一个 Day：名字 + 论述题 */
    private class Day(val name: String, val bigs: MutableList<Big> = mutableListOf())

    private fun parse(ctx: Context): List<Day> =
        ctx.assets.open(ASSET).bufferedReader(Charsets.UTF_8).useLines { parseTsv(it) }

    private fun parseTsv(lines: Sequence<String>): List<Day> {
        val days = mutableListOf<Day>()
        lines.forEach { line ->
            if (line.isEmpty()) return@forEach
            val f = line.split('\t')
            when (f[0]) {
                "D" -> if (f.size >= 2) days.add(Day(f[1]))
                "B" -> if (f.size >= 2) days.lastOrNull()?.bigs?.add(Big(f[1]))
                "Q" -> {
                    val big = days.lastOrNull()?.bigs?.lastOrNull() ?: return@forEach
                    // Q 题干 A B C D 答案下标 原文 = 8 段
                    if (f.size < 8) return@forEach
                    val ans = f[6].toIntOrNull() ?: return@forEach
                    if (ans !in 0..3) return@forEach
                    big.rows.add(Row(f[1], listOf(f[2], f[3], f[4], f[5]), ans, f[7]))
                }
            }
        }
        return days.filter { it.bigs.any { b -> b.rows.isNotEmpty() } }
    }

    // ------------------------------------------------------------------ 组装 App 数据

    private fun build(days: List<Day>) {
        val maQuiz = ArrayList<Question>()
        val maDays = ArrayList<DayNode>(days.size)

        days.forEach { d ->
            val bigs = ArrayList<BigTopic>(d.bigs.size)
            d.bigs.forEach { b ->
                if (b.rows.isNotEmpty()) {
                    bigs.add(
                        // 进度初值一律 0：进度从零开始记
                        BigTopic(title = b.title, done0 = 0, total = b.rows.size, acc0 = 0),
                    )
                }
                b.rows.forEach { r ->
                    maQuiz.add(
                        Question(
                            id = maQuiz.size,
                            src = "${d.name} · 论述题「${b.title}」",
                            text = r.stem,
                            opts = r.opts,
                            ans = r.ans,
                            root = r.root,
                            // 「解析」就是填充后的原文（等于 root），所以解析正文留空；
                            // QuizScreen 在 exp 为空时不再单独渲染那一段
                            exp = "",
                            kp = listOf("$MA_SHORT · ${d.name}", b.title),
                        ),
                    )
                }
            }
            maDays.add(DayNode(d.name, bigs))
        }

        maDayCount = maDays.size
        maBigCount = maDays.sumOf { it.big.size }

        val ma = Subject(
            name = MA_NAME,
            short = MA_SHORT,
            cls = MA_CLS,
            start = 1,
            total = maDays.size,
            ej = maBigCount,
            range = if (maDays.isEmpty()) "还没有录入题目"
            else "Day1–Day${maDays.size} · 已开 ${maDays.size} 个 Day",
            day = maDays,
        )

        tree = listOf(ma)
        quiz = maQuiz
    }
}
