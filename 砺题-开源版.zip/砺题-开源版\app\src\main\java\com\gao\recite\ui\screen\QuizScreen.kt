package com.gao.recite.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gao.recite.data.Question
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.icons.IconSpec
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.vm.AnswerRec
import com.gao.recite.vm.AppVm
import kotlinx.coroutines.delay

/**
 * 答题页 —— 逐条对照原型 #quiz（.quiz-top / .quiz-progress / .quiz-body / .quiz-bottom）。
 * 顶部不放返回按钮：退出入口只在答题卡里，且要点两次。
 */
@Composable
fun QuizScreen(vm: AppVm) {
    val p = LocalPalette.current
    val q = vm.currentQuestion ?: return
    val total = vm.qSet.size
    val rec = vm.answers[vm.qIdx]
    val revealed = rec?.confirmed == true

    // 顶栏/来源行都基于**入口原始文案**（原型 pendingTopic），而不是重拼出来的范围
    val topTitle = shortTopic(vm.sessionTopic.ifBlank { vm.scope?.title() ?: "" })

    // 计时：原型 startTimer —— 每秒递减
    LaunchedEffect(vm.qSet) {
        while (true) {
            delay(1000)
            vm.tick()
        }
    }

    // 2026-09-22 二次定义：背题模式点选项作答即判分（answerReveal），答对 0.8s 自动下一题，
    // 答错停留展示答案；测验模式点选项只做标记（selectExam），交卷统一算分（submitExam）。

    // 背题模式答对自动下一题（一次性信号；autoAdvance 校验题位没被手动移动）
    LaunchedEffect(vm.autoNextToken) {
        if (vm.consumeAutoNext()) {
            delay(800)
            vm.autoAdvance()
        }
    }

    var showCard by remember { mutableStateOf(false) }
    var exitArmed by remember { mutableStateOf(0L) }

    Box(modifier = Modifier.fillMaxSize().background(p.bg)) {
        Column(modifier = Modifier.fillMaxSize()) {

            // ---------------- .quiz-top ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    topTitle,
                    style = AppType.quizT1,
                    color = p.text1,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                // 设置 · 显示答题计时：关闭后用的是 visibility:hidden（占位不塌陷），不是 display:none
                Row(
                    modifier = Modifier.alpha(if (vm.showTimer) 1f else 0f),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AppIcon(AppIcons.Timer, size = 13.dp, strokeWidth = 2f, tint = p.text2)
                    Spacer(Modifier.width(4.dp))
                    Text(fmtClock(vm.seconds), style = AppType.quizTimer, color = p.text2)
                }
            }

            // ---------------- .quiz-progress ----------------
            // 未作答时按 qIdx 计（原型 renderQ 里是 qIdx/qSet.length），作答后跳到 (qIdx+1)
            val frac = if (revealed) (vm.qIdx + 1f) / total else vm.qIdx.toFloat() / total
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(p.track),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(frac.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(Brush.linearGradient(listOf(p.primary, p.primary2))),
                )
            }

            // ---------------- .quiz-body ----------------
            // 滚动状态必须跟题位走：读完上一题的长解析（页面滚到底）按「下一题」，
            // 新题要从顶部开始，不能继承上一题的滚动深度（2026-09-22 修复）
            val bodyScroll = rememberScrollState()
            LaunchedEffect(vm.qIdx, vm.qSet) { bodyScroll.scrollTo(0) }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(bodyScroll)
                    .background(p.bg)
                    .padding(16.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Spacer(Modifier.weight(1f))
                    Text("第 ${vm.qIdx + 1} / $total 题", style = AppType.qCount, color = p.text3)
                }

                val srcLine = qSrcLine(q, topTitle)
                if (srcLine.isNotBlank()) {
                    Row(
                        modifier = Modifier
                            .background(p.surface2, RoundedCornerShape(12.dp))
                            .border(1.dp, p.cardBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        AppIcon(AppIcons.OpenBook, size = 12.dp, strokeWidth = 2f, tint = p.text3)
                        Spacer(Modifier.width(6.dp))
                        Text(srcLine, style = AppType.qSrc, color = p.text3)
                    }
                    Spacer(Modifier.height(12.dp))
                }

                // 「单选题」徽标紧贴题干（2026-09-22 用户要求挪到题目旁边）
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                    Box(
                        modifier = Modifier
                            .background(p.primarySoft, RoundedCornerShape(999.dp))
                            .padding(horizontal = 10.dp, vertical = 3.dp),
                    ) {
                        Text("单选题", style = AppType.qTag, color = p.primary)
                    }
                }

                Text(q.text, style = AppType.qText, color = p.text1)
                Spacer(Modifier.height(20.dp))

                // 选项乱序：按当前会话的展示顺序渲染，判分仍用原始下标。
                // 背题模式：点选项作答 → 立即判分显示答案；测验模式：点选项只做标记，交卷统一算分。
                vm.orderOf(vm.qIdx, q.opts.size).forEachIndexed { di, oi ->
                    OptionRow(
                        index = di,
                        text = q.opts[oi],
                        state = optionState(vm.backMode, q, rec, oi),
                        onPick = { if (vm.backMode) vm.answerReveal(oi) else vm.selectExam(oi) },
                    )
                    Spacer(Modifier.height(12.dp))
                }

                // 只有背题模式作答后展示「答案解析」卡；测验模式交卷前不显示答案（2026-09-22）
                if (vm.backMode && rec?.confirmed == true) {
                    Spacer(Modifier.height(8.dp))
                    // 乱序时界面字母是重排后的，解析里的字母要按同一映射换算
                    ExplainCard(q, rec, vm.orderOf(vm.qIdx, q.opts.size))
                }
                Spacer(Modifier.height(16.dp))
            }

            // ---------------- .quiz-bottom ----------------
            Column(modifier = Modifier.fillMaxWidth().background(p.surface)) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(p.cardBorder))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 26.dp),
                ) {
                    // .q-nav：矮、淡、描边的小胶囊，刻意降低误触概率
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        NavPill("上一题", AppIcons.ChevronLeft, leading = true, enabled = vm.qIdx > 0) { vm.goPrev() }
                        CardPill(
                            done = vm.answers.size,
                            total = total,
                            modifier = Modifier.weight(1f),
                        ) { showCard = true }
                        NavPill(
                            "下一题", AppIcons.ChevronRight, leading = false,
                            enabled = vm.qIdx < total - 1,
                        ) { vm.goNext() }
                    }
                    Spacer(Modifier.height(10.dp))
                    // .q-act
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        val faved = vm.favIds.contains(q.id)
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(p.surface2, RoundedCornerShape(16.dp))
                                .border(1.dp, p.cardBorder, RoundedCornerShape(16.dp))
                                .clickable { vm.toggleFav(q.id) },
                            contentAlignment = Alignment.Center,
                        ) {
                            // .star-btn 常态就是 warning 色，选中后填充
                            AppIcon(
                                if (faved) AppIcons.StarFilled else AppIcons.Star,
                                size = 20.dp,
                                strokeWidth = 1.8f,
                                tint = p.warning,
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .background(p.primary, RoundedCornerShape(16.dp))
                                .clickable { if (vm.backMode) vm.goNext() else vm.submitExam() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (vm.backMode) {
                                    // 背题模式：作答即判分，这里只负责翻页 / 收尾
                                    if (vm.qIdx < total - 1) "下一题" else "完成背诵"
                                } else {
                                    // 测验模式：交卷后统一算分显示答案
                                    "交卷"
                                },
                                style = AppType.btnLg,
                                color = p.onPrimary,
                            )
                        }
                    }
                }
            }
        }

        // 答题卡抽屉
        if (showCard) {
            AnswerCardSheet(
                vm = vm,
                onJump = { pos -> vm.jumpTo(pos); showCard = false },
                onExit = {
                    val now = System.currentTimeMillis()
                    if (now - exitArmed < 2500) vm.exitQuiz() else exitArmed = now
                },
                exitArmed = System.currentTimeMillis() - exitArmed < 2500,
                onDismiss = { showCard = false },
            )
        }

        // 完成/交卷时还有未作答的题 → 确认弹窗（2026-09-23：不返回则未答全按答错计入错题本）
        if (vm.finishPrompt) {
            val pal = LocalPalette.current
            AlertDialog(
                onDismissRequest = { vm.resolveFinish(true) },
                containerColor = pal.surface,
                title = {
                    Text("还有 ${vm.finishUnanswered} 题未作答", color = pal.text1, style = AppType.title)
                },
                text = {
                    Text(
                        "是否返回作答？若不返回，未作答的题目将全部按答错计入错题本。",
                        color = pal.text2,
                    )
                },
                confirmButton = {
                    TextButton(onClick = { vm.resolveFinish(true) }) {
                        Text("返回作答", color = pal.primary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { vm.resolveFinish(false) }) {
                        Text("仍要完成", color = pal.text3)
                    }
                },
            )
        }
    }
}

/** 原型 .opt 的四种呈现：普通 / 已选 / 答对 / 答错（锁定后未涉及的选项保持普通样式，不置灰） */
private enum class OptState { NORMAL, SELECTED, RIGHT, WRONG }

/**
 * 背题模式作答后、测验模式交卷后：正确项绿、选错的项红；
 * 测验模式交卷前：只高亮已选项。
 */
private fun optionState(back: Boolean, q: Question, rec: AnswerRec?, i: Int): OptState {
    if (rec == null) return OptState.NORMAL
    if (back || rec.confirmed) {
        return when {
            i == q.ans -> OptState.RIGHT
            i == rec.selected && !rec.right -> OptState.WRONG
            else -> OptState.NORMAL
        }
    }
    return if (i == rec.selected) OptState.SELECTED else OptState.NORMAL
}

@Composable
private fun OptionRow(
    index: Int,
    text: String,
    state: OptState,
    onPick: () -> Unit,
) {
    val p = LocalPalette.current
    val letter = ('A'.code + index).toChar().toString()
    // 原型：容器底/边框随状态变，字色始终是 --text-1；只有 letter 方块换底换字色
    val (bg, border) = when (state) {
        OptState.SELECTED -> p.primarySoft to p.primary
        OptState.RIGHT -> p.success.copy(alpha = .10f) to p.success
        OptState.WRONG -> p.dangerSoft to p.danger
        else -> p.surface to p.cardBorder
    }
    val (letterBg, letterFg) = when (state) {
        OptState.SELECTED -> p.primary to p.onPrimary
        OptState.RIGHT -> p.success to Color.White
        OptState.WRONG -> p.danger to Color.White
        else -> p.surface2 to p.text2
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg, RoundedCornerShape(16.dp))
            .border(1.5.dp, border, RoundedCornerShape(16.dp))
            .clickable(onClick = onPick)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .background(letterBg, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(letter, style = AppType.optLetter, color = letterFg)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, style = AppType.optText, color = p.text1, modifier = Modifier.weight(1f))
        // .opt .mark：答对/答错右侧出现的对勾标记
        if (state == OptState.RIGHT || state == OptState.WRONG) {
            Spacer(Modifier.width(8.dp))
            AppIcon(
                AppIcons.Mark,
                size = 18.dp,
                strokeWidth = 2.4f,
                tint = if (state == OptState.RIGHT) p.success else p.danger,
            )
        }
    }
}

/** 原型 .exp：答案解析卡 —— 背题模式作答后出现（答对短暂展示后自动跳题，答错停留细读） */
@Composable
private fun ExplainCard(q: Question, rec: AnswerRec, order: List<Int>) {
    val p = LocalPalette.current
    // 选项乱序时，界面字母 = 显示序；原始下标要映射回显示字母（找不到就兜底用原始下标）
    fun dispLetter(orig: Int): Char {
        val d = order.indexOf(orig).takeIf { it >= 0 } ?: orig
        return ('A'.code + d).toChar()
    }
    AppCard {
        Column {
            Text("答案解析", style = AppType.expTitle, color = p.text1)
            Spacer(Modifier.height(8.dp))
            Text(
                buildString {
                    append("正确答案：").append(dispLetter(q.ans))
                    if (!rec.right) append(" · 你选了 ").append(dispLetter(rec.selected)).append("，已加入错题本")
                },
                style = AppType.expTitle,
                color = p.success,
            )
            Spacer(Modifier.height(8.dp))
            // .root-box：primary-soft 底
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(p.primarySoft, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                Text("📖 原文", style = AppType.rootLabel, color = p.primary)
                Spacer(Modifier.height(4.dp))
                Text(q.root, style = AppType.expText, color = p.text1)
            }
            Spacer(Modifier.height(10.dp))
            // 真题的「解析」就是填充后的原文（已放在背诵原文里），exp 为空时不再多出一段空行
            if (q.exp.isNotBlank()) {
                Text(q.exp, style = AppType.expText, color = p.text2)
                Spacer(Modifier.height(10.dp))
            }
            Row {
                q.kp.forEach { k ->
                    Box(
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .background(p.surface2, RoundedCornerShape(999.dp))
                            .padding(horizontal = 10.dp, vertical = 3.dp),
                    ) {
                        Text(k, style = AppType.tag, color = p.text2)
                    }
                }
            }
        }
    }
}

/** .q-nav > button —— 32 高 / 999 圆角 / 11px-600 / --text-3 */
@Composable
private fun NavPill(
    label: String,
    icon: IconSpec,
    leading: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val c = p.text3
    Row(
        modifier = Modifier
            .height(32.dp)
            .alpha(if (enabled) 1f else .3f)
            .background(Color.Transparent, RoundedCornerShape(999.dp))
            .border(1.dp, p.cardBorder, RoundedCornerShape(999.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading) {
            AppIcon(icon, size = 13.dp, strokeWidth = 2.2f, tint = c)
            Spacer(Modifier.width(4.dp))
        }
        Text(label, style = AppType.navBtn, color = c, maxLines = 1)
        if (!leading) {
            Spacer(Modifier.width(4.dp))
            AppIcon(icon, size = 13.dp, strokeWidth = 2.2f, tint = c)
        }
    }
}

/** .nav-card-btn —— 中间那个撑满的「答题卡 x/y」 */
@Composable
private fun CardPill(done: Int, total: Int, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        modifier = modifier
            .height(32.dp)
            .background(Color.Transparent, RoundedCornerShape(999.dp))
            .border(1.dp, p.cardBorder, RoundedCornerShape(999.dp))
            .clickable { onClick() }
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        AppIcon(AppIcons.GridCard, size = 13.dp, strokeWidth = 2.2f, tint = p.text3)
        Spacer(Modifier.width(4.dp))
        Text(
            buildAnnotatedString {
                append("答题卡 ")
                pushStyle(SpanStyle(color = p.text2, fontWeight = FontWeight.Bold))
                append("$done/$total")
                pop()
            },
            style = AppType.navBtn,
            color = p.text3,
            maxLines = 1,
        )
    }
}

/** 原型 shortTopic：顶栏只留「科目 · Day」 */
private fun shortTopic(t: String): String {
    val tp = t.replace("继续上次背诵 · ", "")
    val m = Regex("^(\\S+) · (Day\\d+)").find(tp)
    return if (m != null) m.groupValues[1] + " · " + m.groupValues[2] else t
}

/** 原型 qSrcLine：顶栏已含 Day 时只显示论述题名，否则补上完整路径 */
private fun qSrcLine(q: Question, top: String): String {
    val day = q.kp.getOrNull(0).orEmpty()
    val big = q.kp.getOrNull(1).orEmpty().trim('「', '」', '『', '』', '《', '》')
    val label = if (big.isNotBlank()) "论述题「$big」" else ""
    val dn = Regex("Day\\d+").find(day)?.value.orEmpty()
    if (dn.isNotBlank() && top.contains(dn)) return label
    return listOf(day, label).filter { it.isNotBlank() }.joinToString(" · ")
}

/** 原型倒计时格式：mm:ss */
private fun fmtClock(sec: Int): String {
    val left = (720 - sec).coerceAtLeast(0)
    return "%02d:%02d".format(left / 60, left % 60)
}
