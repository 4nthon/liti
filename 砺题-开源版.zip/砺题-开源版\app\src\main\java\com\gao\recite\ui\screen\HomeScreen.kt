package com.gao.recite.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gao.recite.data.DAILY_QUOTES
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.components.Divider1
import com.gao.recite.ui.components.IconButton24
import com.gao.recite.ui.components.MetaStat
import com.gao.recite.ui.components.ProgressBar
import com.gao.recite.ui.components.SectionHead
import com.gao.recite.ui.components.StatCell
import com.gao.recite.ui.components.StatDivider
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.AppRadius
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.theme.SubjectTone
import com.gao.recite.ui.toneOf
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.Scope
import com.gao.recite.vm.ScopeKind
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/**
 * 欢迎语，逐字对齐原型 greet()（注意 h<5 的「夜深了」这一档）。
 */
private fun greetText(hour: Int): String = when {
    hour < 5 -> "夜深了，早点休息"
    hour < 9 -> "早上好，欢迎回来"
    hour < 12 -> "上午好，欢迎回来"
    hour < 14 -> "中午好，欢迎回来"
    hour < 18 -> "下午好，欢迎回来"
    else -> "晚上好，欢迎回来"
}

/**
 * 每日名言按「一年中的第几天」轮换。
 * 原型的 dayOfYear 是 `Math.floor((now - new Date(y,0,0)) / 864e5)`，
 * 1 月 1 日算第 1 天 —— 与 java.time 的 `dayOfYear` 完全同值，
 * 所以下标就是 `dayOfYear % len`（曾经多减了 1，整体错位一天）。
 */
private fun dailyQuote(): String {
    val d = LocalDate.now().dayOfYear
    return DAILY_QUOTES[d % DAILY_QUOTES.size]
}

@Composable
fun HomeScreen(vm: AppVm) {
    val p = LocalPalette.current
    val today = LocalDate.now()
    // 原型是「9月18日 星期五」——星期必须走中文 Locale，否则会输出 Monday
    val dateText = today.format(DateTimeFormatter.ofPattern("M月d日 EEEE", Locale.SIMPLIFIED_CHINESE))
    val quote = dailyQuote()
    val greet = greetText(LocalTime.now().hour)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 24.dp),
    ) {
        // ---------------- 欢迎栏（原型 .welcome：左右两端，底部 28px 间距）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 2.dp, end = 2.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Column(Modifier.weight(1f)) {
                Text(greet, style = AppType.welcomeTitle, color = p.text1)
                Spacer(Modifier.height(4.dp))
                Text(dateText, style = AppType.welcomeDate, color = p.text2)
                Spacer(Modifier.height(5.dp))
                Text(quote, style = AppType.welcomeQuote, color = p.text3)
            }
            IconButton24(AppIcons.Settings, p.text1, onClick = { vm.openSettings() })
        }

        Spacer(Modifier.height(28.dp))

        // ---------------- 答题历史数据（原型 .card.stats：4 列，格间 1px 竖线）
        val accGlobal = if (vm.totalAnswered > 0) (vm.totalCorrect * 100.0 / vm.totalAnswered).roundToInt() else 0
        AppCard(modifier = Modifier.padding(bottom = 16.dp), padding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StatCell(AppIcons.Pen, p.primary, "%,d".format(vm.totalAnswered), null, "累计刷题", Modifier.weight(1f))
                StatDivider()
                StatCell(AppIcons.CheckCircle, p.success, "$accGlobal", "%", "平均正确率", Modifier.weight(1f))
                StatDivider()
                StatCell(AppIcons.Flame, p.warning, "${vm.todayCount}", null, "今日已练", Modifier.weight(1f))
                StatDivider()
                StatCell(AppIcons.AlertCircle, p.danger, "${vm.wrongLeft}", null, "待消灭错题", Modifier.weight(1f))
            }
        }

        // ---------------- 继续上次背诵（原型里这张卡是写死的，换真题后改成落在真实题目上）
        vm.continueCard()?.let { card ->
            AppCard(
                modifier = Modifier.padding(bottom = 16.dp),
                // resume = 这一轮还没收尾，点进去要接回原来的题目表与原题位，而不是重开一轮
                onClick = {
                    if (card.resume) vm.resumeSession()
                    else vm.startQuiz(card.scope, topic = "${card.title} · ${card.day}")
                },
                padding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(card.title, style = AppType.cardTitle, color = p.text1)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            card.sub,
                            style = AppType.cardSub, color = p.text2, maxLines = 2,
                        )
                        Spacer(Modifier.height(7.dp))
                        ProgressBar(card.pct, p.primary, p.primary2, height = 5.dp)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(card.footPre, style = AppType.mini, color = p.text3)
                            Text(card.footNum, style = AppType.miniBold, color = p.text2)
                            Text(card.footSuffix, style = AppType.mini, color = p.text3)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(p.primarySoft),
                        contentAlignment = Alignment.Center,
                    ) {
                        AppIcon(AppIcons.PlayFilled, size = 12.dp, tint = p.primary)
                    }
                }
            }
        }

        // ---------------- 我的科目（三级折叠）
        SectionHead(
            "我的科目",
            action = if (vm.allExpanded) "全部收起" else "全部展开",
            onAction = { vm.expandAll(!vm.allExpanded) },
        )

        vm.tree.forEachIndexed { si, _ ->
            SubjectBlock(vm, si)
            Spacer(Modifier.height(12.dp))
        }
    }
}

/** 原型 .subject：科目白卡，头行 + 计量行 + 进度条 */
@Composable
private fun SubjectBlock(vm: AppVm, si: Int) {
    val p = LocalPalette.current
    val sj = vm.tree[si]
    val tone = toneOf(sj.cls)
    val st = vm.statSj(si)
    val open = vm.isSubjectOpen(si)

    Column(Modifier.fillMaxWidth()) {
        // .subject-head
        AppCard(padding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.toggleSubject(si) },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .background(Brush.linearGradient(listOf(tone.main, tone.gradEnd)), CircleShape),
                    )
                    Spacer(Modifier.width(8.dp))
                    // 原型 .head-title 用的是 sj.name（全名，「马克思主义基本原理」），不是简称
                    Text(
                        sj.name,
                        style = AppType.headTitle,
                        color = p.text1,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text("${st.pct}%", style = AppType.miniSemi, color = p.text2)
                    PlayChevronSlot(tone, onClick = { vm.startQuiz(Scope(ScopeKind.SUBJECT, si)) })
                }
                Spacer(Modifier.height(5.dp))
                MetaStat(
                    listOf(
                        "Day" to "${sj.day.size}/${sj.total}",
                        "论述题" to "${st.started}/${sj.ej}",
                        "选择题" to "${st.done}/${st.total}",
                        "正确率" to "${st.acc}%",
                    ),
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                ProgressBar(st.pct, tone.main, tone.gradEnd)
            }
        }

        // .collapsible > .chapters
        if (open) {
            Spacer(Modifier.height(8.dp))
            sj.day.forEachIndexed { di, _ ->
                DayBlock(vm, si, di)
                Spacer(Modifier.height(6.dp))
            }
            // 未开始的 Day 也要列出（原型会补足到 sj.total 个，可点箭头开背）
            for (i in sj.day.size until sj.total) {
                EmptyDayBlock(vm, si, sj.start + i, tone)
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

/** 原型 .chapter：浅色底块 + Day 头 + 计量行 + 5px 进度条 + 论述题白行 */
@Composable
private fun DayBlock(vm: AppVm, si: Int, di: Int) {
    val p = LocalPalette.current
    val sj = vm.tree[si]
    val d = sj.day[di]
    val tone = toneOf(sj.cls)
    val ds = vm.statDay(si, di)
    val open = vm.isDayOpen(si, di)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
            .clip(RoundedCornerShape(AppRadius.inner.dp))
            .background(dayLayer2(sj.cls))
            .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 8.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { vm.toggleDay(si, di) }
                .padding(horizontal = 4.dp, vertical = 8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d.name, style = AppType.chTitle, color = p.text1, modifier = Modifier.weight(1f), maxLines = 1)
                Text("${ds.pct}%", style = AppType.mini, color = p.text2)
                PlayChevronSlot(tone, onClick = { vm.startQuiz(Scope(ScopeKind.DAY, si, di)) })
            }
            Spacer(Modifier.height(4.dp))
            MetaStat(
                listOf(
                    "论述题" to "${ds.started}/${ds.bigs}",
                    "选择题" to "${ds.done}/${ds.total}",
                    "正确率" to "${ds.acc}%",
                ),
                modifier = Modifier.padding(bottom = 6.dp),
            )
            ProgressBar(ds.pct, tone.main, tone.gradEnd, height = 5.dp)
        }

        if (open) {
            Spacer(Modifier.height(0.dp))
            Column(Modifier.padding(start = 6.dp)) {
                d.big.forEachIndexed { bi, _ ->
                    BigRow(vm, si, di, bi, tone)
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
    }
}

/** 原型 .section-row：白行卡（无描边）+ 标题/计量 + 56px 迷你进度条 + ">" */
@Composable
private fun BigRow(vm: AppVm, si: Int, di: Int, bi: Int, tone: SubjectTone) {
    val p = LocalPalette.current
    val b = vm.tree[si].day[di].big[bi]
    val bs = vm.statBig(si, di, bi)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(layer3())
            .clickable { vm.startQuiz(Scope(ScopeKind.BIG, si, di, bi)) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(b.title, style = AppType.secTitle, color = p.text1, maxLines = 2)
            Spacer(Modifier.height(2.dp))
            MetaStat(listOf("选择题" to "${bs.done}/${bs.total}", "正确率" to "${bs.acc}%"))
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(56.dp)) {
            ProgressBar(bs.pct, tone.main, tone.gradEnd, height = 5.dp)
        }
        PlayChevron(tone)
    }
}

/** 未开始的 Day：整块占位，点进去只提示「本 Day 还没有录入题目」 */
@Composable
private fun EmptyDayBlock(vm: AppVm, si: Int, dayNumber: Int, tone: SubjectTone) {
    val p = LocalPalette.current
    val sj = vm.tree[si]
    val dayName = "Day$dayNumber"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
            .clip(RoundedCornerShape(AppRadius.inner.dp))
            .background(dayLayer2(sj.cls))
            .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 8.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { vm.toggleEmptyDay(si, dayName) }
                .padding(horizontal = 4.dp, vertical = 8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(dayName, style = AppType.chTitle, color = p.text1, modifier = Modifier.weight(1f))
                Text("0%", style = AppType.mini, color = p.text2)
                PlayChevronSlot(tone, alpha = .45f, onClick = { vm.startEmptyDay() })
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "未开始 · 论述题 0 道 · 选择题 0 道",
                style = AppType.mini, color = p.text3,
                modifier = Modifier.padding(bottom = 6.dp),
            )
            ProgressBar(0, tone.main, tone.gradEnd, height = 5.dp)
        }
        if (vm.isDayOpen(si, dayName)) {
            Column(Modifier.padding(start = 6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(layer3())
                        .clickable { vm.startEmptyDay() }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("这个 Day 还没开始", style = AppType.secTitle, color = p.text1)
                        Spacer(Modifier.height(2.dp))
                        Text("点这里开始背诵", style = AppType.mini, color = p.text3)
                    }
                }
                Spacer(Modifier.height(5.dp))
            }
        }
    }
}

/** 科目头 / Day 头右侧的 ">"（22dp 命中区，视觉 13px 箭头） */
@Composable
private fun PlayChevronSlot(tone: SubjectTone, alpha: Float = 1f, onClick: () -> Unit) {
    Spacer(Modifier.width(4.dp))
    com.gao.recite.ui.components.PlayChevron(tone, alpha = alpha, onClick = onClick)
}

@Composable
private fun PlayChevron(tone: SubjectTone) {
    Spacer(Modifier.width(8.dp))
    com.gao.recite.ui.components.PlayChevron(tone)
}

/** 二级层级底框色：--layer-2（按科目分色，深色模式统一） */
@Composable
private fun dayLayer2(cls: String) = com.gao.recite.ui.DayBoxBg(cls)

/** 三级层级底框色：--layer-3（浅色=白 / 深色=#252D3D） */
@Composable
private fun layer3() = com.gao.recite.ui.SectionBoxBg()
