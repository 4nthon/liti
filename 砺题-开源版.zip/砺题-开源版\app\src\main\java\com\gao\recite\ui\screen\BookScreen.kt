package com.gao.recite.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.gao.recite.ui.components.AppCard
import com.gao.recite.ui.components.Divider1
import com.gao.recite.ui.components.EmptyBox
import com.gao.recite.ui.components.QRow
import com.gao.recite.ui.components.SectionHead
import com.gao.recite.ui.icons.AppIcon
import com.gao.recite.ui.icons.AppIcons
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.ui.toneOf
import com.gao.recite.vm.AppVm
import com.gao.recite.vm.Scope
import com.gao.recite.vm.ScopeKind

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookScreen(vm: AppVm) {
    val p = LocalPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp),
    ) {
        Text("题本", style = AppType.pageTitle, color = p.text1)
        Spacer(Modifier.height(4.dp))
        Text("错题与收藏，集中管理", style = AppType.pageSub, color = p.text2)
        Spacer(Modifier.height(16.dp))

        // ---------------- 错题英雄卡 .card.bk-hero2
        AppCard(modifier = Modifier.padding(bottom = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.dangerSoft),
                    contentAlignment = Alignment.Center,
                ) {
                    AppIcon(AppIcons.AlertCircle, size = 20.dp, tint = p.danger)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("错题本", style = AppType.cardTitle, color = p.text1)
                    Spacer(Modifier.height(2.dp))
                    Text("错题以论述题为单位 · 整题全对 3 次即可消灭", style = AppType.cardSubLight, color = p.text3)
                }
            }
            Spacer(Modifier.height(14.dp))
            // .bh-nums：上下 1px 描边 + 中间 1px 竖线，数字 22px/800
            Divider1()
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                HeroNum("${vm.wrongLeft}", "待消灭", p.danger, Modifier.weight(1f))
                // .bh-nums>div+div::after —— 70% 高的竖线
                Box(Modifier.width(1.dp).fillMaxHeight(.7f).background(p.cardBorder))
                HeroNum("${vm.killedCount}", "已消灭", p.success, Modifier.weight(1f))
            }
            Divider1()
        }

        // ---------------- 最近错题
        SectionHead("最近错题", action = "全部 ›", onAction = { vm.openList("wrong") })
        AppCard(
            modifier = Modifier.padding(bottom = 16.dp),
            padding = PaddingValues(vertical = 8.dp),
        ) {
            val recent = vm.wrongQAll().take(3)
            if (recent.isEmpty()) {
                Box(Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
                    EmptyBox("🎉", "太棒了，目前没有待消灭的错题")
                }
            } else {
                // 最近错题以「选择题」为单位：一行 = 一道答错的小题（2026-09-22 老高拍板）
                recent.forEachIndexed { i, qi ->
                    val t = vm.bigOf(qi) ?: return@forEachIndexed
                    val sj = vm.tree[t.first]
                    val n = vm.wrongKillOf(qi)
                    if (i > 0) Divider1()
                    QRow(
                        stem = vm.quiz[qi].text,
                        src = "${sj.short} · ${sj.day[t.second].name} · ${sj.day[t.second].big[t.third].title}",
                        badges = listOf("b-red" to if (n > 0) "已答对 $n/3 次" else "刚答错"),
                        tone = toneOf(sj.cls),
                        onClick = {
                            vm.startQuiz(Scope(ScopeKind.SINGLE, si = qi), topic = "错题重练 · 单题")
                        },
                    )
                }
            }
        }

        // ---------------- 我的收藏 .card.bk-fav
        AppCard(
            onClick = { vm.openList("fav") },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(p.primarySoft),
                    contentAlignment = Alignment.Center,
                ) {
                    AppIcon(AppIcons.StarFilled, size = 20.dp, tint = p.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("我的收藏", style = AppType.cardTitle, color = p.text1)
                    Spacer(Modifier.height(2.dp))
                    Text("刷题时点 ⭐ 收进这里", style = AppType.cardSubLight, color = p.text3)
                }
                Text("${vm.favTotal}", style = AppType.favCountNum, color = p.primary)
                Text("题", style = AppType.favCountUnit, color = p.text3, modifier = Modifier.padding(start = 3.dp))
            }
            Spacer(Modifier.height(12.dp))
            // .fav-chips：flex-wrap: wrap / gap 6 / margin 12 0
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                vm.favChipNames().forEach { (name, ghost) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(p.surface2)
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text(
                            name,
                            style = AppType.mini,
                            color = if (ghost) p.text2.copy(alpha = .55f) else p.text2,
                            maxLines = 1,
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(999.dp))
                    .background(p.primarySoft)
                    .clickable { vm.startQuiz(Scope(ScopeKind.FAV)) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("进入背题模式", style = AppType.btn, color = p.primary)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** .bh-nums > div：22px/800 数字 + 11px 说明 */
@Composable
private fun HeroNum(num: String, label: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(num, style = AppType.heroNum, color = color)
        Spacer(Modifier.height(2.dp))
        Text(label, style = AppType.numCaption, color = p.text2)
    }
}
