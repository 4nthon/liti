package com.gao.recite.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.gao.recite.ui.theme.AppType
import com.gao.recite.ui.theme.LocalPalette
import com.gao.recite.vm.AppVm

/**
 * 答题卡 —— 逐条对照原型 #cardMask / #qCardSheet / .qcard-grid / .qc。
 * 三色：答对绿 / 答错红 / 未作答浅蓝；当前题在外圈加一道 4px 主色环。
 */
@Composable
fun AnswerCardSheet(
    vm: AppVm,
    onJump: (Int) -> Unit,
    onExit: () -> Unit,
    exitArmed: Boolean,
    onDismiss: () -> Unit,
) {
    val p = LocalPalette.current
    Box(modifier = Modifier.fillMaxSize()) {
        // .qcard-mask：rgba(10,12,20,.4)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x660A0C14))
                .clickable { onDismiss() },
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(p.surface, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 26.dp),
        ) {
            // .qcard-top
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("答题卡", style = AppType.qcardTitle, color = p.text1, modifier = Modifier.weight(1f))
                // .qcard-exit：11px / --text-3 / 无底色 / 点按才有 surface-2
                Box(
                    modifier = Modifier
                        .background(Color.Transparent, RoundedCornerShape(8.dp))
                        .clickable { onExit() }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                ) {
                    Text(
                        if (exitArmed) "再点一次退出练习" else "退出练习",
                        style = AppType.qcardExit,
                        color = p.text3,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            // .qcard-legend
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                LegendItem("right", p.success, "答对")
                LegendItem("wrong", p.danger, "答错")
                // 测验模式：交卷前已选但未判分的格子实心主色，加一条图例
                if (!vm.backMode) LegendItem("picked", p.primary, "已选")
                LegendItem("todo", p.primarySoft, "未作答")
                LegendItem("cur", Color.Transparent, "当前")
            }
            // .qcard-grid：padding 6 + margin-left -6（负偏移），保证第 1 格与上面的图例左对齐
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 38.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 196.dp)
                    .offset(x = (-6).dp),
                contentPadding = PaddingValues(6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(vm.qSet.size) { pos ->
                    CardCell(vm = vm, pos = pos, onJump = onJump)
                }
            }
        }
    }
}

/** .qc —— 38 高 / 圆角 10 / 1.5px 描边；cur 态在外圈补 4px 主色环 + 2px 底色隔断 */
@Composable
private fun CardCell(vm: AppVm, pos: Int, onJump: (Int) -> Unit) {
    val p = LocalPalette.current
    val rec = vm.answers[pos]
    val cur = pos == vm.qIdx
    val answered = rec?.confirmed == true
    val picked = rec != null && !rec.confirmed
    val (bg, fg, border) = when {
        answered && rec!!.right -> Triple(p.success, Color.White, p.success)
        answered -> Triple(p.danger, Color.White, p.danger)
        // 已选未判（测验模式交卷前）：实心主色
        picked -> Triple(p.primary, Color.White, p.primary)
        else -> Triple(p.primarySoft, p.primaryInk, p.primary.copy(alpha = .26f))
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .drawBehind {
                // box-shadow: 0 0 0 2px surface, 0 0 0 4px primary
                if (cur) {
                    drawRoundRect(
                        color = p.primary,
                        topLeft = Offset(-2f, -2f),
                        size = Size(size.width + 4f, size.height + 4f),
                        cornerRadius = CornerRadius(12f, 12f),
                    )
                    drawRoundRect(
                        color = p.surface,
                        topLeft = Offset(2f, 2f),
                        size = Size(size.width - 4f, size.height - 4f),
                        cornerRadius = CornerRadius(10f, 10f),
                    )
                }
            }
            .background(bg, RoundedCornerShape(10.dp))
            .border(1.5.dp, border, RoundedCornerShape(10.dp))
            .clickable { onJump(pos) },
        contentAlignment = Alignment.Center,
    ) {
        Text("${pos + 1}", style = AppType.qc, color = fg)
    }
}

/** .qcard-legend 里的一格：10×10 圆角色块 + 10px 说明 */
@Composable
private fun LegendItem(kind: String, color: Color, label: String) {
    val p = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(if (kind == "cur") Color.Transparent else color, RoundedCornerShape(3.dp))
                .then(
                    when (kind) {
                        "todo" -> Modifier.border(1.dp, p.primary, RoundedCornerShape(3.dp))
                        "cur" -> Modifier.border(2.dp, p.primary, RoundedCornerShape(3.dp))
                        else -> Modifier
                    },
                ),
        )
        Spacer(Modifier.width(4.dp))
        Text(label, style = AppType.qcardLegend, color = p.text3)
    }
}
