# -*- coding: utf-8 -*-
"""全量校验 qbank.tsv：答案键 vs 原文 是否一致。

原理：真题的「背诵原文」= 题干把空位填上正确答案后的原文。
正确选项的内容（多空题按 ` / ` 拆分）必须能按序在原文里找到；
若答案键指向的选项不在原文里、而恰好有唯一另一个选项在原文里 → 判定为答案键错误，给出修正建议。

只报告，不改文件。用法：
  python check_answers.py            # 全量校验
  python check_answers.py --show 40  # 只显示前 N 条
"""
import io
import os
import re
import sys

TSV = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "..", "app", "src", "main", "assets", "qbank.tsv")

RE_ANY_BLANK = re.compile(r"【\s*】|_{2,}|\[\s*\]")

TABLE = str.maketrans({
    "，": ",", "。": ".", "；": ";", "：": ":", "、": ",",
    "（": "(", "）": ")", "【": "[", "】": "]",
    "“": '"', "”": '"', "‘": "'", "’": "'",
    "「": '"', "」": '"', "『": '"', "』": '"',
})

def norm(s):
    return re.sub(r"\s+", "", s).translate(TABLE)

RE_SKELETON = re.compile(r"[的地了、和与'\"“”‘’「」『』,]")

def skeleton(s):
    """更宽松的骨架：再去掉 的/地/了、顿号和引号 —— 只用于「键失败后」的复核"""
    return RE_SKELETON.sub("", norm(s))

def parts_of(o):
    """多空选项的分空分隔符：` / `、`／`、` \\ `、全角/半角分号（Day3 起的题库用 `；`）"""
    parts = re.split(r"\s*/\s*|\s*\\\s*|\s*[；;]\s*", o)
    return [norm(p) for p in parts if norm(p)]

def parts_in_root(parts, root_n):
    """各段是否都能在归一化原文里找到（不要求顺序：原文偶有语序调整）"""
    return all(root_n.find(p) >= 0 for p in parts)

def main():
    show = 20
    if "--show" in sys.argv:
        show = int(sys.argv[sys.argv.index("--show") + 1])
    qs = []
    day = big = ""
    with io.open(TSV, encoding="utf-8") as fh:
        for line in fh:
            f = line.rstrip("\n").split("\t")
            if f[0] == "D":
                day = f[1]
            elif f[0] == "B":
                big = f[1]
            elif f[0] == "Q":
                qs.append((day, big, f[1], f[2:-2], int(f[-2]), f[-1]))

    n_key_wrong = 0
    n_ambiguous = 0
    n_no_match = 0
    n_skeleton_ok = 0
    n_noblank_key_out = 0
    problems = []
    for idx, (day, big, stem, opts, ai, root) in enumerate(qs):
        root_n = norm(root)
        root_s = skeleton(root)
        blanks = len(RE_ANY_BLANK.findall(stem))
        if ai < 0 or ai >= len(opts):
            n_noblank_key_out += 1
            problems.append("[答案键越界] #%d %s %s 键=%d 选项数=%d" % (idx, day, big, ai, len(opts)))
            continue
        key_parts = parts_of(opts[ai])
        if parts_in_root(key_parts, root_n):
            continue
        # 第一层失败，用骨架复核（容忍 的/地/了、顿号、引号、和/与 差异）
        if all(root_s.find(p) >= 0 for p in map(skeleton, key_parts)):
            n_skeleton_ok += 1
            continue
        # 键指向的选项不在原文里：看看哪个选项在（骨架口径）
        hits = [i for i, o in enumerate(opts)
                if parts_in_root(list(map(skeleton, parts_of(o))), root_s)]
        if len(hits) == 1:
            n_key_wrong += 1
            problems.append("[答案键错误→应改为%s] #%d %s %s\n    题干: %s\n    键=%s(%s)\n    实际=%s(%s)\n    原文: %s"
                            % (chr(65 + hits[0]), idx, day, big, stem[:70],
                               chr(65 + ai), opts[ai][:40],
                               chr(65 + hits[0]), opts[hits[0]][:40], root[:70]))
        elif len(hits) == 0:
            n_no_match += 1
            problems.append("[四个选项都不在原文里] #%d %s %s\n    题干: %s\n    键=%s(%s)\n    原文: %s"
                            % (idx, day, big, stem[:70], chr(65 + ai), opts[ai][:40], root[:70]))
        else:
            n_ambiguous += 1
            problems.append("[多个选项都在原文里，无法定谳] #%d %s %s 候选=%s | 题干: %s | 原文: %s"
                            % (idx, day, big, "".join(chr(65 + h) for h in hits), stem[:50], root[:50]))

    print("总题数 %d | 骨架复核通过 %d | 答案键错误(可修) %d | 无选项命中 %d | 多选命中(人工看) %d | 键越界 %d"
          % (len(qs), n_skeleton_ok, n_key_wrong, n_no_match, n_ambiguous, n_noblank_key_out))
    with io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "check_answers.txt"),
                 "w", encoding="utf-8", newline="") as fh:
        fh.write("\n".join(problems) if problems else "全部一致")
    for p in problems[:show]:
        print(p)
    if len(problems) > show:
        print("…… 其余 %d 条见 tools/check_answers.txt" % (len(problems) - show))

if __name__ == "__main__":
    main()
